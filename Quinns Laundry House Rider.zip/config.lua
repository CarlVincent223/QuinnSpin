--
-- For more information on config.lua see the Project Configuration Guide at:
-- https://docs.coronalabs.com/guide/basics/configSettings
--
-- local aspectRatio = display.pixelHeight / display.pixelWidth
application =
{
	content =
	{
		width = 320 * (display.pixelHeight/display.pixelWidth>1 and 1 or 1/(display.pixelHeight/display.pixelWidth)),
        height = 480 * (display.pixelHeight/display.pixelWidth<1 and 1 or (display.pixelHeight/display.pixelWidth)/1),
		scale = "adaptive",
		-- width = aspectRatio > 1.5 and 320 or math.ceil( 480 / aspectRatio ),
      	-- height = aspectRatio < 1.5 and 480 or math.ceil( 320 * aspectRatio ),
      	-- scale = "letterBox",
		fps = 60,
	},
	license =
    {
        
    },
}

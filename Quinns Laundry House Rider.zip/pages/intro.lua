local scene_g
local scene = composer.newScene()
local completion_g

local function fade_welcome_screen(event)
	local path = system.pathForFile( "user_data.json", system.DocumentsDirectory )
	local app_data = io.open( path, "r" )
	
	if app_data then
		local user_data = app_data:read( "*a" )
		user_data = json.decode(user_data)

		user['id'] = user_data[1]
		user['user_name'] = user_data[2]
		user['password'] = user_data[2]
		user['first_name'] = user_data[4]
		user['last_name'] = user_data[5]
		user['address'] = user_data[6]
		user['mobile_no'] = user_data[7]
		
		if (on_simulator==false) then
			local json_data = '{"id":' .. user.id .. ',"token_id":"' .. user_token .. '"}'
        	network.request( host_url .. "ntfy_reg_device_rider/" .. json_data, "POST",  register_device_token)
		end
		
		app_data:close()
		composer.gotoScene("pages.booked")
	else
		composer.gotoScene("pages.login")
	end
end

local function load_complete(event)
	transition.fadeOut( completion_g, { time=500, onComplete=fade_welcome_screen } )
end

local function retry_init_connect(event)
	if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
			if(retry_ctr < 2) then
				retry_ctr = retry_ctr + 1
				--local json_data = '{"key":"' .. api_key .. '","id":"all"}'
				--network.request( host_url .. "services/" .. json_data, "GET",  get_services_list)
				network.request( host_url .. "get_shop", "GET",  get_shop_info)
			else
				change_page("pages.server_diverter", "slideLeft")
			end
        elseif ( i == 2 ) then
			os.exit()
        end
    end
end

local function force_close_app(event)
	if ( event.action == "clicked" ) then
		if ( event.index == 1 ) then
			os.exit()
		end
	end
end

local function get_services_list( event )
    if ( event.isError ) then
		native.showAlert( "Network error!", "Unable to connet to server!\nTry again?", { "Yes", "No" }, retry_init_connect)
    else
		res_data = json.decode(event.response)
		products_list = res_data
		if(res_data ~= "" and res_data ~= nil) then
			for i=1, #res_data do
				local index = res_data[i].id

				services_list[index] = {}
				services_list[index]['title'] = res_data[i].title
				services_list[index]['desc'] = res_data[i].description
				services_list[index]['price'] = res_data[i].price
				services_list[index]['qty'] = res_data[i].quantity
				services_list[index]['unit'] = res_data[i].unit
				services_list[index]['type'] = res_data[i].prod_type
				services_list[index]['stat'] = res_data[i].status
			end
			
			timer.performWithDelay(500, load_complete)
		elseif(res_data == nil) then
			native.showAlert( "Server suspended!", "Server currently suspended, please contact the administrator.", { "OK" }, force_close_app)
		else
			native.showAlert( "Server error!", "Unable to connet to server!\nTry again?", { "Yes", "No" }, retry_init_connect)
		end
    end
end

local function process_time_range(ind, val)
	local arr = split_string(val, '-')
	booking_dt[ind] = {}
	for i, part in ipairs(arr) do
    	booking_dt[ind][i] = part
	end
end

function get_shop_info( event )
    if ( event.isError ) then
		native.showAlert( "Network error!", "Unable to connet to server!\nTry again?", { "Yes", "No" }, retry_init_connect)
    else
		res_data = json.decode(event.response)
		process_time_range("Sunday", res_data[1].sunday)
		process_time_range("Monday", res_data[1].monday)
		process_time_range("Tuesday", res_data[1].tuesday)
		process_time_range("Wednesday", res_data[1].wednesday)
		process_time_range("Thursday", res_data[1].thursday)
		process_time_range("Friday", res_data[1].friday)
		process_time_range("Saturday", res_data[1].saturday)

		local json_data = '{"key":"' .. api_key .. '","id":"all"}'
		network.request( host_url .. "services/" .. json_data, "GET",  get_services_list)
	end
end

function scene:create( event )	
	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
    completion_g = display.newGroup()

	local img = create_image_sheet(0, 0, 392, 392, dsp_h*.22, dsp_h*.22, 1, "assets/images/quinns_logo.png")
	img.x = (dsp_w-img.width)*.5
	img.y = 0
	completion_g:insert(img)

	local img_sub = create_image_sheet(0, 0, 386, 395, dsp_h*.35, dsp_h*.35, 1, "assets/images/intro_image.png")
	img_sub.x = (dsp_w-img_sub.width)*.5
	img_sub.y = img.y+(img.height*1.1)
	completion_g:insert(img_sub)

	lbl = create_label(dsp_w*.15, img_sub.y+img_sub.height+20, dsp_w*.7, lbl_gfs_0, "Fast and Reliable Laundry", "center", {0,0,0,.8}, gfont_bold)
    completion_g:insert(lbl)

	lbl_sub = create_label(dsp_w*.1, lbl.y+lbl.height+20, dsp_w*.8, lbl_gfs_2, "Kusot-Free, Amoy crush-Ready", "center", {0,0,0,.8}, gfont_med)
    completion_g:insert(lbl_sub)
	
    completion_g.y = (dsp_h-completion_g.height)/2
	network.request( host_url .. "get_shop", "GET",  get_shop_info)

	scene_g:insert(bubble_bg)
	scene_g:insert(completion_g)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		if ( system.getInfo("platform") == "android" ) then
			native.setProperty( "androidSystemUiVisibility", "immersiveSticky" )
		end
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
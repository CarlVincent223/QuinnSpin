local scene_g
local scene = composer.newScene()
local form_g
local btn_back
local btn_cancel
local booking_tracks = {}
local booking_payments = {}
local lbl_page_title
local task_type
local b_id

local function close_booking(event)
    if(enable_act) then
        change_page("pages.booked", "slideRight")
    end
end

local function complete_task_result( event )
    processing_state({btn_cancel, btn_back}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "valid") then
            native.showAlert( "Notice", "Unable to cancel?", { "OK" })
        else
            change_page("pages.booked", "slideRight")
        end
    end
end

local function on_complete_task(event)
    if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
            local json_data = '{"key":"' .. api_key .. '","id":' .. cur_booking .. ',"bid":' .. b_id .. ',"task_type":"' .. task_type .. '","status":"Completed"}'
            processing_state({btn_cancel, btn_back}, false)
            network.request( host_url .. "set_rider_assigned/" .. json_data, "POST",  complete_task_result)
        elseif ( i == 2 ) then
			return false
        end
    end
end

local function cancel_booking(event)
    if(enable_act) then
        native.showAlert( "Confirmation!", "Are you sure you want to mark this booking as complete?", { "Yes", "No" }, on_complete_task)
    end
end

local function display_booking_details(booking_details)
    
    local gap_y = 10
    local services_g = display.newGroup()
    services_g.y = dsp_h*.15
    form_g:insert(services_g)

    local mgl = dsp_w*.08
    local start_y = 0
    local lbl

    task_type = booking_details['task_type']
    lbl = create_label(mgl, start_y, dsp_w*.9, lbl_gfs_1, "Task", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['task_type'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Name", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['client'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Contact", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['contact'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Address", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['pickup_loc'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Basket", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['quantity'], "left")
    services_g:insert(lbl)
    
    if(booking_details['status'] == "Completed") then
        lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Status", "left", txt_hl_blue1, gfont_med)
        services_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details['status'], "left")
        services_g:insert(lbl)
        sc_height = (lbl.y+lbl.height)+(dsp_h*0.2)
    else
        btn_cancel = create_button("complete","Complete", dsp_w*.7, btn_h, "roundedRect", lbl_gfs_2, btn_style_3, gfont_med, 5)
        btn_cancel.x = dsp_w*.15
        btn_cancel.y = lbl.y+(lbl.height*2)
        btn_cancel:addEventListener( "tap", cancel_booking )
        services_g:insert(btn_cancel)
        sc_height = (btn_cancel.y+btn_cancel.height)+(dsp_h*0.2)
    end

    sc_view:setScrollHeight(sc_height)
end

local function load_booking_details( event )
    processing_state({btn_back}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "") then
            arr = json.decode(res)
            display_booking_details(arr)
            b_id = arr['booking_id']
            lbl_page_title.text = set_code_format("QLH", arr['booking_id'], 5)
        end
    end
end

function scene:create( event )

    scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    local top_g = display.newGroup()

    local header_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(header_bg)

    lbl_page_title = create_label(0, 30, dsp_w, lbl_gfs_0*.9, "", "center", {1,1,1,1})
    lbl_page_title.y = ((dsp_h*.12)-(lbl_page_title.height+10))
    top_g:insert(lbl_page_title)

    local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 10
	btn_back.y = ((dsp_h*.12)-(btn_back.height+10))
	btn_back:addEventListener( "tap", close_booking )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	top_g:insert(btn_back)

    sc_view.x = 0
    sc_view.y = 0
    local form_bg = create_background(dsp_w*.05, lbl_page_title.y-10, dsp_w*.9, form_g.height*1.05, 25, {217/255,217/255,217/255,0})
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
    scene_g:insert( top_g )

    processing_state({btn_back}, false)
    local json_data = '{"key":"' .. api_key .. '","id":'..cur_booking..',"rider_id":'.. user.id ..'}'
	network.request( host_url .. "get_rider_task/" .. json_data, "GET",  load_booking_details)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
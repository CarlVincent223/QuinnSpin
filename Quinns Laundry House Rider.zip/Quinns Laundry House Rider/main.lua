-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

composer = require( "composer" )
widget = require("widget")
json = require("json")
calendar = require( "plugin.calendar" )
date = os.date( "*t" )
openssl = require( "plugin.openssl" )
cipher = openssl.get_cipher ( "aes-256-cbc" )
mime = require ( "mime" )
utf8 = require("plugin.utf8")
notifications = require("plugin.notifications.v2")
scrn_msg = require( "assist.screen_msg" )
scrn_msg_g = display.newGroup()
scrn_msg = scrn_msg.new({g=scrn_msg_g})
--ext_auth = require( "assist.third_party_auth" )
socket = require( "socket" )

require( "timer" )
require( "assist.methods" )
require( "assist.objects_generator" )
require( "assist.variables" )
--require( "assist.laundry_services" )
--require( "pages.slides" )


local function confirm_exit(event)
	if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
			os.exit()
        elseif ( i == 2 ) then
			return false
        end
    end
end

local function soft_keys_event( event )
    if ( event.keyName == "back" ) then
        if event.phase == "up" then
            native.setKeyboardFocus( nil )
            if(composer.getSceneName( "current" ) == "pages.booked") then
                return native.showAlert( "Confirmation!", "Are you sure you want to exit?", { "Yes", "No" }, confirm_exit)
            elseif(composer.getSceneName( "current" ) == "pages.login") then
                change_page("pages.booked", "slideLeft")
                return true
            else
                return true
            end
        end
    end
    return false
end

function register_device_token( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        print(event.response)
    end
end

local function close_popup_notification( event )
    network.request( host_url .. "clear_notification_rider/" .. user.id, "GET",  clear_notification_update)
end

function trigger_notification(event)
    if event.type == "remoteRegistration" then
        user_token = event.token
        composer.gotoScene("pages.intro")
        
    elseif event.type == "remote" then
        system.vibrate()
        
        local ntfy_data = event.custom
        ntfy_msg = ntfy_data['msg']

        if(event.applicationState == "active") then
            if(composer.getSceneName( "current" ) == "pages.booked") then
                native.showAlert(ntfy_data['title'], ntfy_msg, {"OK"}, close_popup_notification)
                reloading_content = true
                reload_user_bookings()
            else
                native.showAlert(ntfy_data['title'], ntfy_msg, {"OK"}, close_popup_notification)
            end
        else
            if(composer.getSceneName("current") ~= "pages.booked") then
	            change_page("pages.booked", "slideLeft")
            end
        end
    end
end

if (on_simulator==false) then
    Runtime:addEventListener("key", soft_keys_event)
    Runtime:addEventListener("notification", trigger_notification)

    local deviceToken = notifications.getDeviceToken()
    if deviceToken then
        user_token = deviceToken
        composer.gotoScene("pages.intro")
    else
        notifications.registerForPushNotifications()
    end
else
    composer.gotoScene("pages.intro")
end
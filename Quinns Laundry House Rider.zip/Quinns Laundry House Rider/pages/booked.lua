local scene_g
local scene = composer.newScene()

--local btn_back
local btn_add
local btn_profile

local slides = {}
local indc = {}
local indc_lbl = {}
local users_bookings = {}
local list_index = {}
local pos_y=20
local mutiplier = {}
local addon_dry = {}
local total_service_fee = {}
local total_addon_fee = {}
local msg_ntfy = {}
local msg_container_g = display.newGroup()
local cur_index = 1
local list_inc = 7
local list_range = list_inc
local remaining_task = 0

local function open_threads(event)
	if(enable_act) then
		cur_booking = event.target.id
		new_msg[cur_booking] = 0
		change_page("pages.threads", "slideLeft")
	end
end

local function open_booking(event)
	if(enable_act) then
		cur_booking = event.target.id
		change_page("pages.booking_details", "slideLeft")
	end
end

local function create_new(event)
	if(enable_act) then
		change_page("pages.profile", "slideLeft")
	end
end

local function create_booking_list(x, y, w, h, data, stat)
	h = lbl_gfs_0*5
	local booked_g = display.newGroup()
	local clr = nil
	clr = {0.9,0.9,0.9,1}
	--if(stat == "Cancelled") then
		--clr = {1,0.3,0.3,1}
	if(stat ~= "Completed") then
		remaining_task = remaining_task + 1
	--else
		--clr = {.2,.6,.3,1}
	end

	
	local clr_bg = {0.2, 0.5, 0.8, .4}
	local bg_cat = create_background(w*.05, 0, w, h, 10, clr)
	local bg_shadow = create_background(w*.06, w*.01, w, h, 10, clr_bg)
	
	m1 = bg_cat.width*.08
	local item_title = create_label(m1, bg_cat.y, w*.95, lbl_gfs_1, data['task'], "right", txt_hl_blue1, gfont_med)
	local item_id = create_label(m1, bg_cat.y, w*.95, lbl_gfs_1, set_code_format("QLH", data['bid'], 5), "left", txt_hl_blue1, gfont_med)
	local item_name = create_label(m1, item_title.y+item_title.height, w*.95, lbl_gfs_2, data['client'], "left", {.3,.3,.3,1}, gfont_med)
	local item_addr = create_label(m1, item_name.y+item_name.height, w*.95, lbl_gfs_2, data['address'], "left", {.3,.3,.3,1}, gfont_ita)
	
	booked_g.id = data['id']
	--booked_g:addEventListener( "tap", open_booking )
	booked_g:insert(bg_shadow)
	booked_g:insert(bg_cat)

	booked_g:insert(item_title)
	booked_g:insert(item_id)
	local tmp_h = item_title.height+item_name.height+item_addr.height
	bg_cat.height = tmp_h+(dsp_w*.1)
	bg_shadow.height = tmp_h+(dsp_w*.1)
	if(stat == "Completed") then
		bg_cat.height = tmp_h+(lbl_gfs_1*2)
		bg_shadow.height = tmp_h+(lbl_gfs_1*2)
		local service_stat = create_label(m1, 0, w*.9, lbl_gfs_1, stat, "left", {.2,.6,.3,1}, gfont_med)
		service_stat.y = bg_cat.height-(service_stat.height*1.2)
		booked_g:insert(service_stat)
	end

	local btn_icon = display.newImageRect("assets/images/message_env_dark.png", 35, 35)
	anchor(btn_icon)
	local btn_messages = create_button("message","", dsp_w*.1, dsp_w*.1, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.1)
	btn_messages.id = data['bid']
	btn_messages:addEventListener( "tap", open_threads )
	resize(btn_icon, btn_messages, 0.2)
	btn_messages:insert(btn_icon)
	btn_messages.x = booked_g.x+(booked_g.width*.90)
	btn_messages.y = booked_g.height-(dsp_w*.1)

	btn_icon = display.newImageRect("assets/images/eye_dark.png", 35, 35)
	anchor(btn_icon)
	local btn_view = create_button("view","", dsp_w*.1, dsp_w*.1, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.1)
	btn_view.id = data['id']
	btn_view:addEventListener( "tap", open_booking )
	resize(btn_icon, btn_messages, 0.2)
	btn_view:insert(btn_icon)
	btn_view.x = booked_g.x+(booked_g.width*.7)
	btn_view.y = booked_g.height-(dsp_w*.1)
	booked_g:insert(btn_view)
	booked_g:insert(btn_messages)

	booked_g:insert(item_name)
	booked_g:insert(item_addr)
	booked_g.y = pos_y
	pos_y = pos_y+booked_g.height+20

	msg_container_g:insert(booked_g)
end

local function load_booking_payments( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        --print(event.response, "<<")
    end
end

local function load_booking_tracks( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        --print(event.response)
        local filter_data = '{"id":' .. services_acquired['id'] .. ',"sort":"booking_id ASC"}'
	    network.request( host_url .. "get_booking_payments/" .. filter_data, "GET",  load_booking_payments)
    end
end

local function show_items( event )
	list_range = list_range + list_inc
	processing_state({btn_profile}, true)
	reload_user_bookings()
end

local function display_booked_list()
	remaining_task = 0
	for i=1, #list_index do
		create_booking_list(0, 0, dsp_w*.9, 0, users_bookings[list_index[i]], users_bookings[list_index[i]]['status'])
		if(i>=list_range) then
			break
		end
	end

	if(#list_index > list_range) then
		local btn_g = display.newGroup()
		local btn_bg = create_background(0, 0, dsp_w*.6, btn_h*.9, 20, {0.2, 0.5, 0.8, .4})
		local btn_lbl = create_label(0, 0, dsp_w, dsp_w*.05, "Show more", "center", {0.1,0.1,0.1,.8})
		btn_lbl.x = btn_bg.x+((btn_bg.width-btn_lbl.width)*.5)
		btn_lbl.y = (btn_bg.height-btn_lbl.height)*.5
		btn_g:insert(btn_bg)
		btn_g:insert(btn_lbl)
		btn_g.x = (dsp_w-btn_bg.width)*.5
		btn_g.y = pos_y
		btn_g:addEventListener( "tap", show_items )
		msg_container_g:insert(btn_g)
	end

	if(#list_index == 0) then
		local btn_lbl = create_label(0, 0, dsp_w, dsp_w*.05, "- No task history -", "center", {0,0,0,.8}, gfont_ita)
		btn_lbl.x = 0
		btn_lbl.y = pos_y
		msg_container_g:insert(btn_lbl)
	end

	lbl_points.text = remaining_task
		
	slides[1]:setScrollHeight(msg_container_g.height+30)
	slides[1]:insert(msg_container_g)
	
	processing_state({btn_profile}, true)
end

local function load_booking_details( event )
	reloading_content = false
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "") then
            local arr = json.decode(res)
			for i=1, #arr do
				users_bookings[arr[i].id] = {}
				users_bookings[arr[i].id]['id'] = arr[i].id
				users_bookings[arr[i].id]['bid'] = arr[i].booking_id
				users_bookings[arr[i].id]['task'] = arr[i].task_type
				users_bookings[arr[i].id]['client'] = arr[i].client
				users_bookings[arr[i].id]['address'] = arr[i].pickup_loc
				users_bookings[arr[i].id]['status'] = arr[i].status
				
				list_index[i] = arr[i].id
			end
        end
		
        display_booked_list()
    end
end

function reload_user_bookings()
	if(enable_act) then
		msg_container_g:removeSelf()
		msg_container_g = display.newGroup()
		pos_y = 20
		processing_state({btn_profile}, false)
		local json_data = '{"key":"' .. api_key .. '","id":"all","rider_id":'.. user.id ..'}'
		network.request( host_url .. "get_rider_task/" .. json_data, "GET",  load_booking_details)
	end
end

function navi_slides(event)
	if(event.target.id ~= cur_index) then
		indc[cur_index]:setState( { isOn=false } )
		indc_lbl[cur_index]:setFillColor(unpack(indc_clr))
		indc_lbl[event.target.id]:setFillColor(unpack(indc_hl_clr))
		
		slides[cur_index].x = dsp_w
		cur_index = event.target.id
		indc[cur_index]:setState( { isOn=true } )

		if(event.target.id == 4) then
			if(enable_act) then
				change_page("pages.profile", "slideLeft")
			end
		else
			slides[cur_index].x = 0
		end
	else
		indc[cur_index]:setState( { isOn=true } )
	end
end

local function display_points_home(event)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		lbl_points.text = trim_string(event.response)
	end
end

function scene:create( event )
	network.request( host_url .. "clear_notification_rider/" .. user.id, "GET",  clear_notification_update)

	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
	local top_g = display.newGroup()
    local form_g = display.newGroup()
	
	local top_bg = create_background(dsp_w*.015, dsp_w*.18, dsp_w*.97, dsp_h*.1, 10, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)

	local shop_icon = display.newImageRect("assets/images/quinns_logo.png", btn_h*1.4, btn_h*1.4)
	shop_icon.x = dsp_w-(shop_icon.width*1.2)
	shop_icon.y = 5
	anchor(shop_icon)
	top_g:insert(shop_icon)

	lbl_user = create_label(top_bg.x+5, 0, dsp_w*.5, lbl_gfs_2, "Hello, "..user.first_name, "left", {0,0,0,.8})
	lbl_user.y = top_bg.y-(lbl_user.height*1.4)
	top_g:insert(lbl_user)

	lbl = create_label(top_bg.x+20, lbl_user.y+lbl_user.height, dsp_w*.22, lbl_gfs_1, "Task:", "left", {1,1,1,1})
	lbl.y = top_bg.y+((top_bg.height-lbl.height))*.5
	lbl_points = create_label(lbl.x+lbl.width, lbl_user.y+lbl_user.height, dsp_w*.5, lbl_gfs_0, "0", "left", {1,1,1,1})
	lbl_points.y = top_bg.y+((top_bg.height-lbl_points.height)*.55)
	top_g:insert(lbl_points)
	top_g:insert(lbl)

	local btn_icon = display.newImageRect("assets/images/profile.png", 100, 100)
	anchor(btn_icon)
	btn_profile = create_button("profile","", top_bg.height*.8, top_bg.height*.8, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_profile.x = (top_bg.x+top_bg.width)-(btn_profile.width*1.2)
	btn_profile.y = top_bg.y+((top_bg.height-btn_profile.height)*.5)
	btn_profile:addEventListener( "tap", create_new )
	resize(btn_icon, btn_profile, 0.2)
	btn_profile:insert(btn_icon)
	top_g:insert(btn_profile)

	scene_g:insert(bubble_bg)

	local sc_view_h = dsp_h-top_g.height
	slides[1] = create_scroll_view(0, 0, dsp_w, sc_view_h-5, 0)
	slides[1].x = top_g.x
    slides[1].y = (top_bg.y+top_bg.height)

	local header_bg = create_background(0, 0, dsp_w, slides[1].y+5, 0, {0.2, 0.5, 0.8, .4})
	scene_g:insert(header_bg)
	scene_g:insert(slides[1])
	scene_g:insert(top_g)

	processing_state({btn_profile}, false)
	local json_data = '{"key":"' .. api_key .. '","id":"all","rider_id":'.. user.id ..'}'
	network.request( host_url .. "get_rider_task/" .. json_data, "GET",  load_booking_details)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
local scene_g
local scene = composer.newScene()
local form_g
local btn_g
local btn_back
local btn_logout
local row_y=20
local lbl_points

local function on_logout()
	local result, reason = os.remove( system.pathForFile( "user_data.json", system.DocumentsDirectory ) )
	if result then
		user = {}
		change_page("pages.login", "slideRight")
	else
		print( "File does not exist", reason )
	end
end

local function confirm_logout(event)
	if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
			on_logout()
        elseif ( i == 2 ) then
			return false
        end
    end
end

local function logout_account(event)
	if(enable_act) then
		native.showAlert( "Confirmation!", "Are you sure you want to logout this account?", { "Yes", "No" }, confirm_logout)
	end
end

local function return_page(event)
	if(enable_act) then
		change_page("pages.booked", "slideRight")
	end
end

local function open_popup(popup_name, params)
	local popup_effects =
	{
		isModal = true,
		effect = "fade",
		time = 100,
		params = params
	}
	composer.showOverlay( popup_name , popup_effects )
end

local profile = {}
profile['password'] = "Update Password"
profile['first_name'] = "Update First Name"
profile['last_name'] = "Update Last Name"
profile['user_name'] = "Update Email"
profile['mobile_no'] = "Update Contact #"
profile['address'] = "Update Address"
local profile_val = {}
     
local function edit_profile(event)
	local popup_params = {
		pop_type = event.target.id,
		title = profile[event.target.id],
		val = profile_val[event.target.id]
	}
	open_popup("assist.popup_list", popup_params)
end

local function create_list_item(x, w, h, text, align, txt_lbl, id)
	profile_val[id] = text

	local item_g = display.newGroup()
	item_g.x = x
	item_g.y = row_y
	local lbl_dummy = create_label( x, 0, w, h*.75, "W", align, {1,1,1,1})
	local lbl_inp = create_label( x-10, 0, w, h*.5, txt_lbl, "left", {1,1,1,1})
	local lbl = create_label( w*.05, 0, w*.9, h*.75, text, align, {1,1,1,1})
	local item_bg = create_background(0, 0, lbl.width+(w*.1), lbl.height+lbl_inp.height+10, 10, {0.2, 0.5, 0.8, .9})
	item_g:insert(item_bg)
	item_g:insert(lbl_inp)
	item_g:insert(lbl)
	--lbl.x = item_bg.x+5
	lbl.y = lbl_inp.y+lbl_inp.height
	
	lbl_dummy:removeSelf()
	item_g.id = id
	item_g:addEventListener( "tap", edit_profile )

	row_y = row_y+item_bg.height+10
	return item_g
end

local function load_user_profile(event)
	processing_state({btn_back, btn_logout}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
		if(res ~= "") then
			local user = json.decode(res)
			local m_gap = dsp_w*.05
			local item_w = dsp_w*.9
			local f_size = lbl_gfs_0
			form_g:insert(create_list_item(m_gap, item_w, f_size, user.user_name, "left", "User Name", "user_name"))
			form_g:insert(create_list_item(m_gap, item_w, f_size, "* * * * * * * *", "center", "Password", "password"))
			form_g:insert(create_list_item(m_gap, item_w, f_size, user.first_name, "left", "First Name", "first_name"))
			form_g:insert(create_list_item(m_gap, item_w, f_size, user.last_name, "left", "Last Name", "last_name"))
			form_g:insert(create_list_item(m_gap, item_w, f_size, user.mobile_no, "left", "Mobile #", "mobile_no"))
			form_g:insert(create_list_item(m_gap, item_w, f_size, user.address, "left", "Address", "address"))

			sc_view:setScrollHeight(row_y)
		end
	end
end

function scene:force_logout(event)
	on_logout()
end

function scene:force_update(event)
	change_page("pages.updating", "slideLeft")
end

function scene:hide_popup(event)
	
end

function scene:create( event )
	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    local top_g = display.newGroup()
    form_g = display.newGroup()

    local top_bg = create_background(0, 0, dsp_w, btn_h*1.5, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)
    local lbl_page_title = create_label(0, 5, dsp_w, 25, "", "center", {0,0,0,.8})
    top_g:insert(lbl_page_title)

    local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 20
	btn_back.y = (top_bg.height-btn_back.height)*.5
	btn_back:addEventListener( "tap", return_page )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	top_g:insert(btn_back)

	btn_icon = display.newImageRect("assets/images/logout.png", 100, 100)
	anchor(btn_icon)
	btn_logout = create_button("add","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_logout.x = dsp_w-(btn_logout.width+20)
	btn_logout.y = (top_bg.height-btn_back.height)*.5
	btn_logout:addEventListener( "tap", logout_account )
	resize(btn_icon, btn_logout, 0.2)
	btn_logout:insert(btn_icon)
	top_g:insert(btn_logout)
    
	local sc_view_h = dsp_h-top_g.height
	sc_view = create_scroll_view(0, 0, dsp_w, sc_view_h, 0)

	local fs_title = dsp_w*.07
	local gw1 = dsp_w*.1
	local gw2 = dsp_w*.55

	processing_state({btn_back, btn_logout}, false)
	network.request( host_url .. "get_riders/" .. user.id, "GET",  load_user_profile)
	
    sc_view.x = 0
    sc_view.y = 0
    top_g.y = dsp_h-top_g.height
    sc_view:insert( form_g )

	scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
    scene_g:insert(top_g)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
function create_button(obj_id, obj_lalbel, obj_w, obj_h, shape, font_size, fill_color, font, radius)
	if(radius == nil) then
		radius = 0
	end

	local btn = widget.newButton(
		{
			width = obj_w,
			height =  obj_h,
			id = obj_id,
			label = obj_lalbel,
			shape = shape,
            cornerRadius = radius,
			fontSize = font_size,
			fillColor = fill_color,
			labelColor = { default = btn_lbl_style_l, over = btn_lbl_style_d }
		}
	)
	anchor(btn)
	
	return btn
end

function create_label(pos_x, pos_y, width, size, text, txt_align, txt_clr, font)
	
	if(font == nil) then
		font = gfont_med
	end
	
	local txt_opt = 
	{
		text = text,
		width = width,
		font = font,   
		fontSize = size,
		align = txt_align
	}
	
	local txt_lbl = display.newText( txt_opt )
    txt_lbl.x = pos_x
    txt_lbl.y = pos_y
	anchor(txt_lbl)
	if(txt_clr == nil) then
		txt_lbl:setFillColor({0,0,0,1})
	else
		txt_lbl:setFillColor(txt_clr[1],txt_clr[2],txt_clr[3],txt_clr[4])
	end
	return txt_lbl
end

function create_input(lbl, gap, width, size, align, secure, input_type, placeholder)
    local inp = native.newTextField( lbl.x, lbl.y+(lbl.height*gap), width, size )
	inp.inputType = input_type
	inp.isSecure = secure
	inp.align = align
	inp.placeholder = placeholder
	anchor(inp)
	return inp
end

local function indc_btn_press(event)
	event.target:setState( { isOn=false } )
end

function create_btn_toggle(x, y, id, stat)
	local options = {
		width = 100,
		height = 100,
		numFrames = 2,
		sheetContentWidth = 200,
		sheetContentHeight = 100
	}
	local checkboxSheet = graphics.newImageSheet( "assets/images/icon_eye"..id..".png", options )
	
	local checkbox = widget.newSwitch(
		{
			style = "checkbox",
			id = id,
			width = 25,
			height = 20,
			sheet = checkboxSheet,
			frameOff = 1,
			frameOn = 2
		}
	)

	checkbox:setState( { isOn=stat } )
	anchor(checkbox)
	checkbox.x = x
	checkbox.y = y

	return checkbox
end

function create_checkbox(id, stat)
	local options = {
		width = 100,
		height = 100,
		numFrames = 2,
		sheetContentWidth = 200,
		sheetContentHeight = 100
	}
	local checkboxSheet = graphics.newImageSheet( "assets/images/radio_button.png", options )
	
	local checkbox = widget.newSwitch(
		{
			style = "checkbox",
			id = id,
			width = 25,
			height = 25,
			sheet = checkboxSheet,
			frameOff = 1,
			frameOn = 2
		}
	)
	anchor(checkbox)
	return checkbox
end


function create_radio_button(w, h, stat, slide_id)
	local options = {
		width = 100,
		height = 100,
		numFrames = 2,
		sheetContentWidth = 200,
		sheetContentHeight = 100
	}

	local radioSheet = graphics.newImageSheet( "assets/images/slides_img/slide"..slide_id.."_indc.png", options )
	local radio = widget.newSwitch(
		{
			style = "radio",
			width = w,
			height = h,
			onEvent = indc_btn_press,
			sheet = radioSheet,
			frameOff = 1,
			frameOn = 2
		}
	)
	
    radio:setState( { isOn=stat } )
	anchor(radio)

	return radio
end

function create_input_multiline(lbl, gap, width, height, size, placeholder)
	local inp
	if(lbl == nil) then
		inp = native.newTextBox( 0, 0, width, height )
	else
		inp = native.newTextBox( lbl.x, lbl.y+(lbl.height*gap), width, height )
	end

	inp.size = size
	inp.isEditable = true
	inp.placeholder = placeholder
	anchor(inp)
	return inp
end

home_slides_ctr = 1
local function reset_auto_scroll_slide(event)
	if event.phase == "moved" then
		home_slides_ctr = 1
    end
	
    if event.limitReached then
		if(composer.getSceneName( "current" ) == "pages.booked") then
			if(event.direction == "down" and reloading_content == false and event.target.y > 100) then
				reloading_content = true
				reload_user_bookings()
			end
		end
		--print("Scroll limit reached in direction: " .. event.direction)
    end
end

function create_scroll_view(top, left, width, height, scroll_width)
	local scrollView = widget.newScrollView(
		{
			top = top,
			left = left,
			width = width,
			height = height,
			scrollWidth = scroll_width,
			listener = reset_auto_scroll_slide
		}
	)
	
	scrollView._view._background:setFillColor(1, 1, 1, 0)
	scrollView:setIsLocked( true, "horizontal" )
	anchor(scrollView)
	return scrollView
end

function bg_scroll_view(top, left, width, height, scroll_width)
	local scrollView = widget.newScrollView(
		{
			top = top,
			left = left,
			width = width,
			height = height,
		}
	)
	
	scrollView._view._background:setFillColor(1, 1, 1, 0)
	scrollView:setIsLocked( true, "vertical" )
	anchor(scrollView)
	return scrollView
end

function create_background(x, y, width, height, radius, opacity)
    local bg = display.newRoundedRect( x, y, width, height, radius ) -- x, y, width, height, radius
    bg:setFillColor( opacity[1], opacity[2], opacity[3], opacity[4] )
	anchor(bg)
	return bg
end

function create_image_sheet(x, y, width, height, prc_w, prc_h, frames, src)
	-- Create the image sheet object
	local options =
	{
		width = width,
		height = height,
		numFrames = frames
	}
	local imageSheet = graphics.newImageSheet( src, options )
	
	-- Create new image from the above image sheet
	local img = display.newImageRect( imageSheet, 1, prc_w, prc_h )
	anchor(img)

	return img
end

function create_image(w, h, sca_x, sca_y, src)
	local img = display.newImageRect(src, w, h)
	local scaleX = sca_x / img.width
	local scaleY = sca_y / img.height
	local scaleFactor = math.min(scaleX, scaleY)
	img:scale(scaleFactor, scaleFactor)
	anchor(img)
	
	return img
end

function create_image_rec(x, y, w, h, src)
	local img = display.newImageRect(src, w, h)
	anchor(img)
    img.x = x
    img.y = y
	
	return img
end

function create_div_hline(x, y, w, h, tick, clr)
	local line = display.newLine( x, y, w, h )
	line:setStrokeColor( unpack(clr) )
	line.strokeWidth = tick
	
	return line
end

function std_page_background()
    local bg = display.newRoundedRect( 0,0,dsp_w,dsp_h,0 ) -- x, y, width, height, radius
    --bg:setFillColor( 174/255, 186/255, 218/255, 1 )
	bg:setFillColor( 1, 1, 1, 1 )
	anchor(bg)
	return bg
end

local sched_picker

function picker_selected(event)
	timer.performWithDelay( 100, function()
		local values = sched_picker:getValues()
	end )
end

function create_date_picker()
	-- Set up the picker wheel columns
	local index=1

	local col2 = {}
	for i=index, 31 do
		col2[i] = i
	end

	index=1
	local col3 = {}
	local col3b = {'AM','PM'}
	for j=1, 2 do
		for i=1, 12 do
			local str = ""
			if(i<10) then
				str = " "
			end
			col3[index] = str .. i .. ":00 " .. col3b[j]
			col3[index+1] = str .. i .. ":30 " .. col3b[j]
			index = index + 2
		end
	end

    local columnData =
    {
        {
            align = "left",
            width = dsp_w*.3,
            startIndex = tonumber(date.month),
            labels = { "January", "February", "March", "April","May","June","July","August","September","October","November","December" }
        },
        {
            align = "left",
            width = dsp_w*.2,
            labelPadding = 10,
            startIndex = tonumber(date.day),
            labels = col2
        },
        {
            align = "center",
			width = dsp_w*.3,
            labelPadding = 10,
            startIndex = 1,
            labels = col3
        }
    }
    
    -- Create the widget
    local pickerWheel = widget.newPickerWheel(
    {
        x = display.contentCenterX,
        top = display.contentHeight,
		width = dsp_w*.8,
        fontSize = 18,
        columns = columnData,
		style = "resizable",
		rowHeight = 25,
		onValueSelected = picker_selected
    })  
	anchor(pickerWheel)
    -- Get the table of current values for all columns
    -- This can be performed on a button tap, timer execution, or other event
    local values = pickerWheel:getValues()
    
    -- Get the value for each column in the wheel, by column index
    local currentStyle = values[1].value
    local currentColor = values[2].value
    local currentSize = values[3].value
    
    print( currentStyle, currentColor, currentSize )

	return pickerWheel
end

function get_day_index(ind)
	if(ind ~= nil) then
		return days_of_week[ind]
	else
		local sched_index
		if(services_acquired['sched'] == "Sunday") then
			sched_index = 1
		elseif(services_acquired['sched'] == "Monday") then
			sched_index = 2
		elseif(services_acquired['sched'] == "Tuesday") then
			sched_index = 3
		elseif(services_acquired['sched'] == "Wednesday") then
			sched_index = 4
		elseif(services_acquired['sched'] == "Thursday") then
			sched_index = 5
		elseif(services_acquired['sched'] == "Friday") then
			sched_index = 6
		elseif(services_acquired['sched'] == "Saturday") then
			sched_index = 7
		end

		return sched_index
	end
end

function create_schedule_picker()
	local sched_index
	if(services_acquired['sched'] == "Sunday") then
		sched_index = 1
	elseif(services_acquired['sched'] == "Monday") then
		sched_index = 2
	elseif(services_acquired['sched'] == "Tuesday") then
		sched_index = 3
	elseif(services_acquired['sched'] == "Wednesday") then
		sched_index = 4
	elseif(services_acquired['sched'] == "Thursday") then
		sched_index = 5
	elseif(services_acquired['sched'] == "Friday") then
		sched_index = 6
	elseif(services_acquired['sched'] == "Saturday") then
		sched_index = 7
	end

	if(sched_index == nil) then
		sched_index = date.wday
	end

	local mode_index = 1
	if(services_acquired['mode'] == "Drop off") then
		mode_index = 2
	end

    local columnData =
    {
        {
            align = "left",
            width = dsp_w*.5,
            startIndex = sched_index,
            labels = { "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" }
        },
		{
            align = "left",
            width = dsp_w*.3,
            startIndex = mode_index,
            labels = { "Pickup","Drop off" }
        }
    }
    
    sched_picker = widget.newPickerWheel(
    {
        x = display.contentCenterX,
        top = display.contentHeight,
		width = dsp_w*.8,
        fontSize = 18,
        columns = columnData,
		style = "resizable",
		rowHeight = 25,
		onValueSelected = picker_selected
    })  
	anchor(sched_picker)
    
	return sched_picker
end

function create_checkbox()
	-- Image sheet options and declaration
	local options = {
		width = 100,
		height = 100,
		numFrames = 2,
		sheetContentWidth = 202,
		sheetContentHeight = 100
	}
	local checkboxSheet = graphics.newImageSheet( "assets/images/check_box.png", options )
	
	-- Create the widget
	local checkbox = widget.newSwitch(
		{
			style = "checkbox",
			id = "Checkbox",
			width = 25,
			height = 25,
			--onPress = onSwitchPress,
			sheet = checkboxSheet,
			frameOff = 1,
			frameOn = 2
		}
	)
	anchor(checkbox)
	
	return checkbox
end
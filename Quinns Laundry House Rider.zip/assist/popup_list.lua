local composer = require( "composer" )
local scene = composer.newScene()
local pop_type
local inp1
local inp2
local inp3
local password_note
local btn_cancel
local btn_submit
local btn_close

local reset_session = false
local update_session = false
local pos_y = 0
local list_h = dsp_w*.13
local sel_val = ""

local lbl_show
local password_secured

local function show_password(event)
     if(password_secured) then
		password_secured = false
	else
		password_secured = true
	end
	inp1.isSecure = password_secured
	inp2.isSecure = password_secured
	inp3.isSecure = password_secured
end

local function hide_popup(event)
	composer.hideOverlay("popup_list")
end

local function init_hide_popup(event)
	if(enable_act) then
		transition.moveTo( scene_g, { y=0-scene_g.height, time=300, transition = easing.inExpo, onComplete=hide_popup } )
	end
end

local function update_account_info(event)
	processing_state({btn_cancel, btn_submit, btn_close}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		--print(trim_string(event.response), "<<")
		if(trim_string(event.response) == "valid") then
			if(pop_type == "password" or pop_type == "user_name") then
				reset_session = true	
			else
				update_session = true	
				if(pop_type == "first_name") then
					user['first_name'] = inp1.text
				elseif(pop_type == "last_name") then
					user['last_name'] = inp1.text
				elseif(pop_type == "address") then
					user['address'] = inp1.text
				elseif(pop_type == "mobile_no") then
					user['mobile_no'] = inp1.text
				end
				set_cache_account()
			end
			composer.hideOverlay("popup_list")
		else
			native.showAlert("Notice!", "Unable to update info!")
		end
    end
end

local function submit_profile_update(event)
	if(enable_act) then
		local json_data
		local str = "Invalid input!"
		local invalid_input = true

		if(pop_type == "first_name") then
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_riders", "field":"first_name", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		elseif(pop_type == "last_name") then
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_riders", "field":"last_name", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		elseif(pop_type == "password") then
			password_note.text = ""
			trim_obj(inp1)
			trim_obj(inp2)
			trim_obj(inp3)
			if(check_input_form({inp1.text, inp2.text, inp3.text})) then
				if(#(trim_string(inp2.text)) < 8) then
					password_note.text = "Minimum of 8 characters"
				elseif(inp2.text == inp3.text) then
					if(inp1.text == user.password) then
						invalid_input = false
						json_data = '{"table":"tbl_riders", "field":"password", "value":"'.. inp2.text ..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
					else
						str = "Invalid Old password!"
					end
				else
					str = "Password didn't match!"
				end
			end
		else
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_riders", "field":"'..pop_type..'", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		end
		
		if(invalid_input) then
			native.showAlert("Notice", str)
		else
			processing_state({btn_cancel, btn_submit, btn_close}, false)
			network.request( host_url .. "rider_update_field/" .. json_data, "POST",  update_account_info)
		end
	end
end

function scene:create( event )

	local params = event.params
	pop_type = params.pop_type
	
	local g1 = dsp_w*.07
	local g2 = dsp_w*.05
	local m1 = dsp_w*.05
	local fw1 = dsp_w*.9

	scene_g = self.view
	anchor(scene_g)
	
	local cover_bg = std_page_background()
	scene_g:insert(cover_bg)
	local top_g = display.newGroup()
	local top_bg = create_background(0, 0, dsp_w, btn_h, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)

	local btn_icon = display.newImageRect("assets/images/slideup.png", 100, 100)
	anchor(btn_icon)
	btn_close = create_button("add","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_close.x = (dsp_w*.5)-(btn_close.width*.5)
	btn_close.y = (top_bg.height-btn_close.height)*.5
	btn_close:addEventListener( "tap", init_hide_popup )
	resize(btn_icon, btn_close, 0.2)
	btn_close:insert(btn_icon)
	top_g:insert(btn_close)

	local form_g = display.newGroup()
	local btn_g = display.newGroup()
	local btn_pos_y = 0

	btn_cancel = create_button("cancel","Cancel", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
	btn_cancel.x = (dsp_w*.25)-(btn_cancel.width*.5)
	btn_cancel.y = 0
	btn_cancel:addEventListener( "tap", init_hide_popup )
	btn_g:insert(btn_cancel)

	btn_submit = create_button("submit","Submit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
	btn_submit.x = (dsp_w*.75)-(btn_cancel.width*.5)
	btn_submit.y = btn_cancel.y
	btn_submit:addEventListener( "tap", submit_profile_update )
	btn_g:insert(btn_submit)

	if(pop_type == "password") then
		password_secured = true

		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Old Password", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "Old Password")
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		lbl_show = create_btn_toggle(0, 0, 2, true)
		lbl_show.x = inp1.x+(inp1.width-lbl_show.width)
		lbl_show.y = lbl.y+((lbl.height-lbl_show.height)*.5)
		lbl_show:addEventListener( "tap", show_password )
		form_g:insert(lbl_show)

		lbl = create_label(m1, inp1.y+inp1.height+g1, fw1, lbl_gfs_2, "New Password", "left", {0,0,0,1})
		inp2 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "New Password")
		inp2.x = lbl.x
		inp2.y = lbl.y+lbl.height
		password_note = create_label(m1, inp2.y+(inp2.height*1.05), fw1, lbl_gfs_3, "", "left", {1,0.1,0,1})
		form_g:insert(lbl)
		form_g:insert(password_note)
		form_g:insert(inp2)

		lbl = create_label(m1, inp2.y+inp2.height+g1, fw1, lbl_gfs_2, "Re-entry Password", "left", {0,0,0,1})
		inp3 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "Re-entry Password")
		inp3.x = lbl.x
		inp3.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp3)
		btn_pos_y = inp3.y+inp3.height+g2

	elseif(pop_type == "first_name") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "First Name", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "First Name")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "last_name") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Last Name", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "Last Name")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "user_name") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "User Name", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "User Name")
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "mobile_no") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Mobile #", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "Mobile #")
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "address") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Address", "left", {0,0,0,1})
		inp1 = create_input_multiline(lbl, 1, fw1, dsp_h*.2, inp_gfs_5, "Address")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2
	end

	form_g.y = 0
	btn_g.y = btn_pos_y
	top_g.y = dsp_h-top_g.height

	scene_g:insert(top_g)
	scene_g:insert(form_g)
	scene_g:insert(btn_g)

	if(pop_type ~= "mode_sched" and pop_type ~= "dt_sched") then
		--lbl_page_title.text = ""
		scene_g.y = 0-scene_g.height
		transition.moveTo( scene_g, { y=0, time=300, transition = easing.inExpo } )
	else
		top_g.alpha=0
	end
end

function scene:show( event )
	--local scene_g = self.view
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
    --local sceneGroup = self.view
    local phase = event.phase
    local parent = event.parent  -- Reference to the parent scene object
    if ( phase == "will" ) then
		if(reset_session) then
			parent:force_logout()
		elseif(update_session) then
			parent:force_update()
		else
        	parent:hide_popup(sel_val, pop_type)
		end
    end
end

function scene:destroy( event )
	if(inp1 ~= nil) then
		inp1:removeSelf()
	end
	if(inp2 ~= nil) then
		inp2:removeSelf()
	end
	if(inp3 ~= nil) then
		inp3:removeSelf()
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
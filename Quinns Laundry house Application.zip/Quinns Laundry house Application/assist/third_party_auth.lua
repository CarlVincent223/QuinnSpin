local facebook = require( "plugin.facebook.v4a" )
 
-- Check for a value inside the provided table
local function valueInTable( t, valueToFind )
    for k,v in pairs( t ) do
        if v == valueToFind then
            return true
        end
    end
    return false
end
 
local function genericFacebookLogin( event )
    local fbData = json.decode(response)
    native.showAlert("Notice", fbData, {"OK"})
    fb_data = fbData
end
 
-- This listener will handle the request of read-only permissions, then request publishable permissions
local function intermediateFacebookLogin( event )
 
    if ( "session" == event.type ) then
        if ( "login" == event.phase ) then
            local accessToken = facebook.getCurrentAccessToken()
            
            -- Continue only if the user granted the read-only permissions
            if ( valueInTable( accessToken.grantedPermissions, "user_events" ) ) then
                facebook.login( genericFacebookLogin, { "publish_actions" } )
            else
                print( "The user did not grant the read-only permissions" )
            end
        end
    end
end

local function listener(event)
    if event.type == 'session' then
        if event.phase == 'login' then
            fbToken = event.token
            fbStatus = 'profile'
            facebook.request('me','GET', {fields="id,email,name"})
        end
    elseif event.type == 'request' then
        local response = event.response
        native.showAlert("Notice", response, {"OK"})
        fb_data = response
    end
end
 
local function facebookListener( event )
    if ( "fbinit" == event.name ) then
        print( "Facebook initialized" )
        facebook.login( listener, {"public_profile", "email" } )
    end
end

function fb_login(event)
    
end

function google_login(event)

end
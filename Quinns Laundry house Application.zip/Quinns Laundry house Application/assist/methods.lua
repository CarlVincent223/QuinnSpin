function encrypt_pass(val)
	return trim_string(mime.b64(cipher:encrypt(val, "lonlonx" )))
end

function anchor(obj)
	if(obj ~= nil) then
		obj.anchorX = 0
		obj.anchorY = 0
	end
end

function get_day_name(val)
	local dateString = val
	local year, month, day = dateString:match("(%d+)%-(%d+)%-(%d+)")
	local timeInSeconds = os.time({year = year, month = month, day = day, hour = 0, min = 0, sec = 0})

	local weekdayName = os.date("%A", timeInSeconds)
	return weekdayName
end

function get_radius_distance(pointX, pointY)
    local dx = pointX - shop_map['lat']
    local dy = pointY - shop_map['lng']
    local radius = math.sqrt(dx * dx + dy * dy)
    return radius
end

function clear_notification_update(event)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		print(event.response)
    end
end

function get_sched_date(cur_date, dw)
	local dateString = cur_date
	local year, month, day = dateString:match("(%d+)%-(%d+)%-(%d+)")
	local timeInSeconds = os.time({year = year, month = month, day = day, hour = 0, min = 0, sec = 0})
	local d_ind = os.date("%w", timeInSeconds)+1

	if(d_ind >= dw) then
		d_ind = 7-math.abs(d_ind-dw)
		timeInSeconds = timeInSeconds + (d_ind*86400)
	else
		d_ind = dw - d_ind
		timeInSeconds = timeInSeconds + (d_ind*86400)
	end
	
	return os.date("%Y-%m-%d", timeInSeconds)
end

function processing_state(targets, cnd)
	for i=1, table.maxn(targets) do
		targets[i]:setEnabled(cnd)
		enable_act = cnd
		if(cnd) then
			targets[i].alpha = 1
		else
			targets[i].alpha = .7
		end
	end
end

function string.urlEncode(str)
    if (str) then
        str = string.gsub(str, "\n", "\r\n")
        str = string.gsub(str, "([^%w ])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
    end
    return str
end

function validate_email(email)
	if (email:match("[A-Za-z0-9%.%%%+%-]+@[A-Za-z0-9%.%%%+%-]+%.%w%w%w?%w?")) then
		return true
	else
		return false
	end
    -- local pattern = "^[a-zA-Z0-9%.%-_]+@[a-zA-Z0-9%.%-_]+%.[a-zA-Z]{2,}$"
	-- --local pattern = "^[%w%._%+-]+@[%w%-]+%.%a%a%a?%a?$"
    -- if string.match(email, pattern) then
    --     return true
    -- else
    --     return false
    -- end
end

function check_input_form(targets)
	local valid = true
	for i=1, table.maxn(targets) do
		if(targets[i] == "") then
			valid = false
		end
	end
	
	return valid
end

function clear_spaces(val)
	local str=""
	for i = 1, #val do
		local byteValue = string.byte(val, i)
		if(byteValue ~= 32) then
			str = str .. val.char(byteValue)
		end
	end
	
	return str
end

function trim_obj(obj)
	local val = obj.text
	val = val:gsub("[\n\r]", "")
	val = val:gsub("^%s*(.-)%s*$", "%1")
	obj.text = val

	return val
end

function trim_string(val)
	val = string.gsub(val, "[\n\r]", "")
	val = val:gsub("^%s*(.-)%s*$", "%1")
	
	return val
end

function split_string(str, delimiter)
    local result = {}
    local startIndex = 1
    local endIndex

    while true do
        endIndex = string.find(str, delimiter, startIndex, true)
        if endIndex then
            table.insert(result, string.sub(str, startIndex, endIndex - 1))
            startIndex = endIndex + string.len(delimiter)
        else
            table.insert(result, string.sub(str, startIndex))
            break
        end
    end
    return result
end

function force_capital_letter(val)
	if(val == nil) then
		val = ""
	end

	local firstLetter = string.sub(val, 1, 1)
  	local capitalizedFirst = string.upper(firstLetter)
	result = string.sub(val, 2, string.len(val))

	return capitalizedFirst .. result
end

function mod_input_format( event )
    if ( "editing" == event.phase ) then
        event.target.text = force_capital_letter(event.target.text)
	elseif ( "ended" == event.phase) then
		event.target.text = force_capital_letter(trim_string(event.target.text))
    end
end

function set_code_format(code, num, max_len)
	num = tostring(num)
	local ctr = string.len(num)
	local res = ""
	while ctr <= max_len do
		res = res .. "0"
		ctr = ctr + 1
	end
	
	return code..res..num
end

function get_day_str(str_date)
	local tmp_arr = split_string(str_date, "-")
	local dateTable = {year = tmp_arr[1], month = tonumber(tmp_arr[2]), day = tonumber(tmp_arr[3])}
    local timestamp = os.time(dateTable)
    local fullDayName = os.date("%A", timestamp)

	return fullDayName
end

function set_datetime_format(val, dt_type)
	local mm_ind = {} --{"Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12"}
	mm_ind['Jan'] = "01"
	mm_ind['Feb'] = "02"
	mm_ind['Mar'] = "03"
	mm_ind['Apr'] = "04"
	mm_ind['May'] = "05"
	mm_ind['Jun'] = "06"
	mm_ind['Jul'] = "07"
	mm_ind['Aug'] = "08"
	mm_ind['Sep'] = "09"
	mm_ind['Oct'] = "10"
	mm_ind['Nov'] = "11"
	mm_ind['Dec'] = "12"
	
	local parse_date = split_string(val,' ')
	print("<>",#parse_date)
	if(#parse_date > 2) then
	
		val = parse_date[4].."-"..mm_ind[parse_date[3]].."-"..parse_date[2].." "..parse_date[5]
	end
	local str = ""
	local time_sym = ""
	local time_sym = ""
	local mm_arr = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"}

	if(dt_type == "datetime") then
		local yr, mm, dd, hr, mn, sc = val:match("(%d+)%-(%d+)%-(%d+) (%d+)%:(%d+)%:(%d+)")
		mm = tonumber(mm)
		dd = tonumber(dd)
		hr = tonumber(hr)
		mn = tonumber(mn)
		sc = tonumber(sc)

		if(mn<10) then
			mn = "0"..tostring(mn)
		end

		if(hr == 12) then
			time_sym = "nn"
		elseif(hr > 12) then
			hr = hr - 12
			time_sym = "pm"
		else
			time_sym = "am"
		end
		str = mm_arr[mm] ..". ".. dd ..", ".. yr .." ".. hr ..":".. mn .. time_sym
	elseif(dt_type == "date") then
		local yr, mm, dd = val:match("(%d+)%-(%d+)%-(%d+)")
		mm = tonumber(mm)
		dd = tonumber(dd)
		
		str = mm_arr[mm] ..". ".. dd ..", ".. yr
	else
		local hr, mn, sc = val:match("(%d+)%:(%d+)%:(%d+)")
		hr = tonumber(hr)
		mn = tonumber(mn)
		sc = tonumber(sc)

		if(mn<10) then
			mn = "0"..tostring(mn)
		end
		
		if(hr == 12) then
			time_sym = "nn"
		elseif(hr > 12) then
			hr = hr - 12
			time_sym = "pm"
		else
			time_sym = "am"
		end
		str = hr ..":".. mn .. time_sym
	end

	return str
end

function set_cache_account()
	local path = system.pathForFile( "user_data.json", system.DocumentsDirectory )
	local file, errorString = io.open( path, "w" )
	
	if file then
		local saveData = "["
		saveData = saveData .. "\"" .. user.id .. "\","
		saveData = saveData .. "\"" .. user.password .. "\","
		saveData = saveData .. "\"" .. user.first_name .. "\","
		saveData = saveData .. "\"" .. user.last_name .. "\","
		saveData = saveData .. "\"" .. user.address .. "\","
		saveData = saveData .. "\"" .. user.mobile_no .. "\""
		saveData = saveData .. "]"
		file:write( saveData )
		io.close( file )
	else
		print( "File error: " .. errorString )
	end
end

function network_error()
	native.showAlert("Notice","Unable to communicate to server.",{"OK"})
end

function resize(obj1, obj2, pad)
	if(obj1.width > obj2.width or obj1.height > obj2.height) then
		if(obj2.width > obj2.height) then
			local temp_obj1_h = obj1.height
			obj1.height = obj2.height - obj2.height*pad
			obj1.width = obj1.width * (obj1.height/temp_obj1_h)
		else
			
			local temp_obj1_w = obj1.width
			obj1.width = obj2.width - obj2.width*pad
			obj1.height = obj1.height * (obj1.width/temp_obj1_w)
		end
		
	else
		local temp_obj1_h = obj1.height
		obj1.height = obj2.height - (obj2.height*pad)
		obj1.width = obj1.width+(obj1.width*((obj1.height-temp_obj1_h)/obj1.height))
	end
	
	anchor(obj1)
	obj1.x = (obj2.width-obj1.width)*.5
	obj1.y = (obj2.height-obj1.height)*.5
end

-- Pagination
function change_page(page_name, direction)
	current_page = page_name
	prev_page = composer.getSceneName( "current" )
	composer.removeScene(prev_page)
    composer.gotoScene(current_page, direction, page_change)
end

function revert_page()
	composer.removeScene(current_page)
    composer.gotoScene(prev_page, "slideRight", page_change)
end
-- Pagination
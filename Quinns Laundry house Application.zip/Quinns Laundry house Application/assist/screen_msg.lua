
local M = {}
local g_dsp

function fade_message_screen(event)
    g_dsp:removeSelf()
    g_dsp = nil
end

function show_message_screen(event)
    transition.fadeOut( g_dsp, { time=1000, onComplete=fade_message_screen } )
end

function hang_message(event)
    timer.performWithDelay(1000, show_message_screen)
end

function display_message(event)
    transition.moveTo( g_dsp, { y=dsp_h*.1, time=500, transition = easing.inExpo, onComplete=hang_message } )
end

function M.new( params )
	local loader = display.newGroup()
	params.g:insert(loader)
    
    function loader:show(msg)
        g_dsp = display.newGroup()
        local bg = display.newRoundedRect( 0, 0, 150, 42, 12 ) -- x, y, width, height
        bg:setFillColor( 0.2, 0.5, 0.8, .4 ) -- Set fill color (R, G, B)
    	local scrn_msg = create_label(0, 0, 0, 22, msg, "center")
        g_dsp:insert(bg)
        g_dsp:insert(scrn_msg)
        bg.width = scrn_msg.width*1.2
        bg.y = -10
        bg.x = 0
        scrn_msg.x = (bg.width-scrn_msg.width)*.5
        g_dsp.y = 0-bg.height
        g_dsp.x = (dsp_w-bg.width)*.5
        anchor(bg)
        params.g:insert(g_dsp)
        
        timer.performWithDelay(100, display_message)
    end

    function loader:hide()
    	print ("Hide message!")
    	scrn_msg:removeSelf()
        scrn_msg = nil
    end

    return loader
end

return M
local chk_box_var = {}

function reset_services_acquired()
    services_acquired['full_service-1'] = false
    services_acquired['full_service-2'] = false
    services_acquired['comforter-3'] = false
    services_acquired['self_service-4'] = false
    services_acquired['self_service-5'] = false
    services_acquired['self_service-6'] = false
    services_acquired['self_service-7'] = false
    services_acquired['addon_drymin-5'] = false
    services_acquired['addon_fold-1'] = false
    services_acquired['addon_plastic-2'] = false
    services_acquired['addon_detergent-3'] = false
    services_acquired['addon_fabcon-4'] = false
    services_acquired['id'] = ""
    services_acquired['qty'] = ""
    services_acquired['sched'] = ""
    services_acquired['mode'] = ""
    services_acquired['client'] = ""
    services_acquired['contact'] = ""
    services_acquired['addr'] = ""

    services_acquired['sched_date'] = ""

    services_acquired['services_title'] = ""
    services_acquired['services_availed'] = ""
    services_acquired['qty'] = 1
    services_acquired['notes'] = ""
end

local function clear_full_service()
    services_acquired['full_service-1'] = false
    services_acquired['full_service-2'] = false
    chk_box_var['fs-1']:setState( { isOn=false, isAnimated=false } )
    chk_box_var['fs-2']:setState( { isOn=false, isAnimated=false } )
end

local function clear_comforter_service()
    services_acquired['comforter-3'] = false
    chk_box_var['c-3']:setState( { isOn=false } )
end

local function clear_self_service()
    services_acquired['self_service-4'] = false
    services_acquired['self_service-5'] = false
    services_acquired['self_service-6'] = false
    services_acquired['self_service-7'] = false
    services_acquired['addon_fold-1'] = false
    services_acquired['addon_plastic-2'] = false
    services_acquired['addon_detergent-3'] = false
    services_acquired['addon_fabcon-4'] = false
    services_acquired['addon_drymin-5'] = false
    chk_box_var['ss-4']:setState( { isOn=false } )
    chk_box_var['ss-5']:setState( { isOn=false } )
    chk_box_var['ss-6']:setState( { isOn=false } )
    chk_box_var['ss-7']:setState( { isOn=false } )

    chk_box_var['aod-5']:setState( { isOn=false } )
    chk_box_var['ao-1']:setState( { isOn=false, isAnimated=false } )
    chk_box_var['ao-2']:setState( { isOn=false, isAnimated=false } )
    chk_box_var['ao-3']:setState( { isOn=false } )
    chk_box_var['ao-4']:setState( { isOn=false } )
end

local function clear_self_service2()
    services_acquired['addon_fold-1'] = false
    services_acquired['addon_plastic-2'] = false
    services_acquired['addon_detergent-3'] = false
    services_acquired['addon_fabcon-4'] = false
    
    chk_box_var['ao-1']:setState( { isOn=false, isAnimated=false } )
    chk_box_var['ao-2']:setState( { isOn=false, isAnimated=false } )
    chk_box_var['ao-3']:setState( { isOn=false } )
    chk_box_var['ao-4']:setState( { isOn=false } )
end

local function clear_self_service3()
    services_acquired['self_service-4'] = false
    services_acquired['self_service-5'] = false
    services_acquired['self_service-6'] = false
    services_acquired['self_service-7'] = false
    services_acquired['addon_drymin-5'] = false
    chk_box_var['ss-4']:setState( { isOn=false } )
    chk_box_var['ss-5']:setState( { isOn=false } )
    chk_box_var['ss-6']:setState( { isOn=false } )
    chk_box_var['ss-7']:setState( { isOn=false } )
    chk_box_var['aod-5']:setState( { isOn=false } )
end

local function onSwitchPress( event )
    local switch = event.target
    services_acquired[switch.id] = switch.isOn
    
    if(switch.cat == "fs") then
        if(switch.isOn) then
            --clear_comforter_service()
            clear_self_service3()
            if(switch.id == "full_service-1") then
                services_acquired['full_service-2'] = false
                chk_box_var['fs-2']:setState( { isOn=false } )
            else
                services_acquired['full_service-1'] = false
                chk_box_var['fs-1']:setState( { isOn=false } )
            end
        else
            clear_full_service()
        end
    end

    if(switch.cat == "c") then
        if(switch.isOn) then
            --clear_full_service()
            clear_self_service3()
        else
            clear_self_service2()
        end
    end

    if(switch.cat == "ss" or switch.cat == "ao") then
        if(switch.isOn) then
        
            if(switch.cat ~= "ao") then
                clear_full_service()
                clear_comforter_service()
            end

            if(switch.id == "self_service-4") then
                services_acquired['self_service-5'] = false
                chk_box_var['ss-5']:setState( { isOn=false } )
            elseif(switch.id == "self_service-5") then
                services_acquired['self_service-4'] = false
                chk_box_var['ss-4']:setState( { isOn=false } )
            elseif(switch.id == "self_service-6") then
                services_acquired['self_service-7'] = false
                chk_box_var['ss-7']:setState( { isOn=false } )
            elseif(switch.id == "self_service-7") then
                services_acquired['self_service-6'] = false
                chk_box_var['ss-6']:setState( { isOn=false } )
            end
        else
            if(switch.id == "self_service-6" or switch.id == "self_service-7") then
                services_acquired['addon_drymin-5'] = false
                chk_box_var['aod-5']:setState( { isOn=false } )
            end
        end
    end   

    if(switch.cat == "aod") then
        if(switch.isOn) then
            if(services_acquired['self_service-6'] or services_acquired['self_service-7']) then
                services_acquired['addon_drymin-5'] = true
                chk_box_var['aod-5']:setState( { isOn=true } )
            else
                services_acquired['addon_drymin-5'] = false
                chk_box_var['aod-5']:setState( { isOn=false } )
            end
        end
    end
    
end

function services_checkbox(id, cat)
	-- Image sheet options and declaration
	local options = {
		width = 100,
		height = 100,
		numFrames = 2,
		sheetContentWidth = 202,
		sheetContentHeight = 100
	}
	local checkboxSheet = graphics.newImageSheet( "assets/images/check_box.png", options )
	
	-- Create the widget
	local checkbox = widget.newSwitch(
		{
			--left = 250,
			--top = 200,
			style = "checkbox",
			id = id,
			width = 25,
			height = 25,
			onPress = onSwitchPress,
			sheet = checkboxSheet,
			frameOff = 1,
			frameOn = 2
		}
	)
    checkbox:setState( { isOn=services_acquired[id] } )
    checkbox.cat = cat
	anchor(checkbox)
	
	return checkbox
end

function create_services_list()
    local services_g = display.newGroup()
    services_g.y = tmp_y
    local gap_y = 10

    local bg_cat = create_background(-10, 0, dsp_w*.7, 30, 10, {0,0,0,1})
    services_g:insert(bg_cat)
    local lbl_cat = create_label(0, 0, dsp_w*.8, 22, "Full Service", "left", {1,1,1,1}, gfont_med)
    lbl_cat.x = dsp_w*.1
    lbl_cat.y = 0
    services_g:insert(lbl_cat)
    local chk_box = services_checkbox("full_service-1", "fs")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl_cat.y+lbl_cat.height+gap_y
    services_g:insert(chk_box)
    local lbl_posx = chk_box.x+(chk_box.width*1.2)
    local lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['full_service-1']['sub_title'].."..... P"..services_list['full_service-1']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['full_service-1']['desc'], "left", nil, gfont_reg)
    services_g:insert(lbl)
    chk_box_var['fs-1'] = chk_box

    chk_box = services_checkbox("full_service-2", "fs")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['full_service-2']['sub_title'].."..... P"..services_list['full_service-2']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['full_service-2']['desc'], "left", nil, gfont_reg)
    services_g:insert(lbl)
    chk_box_var['fs-2'] = chk_box

    bg_cat = create_background(-10, lbl.y+lbl.height+gap_y, dsp_w*.7, 30, 10, {0,0,0,1})
    services_g:insert(bg_cat)
    lbl_cat = create_label(0, 0, dsp_w*.8, 22, "Comforters", "left", {1,1,1,1}, gfont_med)
    lbl_cat.x = dsp_w*.1
    lbl_cat.y = lbl.y+lbl.height+gap_y
    services_g:insert(lbl_cat)
    chk_box = services_checkbox("comforter-3", "c")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl_cat.y+lbl_cat.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['comforter-3']['sub_title'].."..... P"..services_list['comforter-3']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['comforter-3']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['c-3'] = chk_box

    bg_cat = create_background(-10, lbl.y+lbl.height+gap_y, dsp_w*.7, 30, 10, {0,0,0,1})
    services_g:insert(bg_cat)
    lbl_cat = create_label(0, 0, dsp_w*.8, 22, "Self Service", "left", {1,1,1,1}, gfont_med)
    lbl_cat.x = dsp_w*.1
    lbl_cat.y = lbl.y+lbl.height+gap_y
    services_g:insert(lbl_cat)

    local bg_subcat = create_background(-10, lbl_cat.y+lbl_cat.height+gap_y, dsp_w*.7, 22, 10, {62/255,94/255,105/255,1})
    services_g:insert(bg_subcat)
    local lbl_subcat = create_label(0, 0, dsp_w*.8, 14, "Wash (Min of 4 kg, max 7 kg)", "left", {1,1,1,1}, gfont_med)
    lbl_subcat.x = dsp_w*.1
    lbl_subcat.y = lbl_cat.y+lbl_cat.height+gap_y
    services_g:insert(lbl_subcat)

    chk_box = services_checkbox("self_service-4", "ss")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl_subcat.y+lbl_subcat.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['self_service-4']['sub_title'].."..... P"..services_list['self_service-4']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['self_service-4']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ss-4'] = chk_box

    chk_box = services_checkbox("self_service-5", "ss")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 20, services_list['self_service-5']['sub_title'].."..... P"..services_list['self_service-5']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['self_service-5']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ss-5'] = chk_box

    bg_subcat = create_background(-10, lbl.y+lbl.height+gap_y, dsp_w*.7, 22, 10, {62/255,94/255,105/255,1})
    services_g:insert(bg_subcat)
    lbl_subcat = create_label(0, 0, dsp_w*.8, 14, "Dry (Min of 4 kg, max 7 kg)", "left", {1,1,1,1}, gfont_med)
    lbl_subcat.x = dsp_w*.1
    lbl_subcat.y = lbl.y+lbl.height+gap_y
    services_g:insert(lbl_subcat)

    chk_box = services_checkbox("self_service-6", "ss")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl_subcat.y+lbl_subcat.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['self_service-6']['sub_title'].."..... P"..services_list['self_service-6']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['self_service-6']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ss-6'] = chk_box

    chk_box = services_checkbox("self_service-7", "ss")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, services_list['self_service-7']['sub_title'].."..... P"..services_list['self_service-7']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, services_list['self_service-7']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ss-7'] = chk_box

    chk_box = services_checkbox("addon_drymin-5", "aod")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, addons_list['addon_drymin-5']['title'].."..... P"..addons_list['addon_drymin-5']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(lbl_posx, lbl.y+lbl.height, dsp_w*.8, 17, addons_list['addon_drymin-5']['desc'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['aod-5'] = chk_box

    bg_cat = create_background(-10, lbl.y+lbl.height+gap_y, dsp_w*.7, 30, 10, {0,0,0,1})
    services_g:insert(bg_cat)
    lbl_cat = create_label(0, 0, dsp_w*.8, 22, "Others (Add-on)", "left", {1,1,1,1}, gfont_med)
    lbl_cat.x = dsp_w*.1
    lbl_cat.y = lbl.y+lbl.height+gap_y
    services_g:insert(lbl_cat)

    chk_box = services_checkbox("addon_fold-1", "ao")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl_cat.y+lbl_cat.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, addons_list['addon_fold-1']['desc'].."..... P"..addons_list['addon_fold-1']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ao-1'] = chk_box

    chk_box = services_checkbox("addon_plastic-2", "ao")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, addons_list['addon_plastic-2']['desc'].."..... P"..addons_list['addon_plastic-2']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ao-2'] = chk_box

    chk_box = services_checkbox("addon_detergent-3", "ao")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, addons_list['addon_detergent-3']['desc'].."..... P"..addons_list['addon_detergent-3']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ao-3'] = chk_box

    chk_box = services_checkbox("addon_fabcon-4", "ao")
    chk_box.x = dsp_w*.12
    chk_box.y = lbl.y+lbl.height+gap_y
    services_g:insert(chk_box)
    lbl = create_label(lbl_posx, chk_box.y, dsp_w*.8, 20, addons_list['addon_fabcon-4']['desc'].."..... P"..addons_list['addon_fabcon-4']['price'], "left", nil, gfont_med)
    services_g:insert(lbl)
    chk_box_var['ao-4'] = chk_box

    return services_g
end
local scene_g
local scene = composer.newScene()
local form_g
local inp_email
local inp_upass
local inp_repass
local btn_cancel
local btn_submit
local warn_note

local lbl_show
local password_secured
local function show_password(event)
    if(password_secured) then
		password_secured = false
	else
		password_secured = true
	end
	inp_upass.isSecure = password_secured
    inp_repass.isSecure = password_secured
end

local function send_creden( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
        processing_state({btn_cancel, btn_submit}, true)
    else
        res = event.response
        if(res ~= "invalid") then
            --reg_id = (json.decode(res))['id']
            request_type = "reset_password"
            complete_msg = "Congratulations!,\n your password has been reset."
            --change_page("pages.request_otp", "slideLeft")
            change_page("pages.request_completed", "slideLeft")
        else
            native.showAlert("Notice","User email not found!",{"OK"})
        end
    end
end

function submit_new_pasword(event)
    warn_note.text = ""
    if(check_input_form({trim_obj(inp_email), trim_obj(inp_upass), trim_obj(inp_repass)}) and inp_upass.text == inp_repass.text and #(trim_string(inp_upass.text)) >= 8) then
        request_data = encrypt_pass(inp_upass.text)
	    -- network.request( host_url .. "request_reset_password/" .. inp_email.text, "POST",  send_creden)
        local json_data = '{"email":"' .. trim_string(inp_email.text) .. '", "upass":"' .. request_data .. '"}'
        network.request( host_url .. "reset_password/" .. json_data, "POST",  send_creden)
    else
        if(trim_string(inp_email.text) == "") then
            warn_note.text = "Invalid user name!"
        elseif(#(trim_string(inp_upass.text)) < 8) then
            warn_note.text = "Minimum of 8 characters"
        elseif(inp_upass.text ~= inp_repass.text) then
            warn_note.text = "Password didn't match!"
        end
    end
end

function cancel_reset_password(event)
    sc_view:removeSelf()
    change_page("pages.login", "slideRight")
end

function scene:create( event )
    password_secured = true

	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    btn_g = display.newGroup()
    
    local lbl_page_title = create_label(0, dsp_h*.1, dsp_w, lbl_gfs_0, "Reset Password", "center", {1,1,1,1}, gfont_bold)
    form_g:insert(lbl_page_title)
    
    local lbl = create_label(dsp_w*.15, lbl_page_title.y+(lbl_page_title.height*1.1), dsp_w*.7, lbl_gfs_2, "Email", "center", {1,1,1,1})
    inp_email = create_input(lbl, .8, dsp_w*.7, inp_gfs_2,  "center", false, "default", "")
    form_g:insert(lbl)
    form_g:insert(inp_email)

    lbl = create_label(dsp_w*.15, inp_email.y+(inp_email.height*1.2), dsp_w*.7, lbl_gfs_2, "Password", "center", {1,1,1,1})
    inp_upass = create_input(lbl, .8, dsp_w*.7, inp_gfs_2,  "center", true, "default", "")
    form_g:insert(lbl)
    form_g:insert(inp_upass)
    lbl_show = create_btn_toggle(0, 0, 1, true)
    lbl_show.x = inp_upass.x+(inp_upass.width-lbl_show.width)
    lbl_show.y = lbl.y+((lbl.height-lbl_show.height)*.5)
    lbl_show:addEventListener( "tap", show_password )
    form_g:insert(lbl_show)

    lbl = create_label(dsp_w*.15, inp_upass.y+(inp_upass.height*1.2), dsp_w*.7, lbl_gfs_2, "Re-enter Password", "center", {1,1,1,1})
    inp_repass = create_input(lbl, .8, dsp_w*.7, inp_gfs_2,  "center", true, "default", "")
    warn_note = create_label(dsp_w*.15, inp_repass.y+(inp_repass.height*1.5), dsp_w*.7, lbl_gfs_3, "", "center", {1,0.1,0,1})
    form_g:insert(lbl)
    form_g:insert(warn_note)
    form_g:insert(inp_repass)

    btn_cancel = create_button("cancel","Cancel", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_cancel.x = inp_repass.x
    btn_cancel.y = inp_repass.y+(inp_repass.height*2.8)
    btn_cancel:addEventListener( "tap", cancel_reset_password )
    form_g:insert(btn_cancel)

    btn_submit = create_button("submit","Submit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_submit.x = inp_repass.x+(inp_repass.width-btn_submit.width)
    btn_submit.y = btn_cancel.y
    btn_submit:addEventListener( "tap", submit_new_pasword )
    form_g:insert(btn_submit)

    sc_view.x = 0
    sc_view.y = 0
    sc_view:setScrollHeight(form_g.height*1.1)
    local form_bg = create_background(dsp_w*.1, dsp_h*.05, dsp_w*.8, form_g.height*1.2, 25, {17/255,120/255,196/255,1})
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	inp_email:removeSelf()
    inp_upass:removeSelf()
    inp_repass:removeSelf()
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
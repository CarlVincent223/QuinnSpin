local function open_map(event)
	-- Android
	local url = "http://maps.google.com/maps?q=" .. shop_map['lat'] .. "," .. shop_map['lng']
    if shop_map['lbl'] then
        url = url .. "(" .. shop_map['lbl'] .. ")"
    end
    system.openURL(url)

	-- IOS
    -- local url = "comgooglemaps://?q=" .. shop_map['lat'] .. "," .. shop_map['lng']
    -- if shop_map['lbl'] then
    --     url = url .. "&label=" .. shop_map['lbl']
    -- end
    -- system.openURL(url)
end

local function init_call(event)
	if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
			system.openURL( "tel:"..shop_mobile_num )
        elseif ( i == 2 ) then
			return false
        end
    end
end

local function open_contact(event)
	native.showAlert( "Confirmation!", "Are you sure you want to call "..shop_mobile_num.."? Charges may apply.", { "Yes", "No" }, init_call)
end

local function open_fb_page(event)
	system.openURL( "fb://page/"..shop_fb_id )
end

function create_slide4_items(w, h, item_data)
	local fs_title = w*.1
	local fs_sub = w*.06
	local fs_desc = w*.04
	local m1 = 0
	local m2 = w*.05
	local m3 = 0
	local m4 = w*.1
	local w1 = w*.8
	local w2 = w*.9
	local g1 = h*.05
	local g2 = h*.02

	item_g = display.newGroup()
	anchor(item_g)
	local lbl1 = create_label( m2, 0, w2, lbl_gfs_1, item_data['title'], "center")
	item_g:insert(lbl1)
	local img = create_image(740, 494, w*.9, w*.9, item_data['img'])
	img.x = m2
	img.y = lbl1.height
	item_g:insert(img)
	lbl2 = create_label( m2, lbl1.y+lbl1.height, w2, lbl_gfs_3, item_data['desc'], "center", nil, gfont_reg)
	item_g:insert(lbl2)
	lbl2.y = item_g.height
	
	return item_g
end

function create_page_slide2(w, h)
	local fs_title = w*.1
	local fs_sub = w*.06
	local fs_desc = w*.04
	local m1 = 0
	local m2 = w*.05
	local m3 = w*.08
	local m4 = w*.1
	local w1 = w*.8
	local w2 = w*.9
	local g1 = h*.07
	local g2 = h*.02
	
    local slide_view = create_scroll_view(0, 0, w, h, 0)
    anchor(slide_view)

	local pos_y = 20

	local item_g = display.newGroup()
	item_g.y = pos_y
	anchor(item_g)
	local lbl1 = create_label( 0, pos_y, w, lbl_gfs_0, "Our Services", "center")
	anchor(lbl1)
    local bg_cat = create_background(m1, lbl1.y, lbl1.width*1.1, lbl1.height, 20, {17/255,120/255,196/255,0})
	bg_cat.x = (dsp_w*.5)-(bg_cat.width*.5)
	lbl1.x = bg_cat.x+((bg_cat.width-lbl1.width)*.5)
    item_g:insert(bg_cat)
    item_g:insert(lbl1)
	local lbl2 = create_label( m2, lbl1.y+lbl1.height, w*.9, lbl_gfs_3, "Your trust in us to keep your clothes fresh and clean.", "center", nil, gfont_reg)
	item_g:insert(lbl2)
	slide_view:insert(item_g)
	pos_y = lbl2.y+lbl2.height+g1


	local item_data = {}
	item_data[1] = {}
	item_data[1]['title'] = "Machine Wash"
	item_data[1]['img'] = "assets/images/slides_img/machine_wash.png"
	item_data[1]['desc'] = "\"Let our machine do the dirty work while you enjoy the fresh result.\""
	item_data[2] = {}
	item_data[2]['title'] = "Pick-up & Delivery Service"
	item_data[2]['img'] = "assets/images/slides_img/pickup_delivery.png"
	item_data[2]['desc'] = "Let us handle your laundry picked up, cleaned and delivered to your door."
	item_data[3] = {}
	item_data[3]['title'] = "Folding"
	item_data[3]['img'] = "assets/images/slides_img/folding.png"
	item_data[3]['desc'] = "\"Fresh, folded and flawless. Let us handle your laundry so you can handle life.\""
	item_data[4] = {}
	item_data[4]['title'] = "(DIY) DO-IT-YOURSELF LAUNDRY"
	item_data[4]['img'] = "assets/images/slides_img/diy.png"
	item_data[4]['desc'] = "DIY Laundry Day - Beacause fresh clothes feed better when you do it yourself!"
	
	for i=1, #item_data do
		item_g = display.newGroup()
		item_g.y = pos_y
		item_g:insert(create_slide4_items(w, h, item_data[i]))
		slide_view:insert(item_g)
		pos_y = item_g.y + item_g.height+g1
	end

	m2 = w*.05
	m3 = w*.08
	m4 = w*.14
	w1 = w*.9
	w2 = w*.86
	local lbl1 = create_label( 0, pos_y, w, lbl_gfs_0, "Laundry Price", "center")
    local obj_bg = create_background(0, pos_y, w*.9, lbl1.height, 20, {1, 1, 1, 0})
	slide_view:insert(obj_bg)
	slide_view:insert(lbl1)
	local lbl = nil
    
	prod_exist = false
	lbl = create_label(m2, obj_bg.y+obj_bg.height+g2, w1, lbl_gfs_1, "Full Service", "left", txt_hl_blue1, gfont_med)
	slide_view:insert(lbl)
	for i=1, #products_list do
		if(res_data[i].prod_type == "full_service") then
			lbl = create_label(m2, lbl.y+lbl.height+g2, w2, lbl_gfs_2, "☑", "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y, w2, lbl_gfs_2, res_data[i].title.."... P"..res_data[i].price.." / "..res_data[i].quantity..res_data[i].unit, "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y+lbl.height, w2, lbl_gfs_3, res_data[i].description, "left", {0.3,0.3,0.3,1}, gfont_ita)
			slide_view:insert(lbl)
			prod_exist = true
		end
    end

	if(prod_exist == false) then
		lbl:removeSelf()
	end

	prod_exist = false
	lbl = create_label(m2, lbl.y+lbl.height+g2, w1, lbl_gfs_1, "Comforter", "left", txt_hl_blue1, gfont_med)
    slide_view:insert(lbl)
	for i=1, #products_list do
		if(res_data[i].prod_type == "comforter") then
			lbl = create_label(m2, lbl.y+lbl.height+g2, w2, lbl_gfs_2, "☑", "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y, w2, lbl_gfs_2, res_data[i].title.."... P"..res_data[i].price.." / "..res_data[i].quantity..res_data[i].unit, "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y+lbl.height, w2, lbl_gfs_3, res_data[i].description, "left", {0.3,0.3,0.3,1}, gfont_ita)
			slide_view:insert(lbl)
			prod_exist = true
		end
    end

	if(prod_exist == false) then
		lbl:removeSelf()
	end

	prod_exist = false
	lbl = create_label(m2, lbl.y+lbl.height+g2, w1, lbl_gfs_1, "Self Service", "left", txt_hl_blue1, gfont_med)
    slide_view:insert(lbl)
	for i=1, #products_list do
		if(res_data[i].prod_type == "self_service") then
			lbl = create_label(m2, lbl.y+lbl.height+g2, w2, lbl_gfs_2, "☑", "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y, w2, lbl_gfs_2, res_data[i].title.."... P"..res_data[i].price.." / "..res_data[i].quantity..res_data[i].unit, "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y+lbl.height, w2, lbl_gfs_3, res_data[i].description, "left", {0.3,0.3,0.3,1}, gfont_ita)
			slide_view:insert(lbl)
			prod_exist = true
		end
    end

	if(prod_exist == false) then
		lbl:removeSelf()
	end

	prod_exist = false
	lbl = create_label(m2, lbl.y+lbl.height+g2, w1, lbl_gfs_1, "Addons", "left", txt_hl_blue1, gfont_med)
    slide_view:insert(lbl)
	for i=1, #products_list do
		if(res_data[i].prod_type == "addons") then
			lbl = create_label(m2, lbl.y+lbl.height+g2, w2, lbl_gfs_2, "☑", "left")
			slide_view:insert(lbl)
			lbl = create_label(m4, lbl.y, w2, lbl_gfs_2, res_data[i].title.."... P"..res_data[i].price, "left")
			slide_view:insert(lbl)
			prod_exist = true
		end
    end

	if(prod_exist == false) then
		lbl:removeSelf()
	end

	pos_y = lbl.y+lbl.height+g1

    if(pos_y>h) then
	    slide_view:setScrollHeight(pos_y)	
    end
    
	anchor(slide_view)
    return slide_view
end

function create_page_slide3(w, h)
	local fs_title = w*.1
	local fs_sub = w*.06
	local fs_desc = w*.04
	local m1 = 0
	local m2 = w*.05
	local m3 = w*.08
	local g1 = h*.1
	local g2 = h*.03
	local g3 = h*.05

    local slide_view = create_scroll_view(0, 0, w, h, 0)
    anchor(slide_view)

    local obj_bg = create_background(0, 20, w, 0, 40, {0.6, 0.4, 0, 0})
	slide_view:insert(obj_bg)
	
	local item_g = display.newGroup()
	anchor(item_g)
	local img = create_image(260, 174, w*.8, w*.8, "assets/images/slides_img/aboutus_img1.png")
	item_g:insert(img)
	item_g.x = (w*.5)-(item_g.width*.5)
	item_g.y = obj_bg.y+20
	slide_view:insert(item_g)	

	local lbl = create_label( m2, item_g.y+item_g.height+g1, w*.85, lbl_gfs_0, "About Us", "left")
	slide_view:insert(lbl)

	lbl = create_label( m3, lbl.y+lbl.height+g2, w*.85, fs_sub, "Quality", "left")
	slide_view:insert(lbl)
	lbl = create_label( m3, lbl.y+lbl.height, w*.85, fs_desc, "Looking for a budget-friendly laundry service that doesn't comprise on quality? Quinn's Laundry Shop ensures your clothes are fresh, clean and well-cared for, all at an affordable price. Plus enjoy the convenience of our pick-up and service", "left", nil, gfont_reg)
	slide_view:insert(lbl)

	lbl = create_label( m3, lbl.y+lbl.height+g2, w*.85, fs_sub, "Experience", "left")
	slide_view:insert(lbl)
	lbl = create_label( m3, lbl.y+lbl.height, w*.85, fs_desc, "Pick-up and Delivery available to make your day even easier.\nLet us handle the laundry so you can enjoy your day off!", "left")
	slide_view:insert(lbl)

	lbl = create_label( m3, lbl.y+lbl.height+g2, w*.85, fs_sub, "Convenience", "left")
	slide_view:insert(lbl)
	lbl = create_label( m3, lbl.y+lbl.height, w*.85, fs_desc, "We're accessible via mobile app and book through facebook messenger or app. Let us take care of your laundry needs.", "left")
	slide_view:insert(lbl)

	m2 = w*.05
	m3 = w*.08
	m4 = w*.18
	w1 = w*.9
	w2 = w*.84
	local lbl_title = create_label( 0, lbl.y+lbl.height+g1, w, lbl_gfs_0, "Map", "center")
    obj_bg = create_background(0, lbl.y+lbl.height+g1, w*.9, lbl_title.height, 20, {1, 1, 1, 0})
	slide_view:insert(obj_bg)
	slide_view:insert(lbl_title)

	item_g = display.newGroup()
	anchor(item_g)
	img = create_image(740, 494, w*.9, w*.9, "assets/images/slides_img/quinns_laundry_house_map.png")
	item_g:insert(img)
	item_g.x = (w*.5)-(item_g.width*.5)
	item_g.y = lbl_title.y+lbl_title.height+g2
	item_g:addEventListener( "tap", open_map )
	slide_view:insert(item_g)
	lbl = create_label( w*.05, item_g.y+item_g.height, w*.9, fs_desc, "Tap to view map", "center")
	slide_view:insert(lbl)
	
	lbl = create_label( m4, lbl.y+lbl.height+g2, w*.85, fs_sub, "Address", "left")
	local icon_h = lbl.height
	slide_view:insert(lbl)
	local img = display.newImageRect("assets/images/location.png", icon_h, icon_h)
	anchor(img)
	img.x = m2
	img.y = lbl.y
	img:addEventListener( "tap", open_map )
	slide_view:insert(img)
	lbl = create_label( m4, lbl.y+lbl.height, w*.75, fs_desc, "Zone 6, Bagong Sirang San Felipe, Naga City / beside Blue Spring Water Refilling Station", "left", nil, gfont_reg)
	slide_view:insert(lbl)

    lbl = create_label( m4, lbl.y+lbl.height+g2, w*.85, fs_sub, "Contact number", "left")
	slide_view:insert(lbl)
	img = display.newImageRect("assets/images/contact.png", icon_h, icon_h)
	anchor(img)
	img.x = m2
	img.y = lbl.y
	img:addEventListener( "tap", open_contact )
	slide_view:insert(img)
	lbl = create_label( lbl.x, lbl.y+lbl.height, w*.6, fs_desc, shop_mobile_num, "left", nil, gfont_reg)
	slide_view:insert(lbl)

	lbl = create_label( m4, lbl.y+lbl.height+g2, w*.85, fs_sub, "Follow Us", "left")
	slide_view:insert(lbl)
	img = display.newImageRect("assets/images/fb_white.png", icon_h, icon_h)
	anchor(img)
	img.x = m2
	img.y = lbl.y
	img:addEventListener( "tap", open_fb_page )
	slide_view:insert(img)
	lbl = create_label( lbl.x, lbl.y+lbl.height, w*.6, fs_desc, shop_mobile_num, "left", nil, gfont_reg)
	img:addEventListener( "tap", open_fb_page )
	slide_view:insert(lbl)

    lbl_title = create_label( 0, lbl.y+lbl.height+g1, w, lbl_gfs_0, "What We Do", "center")
    obj_bg = create_background(0, lbl.y+lbl.height+g1, w*.9, lbl_title.height, 20, {1, 1, 1, 0})
	slide_view:insert(obj_bg)
	slide_view:insert(lbl_title)

	item_g = display.newGroup()
	anchor(item_g)
	local img = create_image(260, 174, w*.45, w*.45, "assets/images/slides_img/rider_img1.png")
	item_g:insert(img)
	item_g.x = w*.5
	item_g.y = obj_bg.y+lbl_title.height+g2
	slide_view:insert(item_g)	

	lbl = create_label( m2, item_g.y+(item_g.height*.5), w*.45, fs_sub, "GO GREEN WITH EVERY LOAD", "left")
	lbl.y = item_g.y+((item_g.height*.5)-(lbl.height*.5))
	slide_view:insert(lbl)
	lbl = create_label( lbl.x, item_g.y+item_g.height+g2, w1, fs_desc, "We use eco-friendly detergents and sustainable practices to care for your clothes and the planet. Clean clothes, cleaner conscience.", "left")
	slide_view:insert(lbl)

	lbl = create_label( w*.5, lbl.y+lbl.height+g2, w*.45, fs_sub, "HERE'S HOW IT WORKS", "left")
	slide_view:insert(lbl)
	local line_y = lbl.y+lbl.height
	lbl = create_label( w*.5, lbl.y+lbl.height+g3, w*.45, fs_desc, "1. Book laundry pick-up (Our staff will text/call within an hour to confirm schedule.)", "left")
	slide_view:insert(lbl)
	lbl = create_label( w*.5, lbl.y+lbl.height+g2, w*.45, fs_desc, "2. We pick-up your clothes (Please keep bags sealed)", "left")
	slide_view:insert(lbl)
	lbl = create_label( w*.5, lbl.y+lbl.height+g2, w*.45, fs_desc, "3. We clean your clothes", "left")
	slide_view:insert(lbl)
	lbl = create_label( w*.5, lbl.y+lbl.height+g2, w*.45, fs_desc, "4. Pay online", "left")
	slide_view:insert(lbl)
	lbl = create_label( w*.5, lbl.y+lbl.height+g2, w*.45, fs_desc, "5. We deliver fresh and clean clothes", "left")
	slide_view:insert(lbl)

    local div_line = display.newLine( w*.45, line_y, w*.45, lbl.y+lbl.height+g3 )
	div_line:setStrokeColor( 1, 0.6, 0, 1 )
	div_line.strokeWidth = 4
	slide_view:insert(div_line)

	local lbl2 = create_label( m2, div_line.y, w*.37, fs_desc, "Spend Less Time on Laundry, More Time on What Matters. Let us handle the wash, so you can enjoy life uninterrupted.", "left")
	lbl2.y = div_line.y+((div_line.height*.5)-(lbl2.height*.5))
	slide_view:insert(lbl2)

	lbl_title = create_label( 0, div_line.y+div_line.height+g1, w, lbl_gfs_0, "FAQs", "center")
    obj_bg = create_background(0, lbl.y+lbl.height+g1, w*.9, lbl_title.height, 20, {1, 1, 1, 0})
	slide_view:insert(obj_bg)
	slide_view:insert(lbl_title)

	lbl = create_label( m2, lbl_title.y+lbl_title.height+g2, w*.9, fs_sub, "Your Laundry Queries, Answered!", "left")
	slide_view:insert(lbl)
	pos_y = lbl.y+lbl.height

	local item_data = {}
	item_data[1] = {}
	item_data[1]['title'] = "What are your operating hours?"
	item_data[1]['desc'] = "Our standard processing time is 24 hours. However, if you drop off or request a pickup early, we may be able to complete your laundry on the same day, depending on the volume and availability. Were open everyday from 8 AM to 9 PM."
	item_data[2] = {}
	item_data[2]['title'] = "Do you offer same-day service?"
	item_data[2]['desc'] = "Our standard processing time is 24 hours. However, if you drop off or request a pickup early, we may be able to complete your laundry on the same day, depending on the volume and availability. Were open everyday from 8 AM to 9 PM."
	item_data[3] = {}
	item_data[3]['title'] = "What detergents do you use?"
	item_data[3]['desc'] = "☑ Our Laundry Rates:\n\n"..
	"• Full Service (Wash, Dry, Fold)\n"..
	"• P150 for 4 to 7 kilos (regular clothes)\n"..
	"• P180 for 8 kilos (regular clothes)\n"..
	"• P170 for heavy loads (bedsheets, curtains, towels, seat covers, etc.) - max 6 kilos per load\n"..
	"• P180 for comforters - 1 comforter per load\n\n"..
	"☑ We also offer pickup and delivery!\n\n"..
	"• Free within a 3km radius\n"..
	"• P35 delivery fee for locations beyond 3km\n"..
	"• Let us know how we can assist you!"
	item_data[4] = {}
	item_data[4]['title'] = "How do I pay for your services?"
	item_data[4]['desc'] = "☑ Were located at:\n\n• Zone 6, Bagong Sirang San Felipe, Naga City/beside Blue Spring Water Refilling Station"
	
	for i=1, #item_data do
		item_g = display.newGroup()
		item_g.y = pos_y
		item_g.x = dsp_w*.05
		item_g:insert(create_slide7_items(w*.9, h, item_data[i]))
		slide_view:insert(item_g)
		pos_y = item_g.y + item_g.height+g1
	end


	obj_bg.height = pos_y--lbl.y+lbl.height

    if(obj_bg.height>h) then
	    slide_view:setScrollHeight(obj_bg.height+20)	
    end
    
    return slide_view
end

function create_slide7_items(w, h, item_data)
	local fs_sub = w*.06
	local fs_desc = w*.04
	local m1 = 0
	local m2 = w*.05
	local m3 = 0
	local m4 = w*.1
	local w1 = w*.8
	local w2 = w*.9
	local g1 = h*.02

	local gradientPaint = { type='gradient', color1={0.4, 0.6, 0.9, 1.0}, color2={0.2, 0.3, 0.5, 1.0}, direction='down' } 

	local item_g = display.newGroup()
	anchor(item_g)
	local obj_bg = create_background(0, 0, w, 0, 40, {0.6, 0.4, 0, .5})
	obj_bg.fill = gradientPaint
	item_g:insert(obj_bg)
	local lbl1 = create_label( m2, 20, w2, fs_sub, item_data['title'], "left", {1,1,1,1})
	item_g:insert(lbl1)
	lbl2 = create_label( m2, lbl1.y+lbl1.height+g1, w2, fs_desc, item_data['desc'], "left", {1,1,1,1})
	item_g:insert(lbl2)
	obj_bg.height = lbl2.y+lbl2.height+20
	
	return item_g
end
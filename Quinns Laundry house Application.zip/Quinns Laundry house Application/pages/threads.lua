local scene_g
local scene = composer.newScene()
local inp_message
local sc_view
local form_g
local msg_container_g = display.newGroup()
local msg_pos_y = 0
local thread_id
local latest_stamp = ""
local link_to_view = ""
local indc_viewed
local btn_back
local btn_send

local function view_attached_file(event)
	system.openURL( link_to_view )
end

local function display_messages(temp_message, sender, seen_by, fin)
	link_to_view = ""
	if(string.find(temp_message, "http")) then
		link_to_view = temp_message
		temp_message = "Tap to view attachment"
	end

	local bg_w = dsp_w*.82
	if(sender == 'client') then
		txt_align = "right"
		ext_bg = 0
		pos_x = dsp_w*.29
		bg_clr = {0.2, 0.5, 0.8, .7}
	else
		txt_align = "left"
		ext_bg = dsp_w*.03
		pos_x = dsp_w*.01
		bg_clr = {.15,.15,.15,.6}
	end

	local dummy_txt = display.newText( temp_message, 100, 100, native.systemFont, 24 )
	anchor(dummy_txt)
	local msg_txt = create_label(dsp_w*.05, msg_pos_y, dsp_w*.8, 18, temp_message, txt_align, {1,1,1,1}, gfont_reg)
	local padw = 15
	local padh = 5
	
	local bg_h = msg_txt.height+padh
	if(dummy_txt.width < msg_txt.width) then
		bg_w = dummy_txt.width+padw
		bg_h = dummy_txt.height+padh
	end

	local bg_x = dsp_w*.04
	if(sender == 'client') then
		bg_x = dsp_w-((dsp_w*.04)+bg_w)
	end

	local bg = create_background(bg_x, msg_pos_y, bg_w+ext_bg, bg_h, 10, bg_clr)
    msg_container_g:insert(bg)
	msg_container_g:insert(msg_txt)
	
	if(link_to_view ~= "") then
		local attch_icon = display.newImageRect("assets/images/attachment_white.png", bg.height*.8, bg.height*.8)
		anchor(attch_icon)
		attch_icon.x = (bg.x+bg.width)-(attch_icon.width*1.1)
		attch_icon.y = bg.y+(bg.height*.1)
		msg_container_g:addEventListener( "tap", view_attached_file )
		msg_container_g:insert(attch_icon)
	end
	msg_txt.width = msg_txt.width*1.05
	local tmp_author = sender
	local tmp_stat = ""
	local tmp_align = "left"
	local add_spc = 0
	if(sender == 'client') then
		msg_txt.x = dsp_w*.12
		if(fin) then
			if(seen_by == nil or seen_by == "") then
				tmp_stat = "seen "
				tmp_align = "right"
			else
				tmp_stat = "sent ✓"
				tmp_align = "right"
			end
			indc_viewed = create_label(msg_txt.x, msg_pos_y, msg_txt.width, lbl_gfs_3, tmp_stat, tmp_align, {0.4,0.4,0.4,1}, gfont_ita)
			msg_container_g:insert(indc_viewed)
			indc_viewed.y = msg_txt.y+(msg_txt.height*1.15)
		end
	else
		indc_viewed = create_label(msg_txt.x, msg_pos_y, msg_txt.width, lbl_gfs_3, tmp_author .. "   " .. tmp_stat, tmp_align, {0.4,0.4,0.4,1}, gfont_ita)
		add_spc = add_spc + indc_viewed.height
		msg_txt.x = bg_x
		indc_viewed.y = msg_txt.y---+(msg_txt.height*1.15)
		msg_txt.y = indc_viewed.y+indc_viewed.height
		bg.y = msg_txt.y
		msg_container_g:insert(indc_viewed)
	end

	msg_pos_y = msg_pos_y+bg.height+10+add_spc
	dummy_txt:removeSelf()
	sc_view:insert(msg_container_g)	
end

local function load_booked_threads(event)
	processing_state({btn_back, btn_send}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "" and res ~= "invalid") then
			local arr = json.decode(res)
			local pos_y = 0
			for i=1, #arr do
				thread_id = arr[i].id

				local fin = false
				if(i==#arr) then
					fin = true
				end

				if(arr[i].thread_id ~= null) then
					display_messages(arr[i].message, arr[i].sender_type, arr[1].viewed, fin)
					latest_stamp = arr[i].timestamp
				end
			end

			if(msg_pos_y < sc_view.height) then
				sc_view:setScrollHeight(msg_pos_y)
				msg_container_g.y = sc_view.height-(msg_container_g.height+10)
				sc_view:scrollTo( "top", { time = 0, onComplete = function() print( "Scroll to bottom complete!" ) end } )
			else
				msg_container_g.y = 10
				sc_view:setScrollHeight(msg_pos_y+10)
				sc_view:scrollTo( "bottom", { time = 0, onComplete = function() print( "Scroll to bottom complete!" ) end } )
			end
			
        end
    end
end

local function send_message(event)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
		local filter_data
		if(latest_stamp ~= "") then
			filter_data = '{"filter":"WHERE B.user_id=' .. user.id .. ' AND T.booking_id=' .. cur_booking .. ' AND TM.timestamp>\'' .. latest_stamp .. '\'"}'
		else
			filter_data = '{"filter":"WHERE B.user_id=' .. user.id .. ' AND T.booking_id=' .. cur_booking .. '"}'
		end

		if(indc_viewed ~= nil) then
			indc_viewed:removeSelf()
		end

		processing_state({btn_back, btn_send}, false)
		network.request( host_url .. "get_threads/" .. filter_data, "GET",  load_booked_threads)
		inp_message.text = ""
	end
end

function reload_threads()
	if(enable_act) then
		msg_container_g:removeSelf()
		msg_container_g = display.newGroup()
		msg_pos_y = 0
		processing_state({btn_back, btn_send}, false)
		local filter_data = '{"filter":"WHERE B.user_id=' .. user.id .. ' AND T.booking_id=' .. cur_booking .. '"}'
		network.request( host_url .. "get_threads/" .. filter_data, "GET",  load_booked_threads)
	end
end

local function onprep_message(event)
	if(enable_act) then
		local temp_message = inp_message.text
		--display_messages(temp_message)

		local filter_data = '{"thread_id":"' .. thread_id .. '","user_id":"' .. user.id .. '","message":"' .. string.urlEncode(temp_message) ..'", "sender_type":"client"}'
		network.request( host_url .. "set_threads/" .. filter_data, "POST",  send_message)
	end
end

local function return_page(event)
	if(enable_act) then
		--native.setKeyboardFocus( nil )
		inp_message:removeSelf()
		change_page("pages.booked", "slideRight")
	end
end

local function move_page_gui( event )
    if ( "began" == event.phase ) then
        transition.moveTo( form_g, { y=0-(dsp_h*.4), time=200, transition = easing.inExpo } )
    elseif ( "ended" == event.phase or "submitted" == event.phase ) then
        transition.moveTo( form_g, { y=0, time=200, transition = easing.inExpo } )
        native.setKeyboardFocus( nil )
    end
end

local function hide_keyboard( event )
	native.setKeyboardFocus( nil )
end

function scene:create( event )
	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
	local top_g = display.newGroup()
    form_g = display.newGroup()
	local bottom_g = display.newGroup()
	
	local top_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)
    local lbl_page_title = create_label(0, 5, dsp_w, lbl_gfs_0*.9, set_code_format(bk_code, cur_booking, 5), "center", {1,1,1,1})
    lbl_page_title.y = (top_bg.height-(lbl_page_title.height+10))
	top_g:insert(lbl_page_title)
	
	local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 10
	btn_back.y = (top_bg.height-(btn_back.height+10))
	btn_back:addEventListener( "tap", return_page )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	top_g:insert(btn_back)

	local bottom_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	bottom_bg:addEventListener( "tap", hide_keyboard )
	bottom_bg.y = dsp_h-bottom_bg.height
	bottom_g:insert(bottom_bg)

	sc_view = create_scroll_view(0, 0, dsp_w, dsp_h-(top_g.height+bottom_bg.height), 0)
	sc_view.x = 0
    sc_view.y = top_g.y+top_g.height

	inp_message = create_input_multiline(nil, 1, dsp_w*.8, bottom_bg.height*.9, 17, "Message")
	inp_message.x = 5
	inp_message.y = bottom_bg.y+(bottom_bg.height*.05)
	bottom_bg.height = dsp_h*.6
	
    if (on_simulator==false and on_android) then
        inp_message:addEventListener( "userInput", move_page_gui )
    end
    bottom_g:insert(inp_message)
	local lbl = create_label(0, inp_message.y+(inp_message.height*1.2), dsp_w, lbl_gfs_2, "Tap To Hide", "center", {1,1,1,1})
	bottom_g:insert(lbl)

	btn_icon = display.newImageRect("assets/images/send.png", 48, 48)
	anchor(btn_icon)
	btn_send = create_button("back","", dsp_w*.15, dsp_w*.15, "Rect", 32, btn_style_trans, gfont_med)
	btn_send.x = (bottom_bg.width-(btn_send.width+((dsp_w*.2)-btn_send.width)*.5))
	btn_send.y = inp_message.y+((inp_message.height-btn_send.height)*.5)
	btn_send:addEventListener( "tap", onprep_message )
	resize(btn_icon, btn_send, 0.2)
	btn_send:insert(btn_icon)
	bottom_g:insert(btn_send)
	
	scene_g:insert(bubble_bg)
	form_g:insert(sc_view)
	form_g:insert(bottom_g)
	scene_g:insert(form_g)
	scene_g:insert(top_g)
	
	processing_state({btn_back, btn_send}, false)
	local filter_data = '{"filter":"WHERE B.user_id=' .. user.id .. ' AND T.booking_id=' .. cur_booking .. '"}'
	network.request( host_url .. "get_threads/" .. filter_data, "GET",  load_booked_threads)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
		native.setKeyboardFocus(nil)
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	inp_message:removeSelf()
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
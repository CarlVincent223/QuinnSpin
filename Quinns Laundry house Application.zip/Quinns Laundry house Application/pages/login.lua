local scene_g
local scene = composer.newScene()
local form_g
local btn_g
local inp_email
local inp_upass
local btn_login
local btn_signup

local lbl_show
local password_secured
local function show_password(event)
    if(password_secured) then
		password_secured = false
	else
		password_secured = true
	end
	inp_upass.isSecure = password_secured
end

local function send_creden( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
        processing_state({btn_login, btn_signup}, true)
    else
        user = json.decode(event.response)
        if(user ~= nil) then
            if(user.status == "Pending") then
                complete_msg = "Congratulations!,\n your account is successfully registered."
                request_type = "login"
                reg_id = user.id
                change_page("pages.request_otp", "slideLeft")
            else
                
                if (on_simulator==false) then
                    local json_data = '{"id":' .. user.id .. ',"token_id":"' .. user_token .. '"}'
                    network.request( host_url .. "ntfy_reg_device/" .. json_data, "POST",  register_device_token)
                end

                set_cache_account()
                change_page("pages.booked", "slideLeft")
            end
        else
            processing_state({btn_login, btn_signup}, true)
            native.showAlert("Notice","Invalid account",{"OK"})
        end
    end
end

function submit_login(event)
    inp_email.text = clear_spaces(inp_email.text)
    if(check_input_form({trim_obj(inp_email), trim_obj(inp_upass)})) then
        processing_state({btn_login, btn_signup}, false)
        local json_data = '{"email":"' .. inp_email.text .. '", "upass":"' .. encrypt_pass(inp_upass.text) .. '"}'
	    network.request( host_url .. "signin/" .. json_data, "POST",  send_creden)
    else
        native.showAlert("Notice","Invalid inputs",{"OK"})
    end
end

function open_signup_form(event)
    change_page("pages.signup", "slideLeft")
end

local function extend_scrollView( event )
    if ( "began" == event.phase ) then
        sc_view:setScrollHeight(form_g.height+(dsp_h*.6))
    elseif ( "ended" == event.phase or "submitted" == event.phase ) then
        sc_view:setScrollHeight(form_g.height*1.1)
        native.setKeyboardFocus( nil )
    end
end

local function reset_password(event)
	change_page("pages.reset_password", "slideLeft")
end

function scene:create( event )
    password_secured = true

	scene_g = self.view
    
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    btn_g = display.newGroup()

    local img = create_image_sheet(0, 0, 392, 392, dsp_h*.12, dsp_h*.12, 1, "assets/images/quinns_logo.png")
    img.x = (dsp_w*.5)-(img.width*.5)

    local circ_bg = display.newCircle( 0, 0, img.width*.5 )
	circ_bg:setFillColor( 1 )
    anchor(circ_bg)
    circ_bg.x = img.x-((circ_bg.width-img.width)*.5)
    circ_bg.y = img.y-((circ_bg.height-img.height)*.5)
    form_g:insert(circ_bg)
	form_g:insert(img)

    local lbl = create_label(0, img.y+(img.height*1.2), dsp_w, lbl_gfs_0, "Login Here", "center", {1,1,1,1}, gfont_bold)
    form_g:insert(lbl)

    lbl = create_label(dsp_w*.15, lbl.y+(lbl.height*1.2), dsp_w*.7, lbl_gfs_2, "Email", "center", {1,1,1,1})
    inp_email = create_input(lbl, .8, dsp_w*.7, inp_gfs_2, "center", false, "default", "")
    form_g:insert(lbl)
    form_g:insert(inp_email)
    
    
    lbl = create_label(dsp_w*.15, inp_email.y+(inp_email.height*1.5), dsp_w*.7, lbl_gfs_2, "Password", "center", {1,1,1,1})
    inp_upass = create_input(lbl, .8, dsp_w*.7, inp_gfs_2, "center", true, "default", "")
    form_g:insert(lbl)
    form_g:insert(inp_upass)
    lbl_show = create_btn_toggle(0, 0, 1, true)
    lbl_show.x = inp_upass.x+(inp_upass.width-lbl_show.width)
    lbl_show.y = lbl.y+((lbl.height-lbl_show.height)*.5)
    lbl_show:addEventListener( "tap", show_password )
    form_g:insert(lbl_show)
    lbl = create_label(dsp_w*.15, inp_upass.y+(inp_upass.height*1.5), dsp_w*.7, lbl_gfs_3, "Forgot password?", "center", {1,1,1,1})
    lbl:addEventListener( "tap", reset_password )
    form_g:insert(lbl)
    

    if (on_simulator==false and on_android) then
        inp_email:addEventListener( "userInput", extend_scrollView )
    end

    btn_login = create_button("login","Login", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_login.x = inp_email.x
    btn_login.y = lbl.y+(lbl.height*2)--inp_email.y+(inp_email.height*5)
    btn_login:addEventListener( "tap", submit_login )
    form_g:insert(btn_login)
    
    -- local btn_fb = create_image_sheet(0, 0, 100, 100, dsp_h*.07, dsp_h*.07, 1, "assets/images/fb_login.png")
    -- btn_fb.x = btn_login.x+((btn_login.width-btn_fb.width)*.5)
    -- btn_fb.y = btn_login.y+(btn_login.height*2)
    -- btn_fb:addEventListener( "tap", fb_login )
    -- form_g:insert(btn_fb)

    btn_signup = create_button("login","Signup", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_signup.x = inp_email.x+(inp_email.width-btn_signup.width)
    btn_signup.y = btn_login.y
    btn_signup:addEventListener( "tap", open_signup_form )
    form_g:insert(btn_signup)

    -- local btn_google = create_image_sheet(0, 0, 100, 100, dsp_h*.07, dsp_h*.07, 1, "assets/images/google_login.png")
    -- btn_google.x = btn_signup.x+((btn_login.width-btn_google.width)*.5)
    -- btn_google.y = btn_signup.y+(btn_signup.height*2)
    -- btn_fb:addEventListener( "tap", google_login )
    -- form_g:insert(btn_google)

    --form_g.x = (dsp_w-form_g.width)*.5
    form_g.y = (dsp_h-form_g.height)*.5
    
    sc_view.x = 0
    sc_view.y = 0
    local form_bg = create_background(dsp_w*.1, form_g.y-(form_g.height*.1), dsp_w*.8, form_g.height*1.2, 25, {17/255,120/255,196/255,1})
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    sc_view:setScrollHeight(form_g.height*1.1)
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
        native.setKeyboardFocus(nil)
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	inp_email:removeSelf()
    inp_upass:removeSelf()
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
local scene_g
local scene = composer.newScene()
local form_g
local btn_back
local btn_cancel
local btn_submit
local lbl_sched

local function send_booking( event )
    processing_state({btn_back, btn_cancel, btn_submit}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        complete_msg = "Booking complete\n\nYour booking id\n\n" .. set_code_format(bk_code, event.response, 5)
        request_type = "booking"
        change_page("pages.request_completed", "slideLeft")
    end
end

local function confirm_booking(event)
    if(enable_act) then
        processing_state({btn_back, btn_cancel, btn_submit}, false)
        network.request( host_url .. "set_booking/" .. booking_req_data, "POST",  send_booking)
    end
end

local function cancel_booking(event)
    if(enable_act) then
        -- revert_page()
        change_page("pages.booking", "slideRight")
    end
end

function scene:create( event )
    local gap_y = 10
    
	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    local top_g = display.newGroup()

    local header_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(header_bg)

    local lbl_page_title = create_label(0, 30, dsp_w, lbl_gfs_0*.9, "Confirmation", "center", {1,1,1,1})
    lbl_page_title.y = ((dsp_h*.12)-(lbl_page_title.height+10))
    top_g:insert(lbl_page_title)

    local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 10
	btn_back.y = ((dsp_h*.12)-(btn_back.height+10))
	btn_back:addEventListener( "tap", cancel_booking )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	top_g:insert(btn_back)

    local services_g = display.newGroup()
    services_g.y = lbl_page_title.y+(lbl_page_title.height*1.5)
    form_g:insert(services_g)

    local mgl = dsp_w*.08
    local bg_cat

    --local bg_cat = create_background(mgl, 0, dsp_w*.5, lbl_gfs_0, 10, hl_bg0)
    --services_g:insert(bg_cat)
    local lbl = create_label(mgl, 0, dsp_w*.9, lbl_gfs_1, "Quantity", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, " Basket", "left")
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "x " .. services_acquired['qty'], "right")
    services_g:insert(lbl)

    --bg_cat = create_background(dsp_w*.08, services_g.y+services_g.height+gap_y, dsp_w*.5, lbl_gfs_0, 10, hl_bg0)
    --form_g:insert(bg_cat)
    lbl = create_label(mgl, services_g.y+services_g.height+gap_y, dsp_w*.8, lbl_gfs_1, "Schedule", "left", txt_hl_blue1, gfont_med)
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['sched'], "left")
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, set_datetime_format(services_acquired['sched_date'], "date"), "right")
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['mode'], "left")
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, services_acquired['dt'], "right")
    form_g:insert(lbl)
    lbl_sched = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "", "right", {1,0,0,.8}, gfont_med)
    form_g:insert(lbl_sched)

    --bg_cat = create_background(dsp_w*.08, lbl_sched.y+lbl_sched.height+gap_y, dsp_w*.5, lbl_gfs_0, 10, hl_bg2)
    --form_g:insert(bg_cat)
    lbl = create_label(mgl, lbl_sched.y+lbl_sched.height+gap_y, dsp_w*.8, lbl_gfs_1, "Client", "left", txt_hl_blue1, gfont_med)
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['client'], "left")
    form_g:insert(lbl)

    --bg_cat = create_background(dsp_w*.08, lbl.y+lbl.height+gap_y, dsp_w*.5, lbl_gfs_0, 10, hl_bg2)
    --form_g:insert(bg_cat)
    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_1, "Contact", "left", txt_hl_blue1, gfont_med)
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['contact'], "left")
    form_g:insert(lbl)

    --bg_cat = create_background(dsp_w*.08, lbl.y+lbl.height+gap_y, dsp_w*.5, lbl_gfs_0, 10, hl_bg2)
    --form_g:insert(bg_cat)
    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_1, "Address", "left", txt_hl_blue1, gfont_med)
    form_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['addr'], "left")
    form_g:insert(lbl)

    if(services_acquired['notes'] ~= "") then
        --bg_cat = create_background(dsp_w*.08, lbl.y+lbl.height+gap_y, dsp_w*.5, lbl_gfs_0, 10, hl_bg2)
        --form_g:insert(bg_cat)
        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "Notes", "left", txt_hl_blue1, gfont_med)
        form_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, services_acquired['notes'], "left")
        form_g:insert(lbl)
    end

    btn_cancel = create_button("cancel","Edit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_cancel.x = (dsp_w*.25)-(btn_cancel.width*.5)
    btn_cancel.y = dsp_h-(btn_cancel.height*1.5)
    btn_cancel.y = (lbl.y+lbl.height)+btn_cancel.height
    btn_cancel:addEventListener( "tap", cancel_booking )
    
    btn_submit = create_button("submit","Confirm", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_submit.x = (dsp_w*.75)-(btn_cancel.width*.5)
    btn_submit.y = btn_cancel.y
    btn_submit:addEventListener( "tap", confirm_booking )

    --form_g.y = (dsp_h/2)-(form_g.height/2)

    sc_view.x = 0
    sc_view.y = 0
    local form_bg = create_background(dsp_w*.05, lbl_page_title.y-10, dsp_w*.9, form_g.height*1.05, 25, {217/255,217/255,217/255,0})
    form_g:insert(btn_cancel)
    form_g:insert(btn_submit)
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
    scene_g:insert( top_g )

    --sc_view:setScrollHeight(form_bg.height*1.2)
    sc_view:setScrollHeight(form_g.height+(top_g.height*1.5))
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
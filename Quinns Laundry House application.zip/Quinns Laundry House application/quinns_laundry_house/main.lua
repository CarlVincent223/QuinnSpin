-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

composer = require( "composer" )
widget = require("widget")
json = require("json")
calendar = require( "plugin.calendar" )
date = os.date( "*t" )
openssl = require( "plugin.openssl" )
cipher = openssl.get_cipher ( "aes-256-cbc" )
mime = require ( "mime" )
utf8 = require("plugin.utf8")
notifications = require("plugin.notifications.v2")
scrn_msg = require( "assist.screen_msg" )
scrn_msg_g = display.newGroup()
scrn_msg = scrn_msg.new({g=scrn_msg_g})
ext_auth = require( "assist.third_party_auth" )
socket = require( "socket" )

require( "timer" )
require( "assist.methods" )
require( "assist.objects_generator" )
require( "assist.variables" )
require( "assist.laundry_services" )
require( "pages.slides" )


local function confirm_exit(event)
	if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
			os.exit()
        elseif ( i == 2 ) then
			return false
        end
    end
end

local function soft_keys_event( event )
    if ( event.keyName == "back" ) then
        if event.phase == "up" then
            native.setKeyboardFocus( nil )
            if(composer.getSceneName( "current" ) == "pages.booked") then
                return native.showAlert( "Confirmation!", "Are you sure you want to exit?", { "Yes", "No" }, confirm_exit)
            elseif(composer.getSceneName( "current" ) == "pages.login") then
                change_page("pages.booked", "slideLeft")
                return true
            elseif(composer.getSceneName( "current" ) == "pages.signup" or composer.getSceneName( "current" ) == "pages.reset_password") then
                change_page("pages.login", "slideRight")
                return true
            elseif(composer.getSceneName( "current" ) == "pages.booking") then
                change_page("pages.booked", "slideRight")
                return true
            else
                return true
            end
        end
    end
    return false
end

function register_device_token( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        print(event.response)
    end
end

local function close_popup_notification( event )
    network.request( host_url .. "clear_notification/" .. user.id, "GET",  clear_notification_update)
end

function trigger_notification(event)
    if event.type == "remoteRegistration" then
        user_token = event.token
        composer.gotoScene("pages.intro")
        
    elseif event.type == "remote" then
        system.vibrate()
        
        local ntfy_data = event.custom

        if(ntfy_data['type'] == "booking") then
            if(ntfy_data['msg'] == "Confirmed") then
                ntfy_msg = "Your laundry booking request confirmed."
            elseif(ntfy_data['msg'] == "Pickup") then
                ntfy_msg = "Rider is on the way to pickup your laundry."
            elseif(ntfy_data['msg'] == "Drop Off") then
                ntfy_msg = ""
            elseif(ntfy_data['msg'] == "Arrived") then
                ntfy_msg = "Your laundry arrived at the shop."
            elseif(ntfy_data['msg'] == "Ongoing") then
                ntfy_msg = "Were currently doing a service to your laundry."
            elseif(ntfy_data['msg'] == "Delivery") then
                ntfy_msg = "Rider is on the way to deliver your laundry."
            elseif(ntfy_data['msg'] == "To Receive") then
                ntfy_msg = "Your laundry is ready to be receive."
            elseif(ntfy_data['msg'] == "Completed") then
                ntfy_msg = "We have completed servicing your laundry."
            elseif(ntfy_data['msg'] == "Cancelled") then
                ntfy_msg = "We have to decline on your booking request for some reason."
            end
        elseif(ntfy_data['type'] == "message") then
            ntfy_msg = ntfy_data['msg']
            new_msg[tonumber(ntfy_data['id'])] = 1
        end

        if(event.applicationState == "active") then
            if(composer.getSceneName( "current" ) == "pages.threads") then
                network.request( host_url .. "clear_notification/" .. user.id, "GET",  clear_notification_update)
                reloading_content = true
                reload_threads()
            elseif(composer.getSceneName( "current" ) == "pages.booked") then
                native.showAlert(ntfy_data['title'], ntfy_msg, {"OK"}, close_popup_notification)
                reloading_content = true
                reload_user_bookings()
            else
                ntfy_status = true
                show_ntfy_sign()
                native.showAlert(ntfy_data['title'], ntfy_msg, {"OK"}, close_popup_notification)
            end
        else
            ntfy_status = false
            if(composer.getSceneName("current") ~= "pages.booked") then
	            change_page("pages.booked", "slideLeft")
            end
        end
    end
end

if (on_simulator==false) then
    Runtime:addEventListener("key", soft_keys_event)
    Runtime:addEventListener("notification", trigger_notification)

    local deviceToken = notifications.getDeviceToken()
    if deviceToken then
        user_token = deviceToken
        composer.gotoScene("pages.intro")
    else
        notifications.registerForPushNotifications()
    end
else
    composer.gotoScene("pages.intro")
end
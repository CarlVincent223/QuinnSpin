local composer = require( "composer" )
local scene = composer.newScene()
local pop_type
local sc_view
local inp1
local inp2
local inp3
local password_note
local btn_cancel
local btn_submit
local btn_close

local reset_session = false
local update_session = false
local pos_y = 0
local list_h = dsp_w*.13
local sel_val = ""

local lbl_show
local password_secured

local calendar_g
local day_off_data = {}
local header_g = display.newGroup()
local header_title = ""
local server_date
local tmp_dd
local tmp_mm
local tmp_yr

local function show_password(event)
     if(password_secured) then
		password_secured = false
	else
		password_secured = true
	end
	inp1.isSecure = password_secured
	inp2.isSecure = password_secured
	inp3.isSecure = password_secured
end

local function hide_popup(event)
	composer.hideOverlay("popup_list")
end

local function init_hide_popup(event)
	if(enable_act) then
		--if(pop_type == "pts_history" or pop_type == "pts_reward") then
		if(pop_type ~= "mode_sched" and pop_type ~= "dt_sched") then
			transition.moveTo( scene_g, { y=0-scene_g.height, time=300, transition = easing.inExpo, onComplete=hide_popup } )
		else
			composer.hideOverlay("popup_list")
		end
	end
end

local function display_points_history(x, y, w, h, data)
	local fs_desc = lbl_gfs_3

	local m1 = dsp_w*.05
	local m2 = dsp_w*.07
	local g1 = dsp_h*.02
	local g2 = dsp_h*.04

	local booked_g = display.newGroup()

	local clr, str_amt, tmp_title
	if(data['source'] ~= nil) then
		clr = {0.2,0.5,0.8,.7}
		tmp_title = data['source']
		str_amt = "+"..data['amount']
	else
		clr = {1,0,0,.5}
		tmp_title = data['benefit']
		str_amt = "-"..data['amount']
	end

	local bg_cat = create_background(x, pos_y, w, h, 0, clr)
	local item_title = create_label(m1, bg_cat.y, w*.7, lbl_gfs_1, tmp_title, "left", {1,1,1,1}, gfont_med)

	local item_desc = create_label(item_title.x+item_title.width, bg_cat.y, w*.2, lbl_gfs_0, str_amt, "right", {1,1,1,1}, gfont_med)
	local item_stamp = create_label(m1, bg_cat.y, w, fs_desc, set_datetime_format(data['timestamp'], "datetime"), "left", {1,1,1,1}, gfont_ita)

	booked_g:insert(bg_cat)
	booked_g:insert(item_title)
	booked_g:insert(item_desc)
	booked_g:insert(item_stamp)

	bg_cat.height = booked_g.y+booked_g.height+item_stamp.height+g1
	item_desc.y = bg_cat.y+((bg_cat.height-item_desc.height)*.5)
	item_stamp.y = (bg_cat.y+bg_cat.height)-item_desc.height+g1
	pos_y = pos_y+booked_g.height+3
	
	sc_view:insert(booked_g)
end

local function display_points_reward_list(x, y, w, h, data)
	local fs_desc = lbl_gfs_3

	local m1 = dsp_w*.05
	local m2 = dsp_w*.07
	local g1 = dsp_h*.02
	local g2 = dsp_h*.04

	local booked_g = display.newGroup()
	local clr = {0.2, 0.5, 0.8, .8}

	local bg_cat = create_background(m1, pos_y, w, h, 10, clr)
	local item_title = create_label(m2, bg_cat.y, w*.9, lbl_gfs_0, data['title'], "left", {1,1,1,1}, gfont_med)
	local item_desc = create_label(dsp_w*.5, item_title.y+item_title.height+g1, w*.45, lbl_gfs_2, data['description'], "left", {1,1,1,1}, gfont_med)
	local pts_req = create_label(m2, item_desc.y+item_desc.height+g1, w*.45, fs_desc, "Required Points", "center", {1,1,1,1}, gfont_med)

	local item_g = display.newGroup()
	anchor(item_g)
	local img = create_image(100, 100, bg_cat.width*.3, bg_cat.width*.3, "assets/images/pts_bg.png")
	item_g:insert(img)
	item_g.x = pts_req.x+((pts_req.width-item_g.width)*.5)
	item_g.y = item_desc.y --(pts_req.y+pts_req.height)-item_g.height
	lbl_points = create_label( 0, 0, item_g.width, lbl_gfs_0, data['pts_req'], "center", {1,1,1,1})
	lbl_points.y = (item_g.height*.5)-(lbl_points.height*.5)
	pts_req.y = item_g.y+item_g.height
	item_g:insert(lbl_points)
	
	booked_g:insert(bg_cat)
	booked_g:insert(item_title)
	booked_g:insert(item_desc)
	booked_g:insert(pts_req)
	booked_g:insert(item_g)

	pos_y = pos_y+booked_g.height+g2
	bg_cat.height = booked_g.y+booked_g.height+g1
	
	sc_view:insert(booked_g)
end

local function update_account_info(event)
	processing_state({btn_cancel, btn_submit, btn_close}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		--print(trim_string(event.response), "<<")
		if(trim_string(event.response) == "valid") then
			if(pop_type == "password" or pop_type == "email") then
				reset_session = true	
			else
				update_session = true	
				if(pop_type == "first_name") then
					user['first_name'] = inp1.text
				elseif(pop_type == "last_name") then
					user['last_name'] = inp1.text
				elseif(pop_type == "address") then
					user['address'] = inp1.text
				elseif(pop_type == "mobile_no") then
					user['mobile_no'] = inp1.text
				end
				set_cache_account()
			end
			composer.hideOverlay("popup_list")
		else
			native.showAlert("Notice!", "Unable to update info!")
		end
    end
end

local function cancel_booking_result( event )
    processing_state({btn_cancel, btn_back}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "valid") then
            native.showAlert( "Notice", "Unable to cancel?", { "OK" })
        else
			composer.hideOverlay("popup_list")
            change_page("pages.booked", "slideRight")
        end
    end
end

local function submit_profile_update(event)
	if(enable_act) then
		local json_data
		local str = "Invalid input!"
		local invalid_input = true

		if(pop_type == "first_name") then
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_users", "field":"first_name", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		elseif(pop_type == "last_name") then
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_users", "field":"last_name", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		elseif(pop_type == "password") then
			password_note.text = ""
			trim_obj(inp1)
			trim_obj(inp2)
			trim_obj(inp3)
			if(check_input_form({inp1.text, inp2.text, inp3.text})) then
				if(#(trim_string(inp2.text)) < 8) then
					password_note.text = "Minimum of 8 characters"
				elseif(inp2.text == inp3.text) then
					if(encrypt_pass(inp1.text) == user.password) then
						invalid_input = false
						--str = "UPDATE tbl_users SET password='".. encrypt_pass(inp2.text) .."' WHERE id=" .. user.id
						json_data = '{"table":"tbl_users", "field":"password", "value":"'..encrypt_pass(inp2.text)..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
					else
						str = "Invalid Old password!"
					end
				else
					str = "Password didn't match!"
				end
			end
		else
			trim_obj(inp1)
			if(check_input_form({inp1.text})) then
				invalid_input = false
				json_data = '{"table":"tbl_users", "field":"'..pop_type..'", "value":"'..inp1.text..'", "ref_field":"id", "ref_value":"'..user.id..'"}'
			end
		end
		
		if(invalid_input) then
			native.showAlert("Notice", str)
		else
			processing_state({btn_cancel, btn_submit, btn_close}, false)
			if(pop_type == "cancel_reason") then
				trim_obj(inp1)
				if(check_input_form({inp1.text})) then
					invalid_input = false
					local json_data = '{"key":"' .. api_key .. '","id":"' .. cur_booking .. '", "cancel_reason":"'..inp1.text..'", "cancelled_by":"client"}'
					processing_state({btn_cancel, btn_back}, false)
					network.request( host_url .. "cancel_booking/" .. json_data, "POST",  cancel_booking_result)
				end
				
				
			else
				network.request( host_url .. "update_field/" .. json_data, "POST",  update_account_info)
			end
		end
	end
end

local function load_points_history(event)
	processing_state({btn_close}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		pos_y = 3
		local res_arr = json.decode(event.response)
		local points_arr = {}
		local ind = 1
		for i=1, #res_arr[1] do
			points_arr[ind] = {}
			points_arr[ind] = res_arr[1][i]
			ind = ind + 1
		end

		for i=1, #res_arr[2] do
			points_arr[ind] = {}
			points_arr[ind] = res_arr[2][i]
			ind = ind + 1
		end

		for i=1, #points_arr-1 do
			for j=i+1, #points_arr do
				if(points_arr[i]['timestamp'] < points_arr[j]['timestamp']) then
					local tmp = points_arr[i]
					points_arr[i] = points_arr[j]
					points_arr[j] = tmp
				end
			end
		end

		if(#points_arr > 0) then
			pos_y = dsp_w*.18
			for i=1, #points_arr do
				display_points_history(dsp_w*.02, 0, dsp_w*.96, 0, points_arr[i])
			end
		else
			local empty_sign = create_label(0, 0, dsp_w, lbl_gfs_3, "No point's history yet.", "center", {0,0,0,1}, gfont_med)
			empty_sign.y = (dsp_h*.5)-empty_sign.height
			sc_view:insert(empty_sign)
		end
    end
end

local function points_history()
	processing_state({btn_close}, false)
	network.request( host_url .. "points_history/" .. user.id, "GET",  load_points_history)
end

local function load_points_reward_list(event)
	processing_state({btn_close}, true)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		pos_y = dsp_w*.18
		local arr = json.decode(event.response)

		if(#arr > 0) then
			for i=1, #arr do
				display_points_reward_list(0, 0, dsp_w*.9, 0, arr[i])
			end
			sc_view:setScrollHeight(pos_y+(dsp_h*.12))
		else
			local empty_sign = create_label(0, 0, dsp_w, lbl_gfs_3, "No reward offers available.", "center", {0,0,0,1}, gfont_med)
			empty_sign.y = (dsp_h*.5)-empty_sign.height
			sc_view:insert(empty_sign)
		end
    end
end

local function points_reward_list()
	processing_state({btn_close}, false)
	network.request( host_url .. "points_reward/Active", "GET",  load_points_reward_list)
end

local function selected_option(event)
	sel_val = event.target.id
end

local options = {
	width = 100,
	height = 100,
	numFrames = 2,
	sheetContentWidth = 200,
	sheetContentHeight = 100
}
local checkboxSheet = graphics.newImageSheet( "assets/images/radio_button_dark.png", options )

local function selected_date( event )
	if(enable_act) then
		sel_val = event.target.day
		tmp_dd = event.target.id
		sel_val = tmp_yr.."-"..tmp_mm.."-"..set_code_format('', tmp_dd, 1)
		transition.moveTo( scene_g, { y=0-scene_g.height, time=300, transition = easing.inExpo, onComplete=hide_popup } )
	end
end

local function calendar_list()
	if(calendar_g ~= nil) then
		calendar_g:removeSelf()
	end
	calendar_g = display.newGroup()

	local mt = dsp_h*.07
	header_title.text = months_list[tmp_mm].." "..tmp_yr
	
	pos_y = 0

	local bg_clr
	local date_status
	local leaf_yr = 0
	if(tmp_yr%4~=0 and tmp_mm==2) then
		leaf_yr = 1
	end
	
	for i=1, months_days_list[tmp_mm]-leaf_yr do
		local tmp_ind = trim_string(set_code_format('', tmp_mm, 1).."-"..set_code_format('', i, 1))
		
		local cur_stamp = os.time({year=tmp_cur_yr, month=tmp_cur_mm, day=tmp_cur_dd})
		local new_stamp = os.time({year=tmp_yr, month=tmp_mm, day=i})

		if(day_off_data[tmp_ind] ~= nil) then
			date_status = "Closed"
			bg_clr = {0.2,0.5,0.8,.5}
			txt_clr = {1,0,0,.9}
		elseif(cur_stamp > new_stamp) then
			date_status = ""
			bg_clr = {0.1,0.1,0.1,.5}
		else
			date_status = "Open"
			bg_clr = {0.2,0.5,0.8,.5}
			txt_clr = {0,0.6,0.3,.9}
		end
		local item_g = display.newGroup()
		anchor(item_g)
		item_g.y = pos_y
		local item_bg = create_background(dsp_w*.05, 0, dsp_w*.9, (lbl_gfs_0*2), 10, bg_clr)
		item_g:insert(item_bg)
		local lbl1 = create_label(item_bg.x+10, 0, dsp_w, lbl_gfs_0, set_code_format('', i, 1), "left", {0,0,0,.9})
		lbl1.y = (item_bg.height-lbl1.height)*.5
		item_g:insert(lbl1)
		local lbl2 = create_label(item_bg.x+(lbl_gfs_0*2), 0, dsp_w, lbl_gfs_1, get_day_str(tmp_yr.."-"..tmp_mm.."-"..i), "left", {0,0,0,.9})
		item_g:insert(lbl2)
		local lbl3 = create_label(item_bg.x, 0, item_bg.width-10, lbl_gfs_1, date_status, "right", txt_clr)
		item_g:insert(lbl3)
		pos_y = pos_y+item_bg.height+15
		item_g.id = i
		item_g.day = get_day_str(tmp_yr.."-"..tmp_mm.."-"..i)
		if(date_status == "Open") then
			item_g:addEventListener( "tap", selected_date )
		end
		calendar_g:insert(item_g)
	end

	calendar_g.y = header_g.height
	sc_view:insert(calendar_g)
	sc_view:setScrollHeight(pos_y+(header_g.height*2))
end

local function days_list(val, title)
	local mt = dsp_h*.07
	local modal_g = display.newGroup()
	local modal_bg = create_background(dsp_w*.05, 0, dsp_w*.9, 0, 20, {0.2, 0.5, 0.8, .4})
	modal_g:insert(modal_bg)
	local lbl = create_label(modal_bg.x, modal_bg.y+5, modal_bg.width, lbl_gfs_0, title, "center", {0,0,0,.9})
	modal_g:insert(lbl)
	pos_y = modal_g.y+lbl.height
	for i=1, #days_of_week do
		rad_state = false
		if(val == days_of_week[i]) then
			rad_state = true
		end
		local alpha = .4
		if(i%2 == 1) then
			alpha = .6
		end
		
		local item_bg = create_background(0, pos_y, dsp_w, list_h, 0, {0.2, 0.5, 0.8, 0})
		local chk_box = widget.newSwitch(
			{
				left = dsp_w*.05,
				top = 0,
				width = dsp_w*.1,
				height = dsp_w*.1,
				style = "radio",
				id = days_of_week[i],
				initialSwitchState = rad_state,
				sheet = checkboxSheet,
				frameOff = 1,
				frameOn = 2,
				onPress = selected_option
			}
		)
		chk_box.y = item_bg.y+((item_bg.height-chk_box.height)*.5)
		anchor(chk_box)

		local lbl = create_label(chk_box.x+(chk_box.width*1.2), 0, dsp_w, lbl_gfs_1, days_of_week[i], "left", {0.1,0.1,0.1,1})
		lbl.y = item_bg.y+((item_bg.height-lbl.height)*.5)

		pos_y = pos_y+list_h
		modal_g:insert(item_bg)
		modal_g:insert(chk_box)
		modal_g:insert(lbl)

	end
	local lbl_close = create_label(modal_bg.x, pos_y, modal_bg.width*.5, lbl_gfs_1, "Close", "center", {0,0,0,.9})
	lbl_close:addEventListener( "tap", init_hide_popup )
	lbl_close.x = modal_bg.x+(modal_bg.width-lbl_close.width)
	modal_g:insert(lbl_close)
	pos_y = pos_y+list_h
	sc_view:insert(modal_g)
	modal_bg.height = pos_y
	modal_g.y = (sc_view.height-modal_g.height)*.5
	sc_view:setScrollHeight(modal_g.height)
end

local function mode_list(val, title)
	local mt = dsp_h*.06
	local modal_g = display.newGroup()
	local modal_bg = create_background(dsp_w*.05, 0, dsp_w*.9, 0, 20, {0.2, 0.5, 0.8, .4})
	modal_g:insert(modal_bg)
	local lbl = create_label(modal_bg.x, modal_bg.y+5, modal_bg.width, lbl_gfs_0, title, "center", {0,0,0,.9})
	modal_g:insert(lbl)
	pos_y = modal_g.y+lbl.height
	for i=1, #booking_modes do
		rad_state = false
		if(val == booking_modes[i]) then
			rad_state = true
		end

		local alpha = .4
		if(i%2 == 1) then
			alpha = .6
		end
		
		local item_bg = create_background(0, pos_y, dsp_w, list_h, 0, {0.2, 0.5, 0.8, 0})
		local chk_box = widget.newSwitch(
			{
				left = dsp_w*.05,
				top = 0,
				width = dsp_w*.1,
				height = dsp_w*.1,
				style = "radio",
				id = booking_modes[i],
				initialSwitchState = rad_state,
				sheet = checkboxSheet,
				frameOff = 1,
				frameOn = 2,
				onPress = selected_option
			}
		)
		
		chk_box.y = item_bg.y+((item_bg.height-chk_box.height)*.5)
		anchor(chk_box)

		lbl = create_label(chk_box.x+(chk_box.width*1.2), 0, dsp_w, lbl_gfs_1, booking_modes[i], "left", {0.1,0.1,0.1,.9})
		lbl.y = item_bg.y+((item_bg.height-lbl.height)*.5)

		pos_y = pos_y+list_h
		modal_g:insert(item_bg)
		modal_g:insert(chk_box)
		modal_g:insert(lbl)

	end
	local lbl_close = create_label(modal_bg.x, pos_y, modal_bg.width*.5, lbl_gfs_1, "Close", "center", {0,0,0,.8})
	lbl_close:addEventListener( "tap", init_hide_popup )
	lbl_close.x = modal_bg.x+(modal_bg.width-lbl_close.width)
	modal_g:insert(lbl_close)
	pos_y = pos_y+list_h
	sc_view:insert(modal_g)
	modal_bg.height = pos_y
	modal_g.y = (sc_view.height-modal_g.height)*.5
	sc_view:setScrollHeight(modal_g.height)
end

local function time_list(val, title)
	local mt = dsp_h*.06
	local modal_g = display.newGroup()
	local modal_bg = create_background(dsp_w*.05, 0, dsp_w*.9, 0, 20, {0.2, 0.5, 0.8, .4})
	modal_g:insert(modal_bg)
	local lbl = create_label(modal_bg.x, modal_bg.y+5, modal_bg.width, lbl_gfs_0, title, "center", {0,0,0,.9})
	modal_g:insert(lbl)
	pos_y = modal_g.y+lbl.height

	local time_dsp = ""
	local tmp_time_list = {}
	local start_ind = 1
	local end_ind = 24
	for i = 1, 24 do
		if(i==12)then
			time_dsp = i..":00 nn"
		elseif(i==24)then
			time_dsp = i..":00 mn"
		elseif(i>12)then
			time_dsp = (i-12)..":00 pm"
		else
			time_dsp = i..":00 am"
		end

		tmp_time_list[i] = time_dsp

		if(booking_dt[sched_day][1] == time_dsp) then
			start_ind = i
		end
		
		if(booking_dt[sched_day][2] == time_dsp) then
			start_end = i
		end
	end
	
	for i=start_ind, start_end do
		rad_state = false
		if(val == tmp_time_list[i]) then
			rad_state = true
		end

		local alpha = .4
		if(i%2 == 1) then
			alpha = .6
		end
		
		local item_bg = create_background(0, pos_y, dsp_w, list_h, 0, {0.2, 0.5, 0.8, 0})
		local chk_box = widget.newSwitch(
			{
				left = dsp_w*.05,
				top = 0,
				width = dsp_w*.1,
				height = dsp_w*.1,
				style = "radio",
				id = tmp_time_list[i],
				initialSwitchState = rad_state,
				sheet = checkboxSheet,
				frameOff = 1,
				frameOn = 2,
				onPress = selected_option
			}
		)
		
		chk_box.y = item_bg.y+((item_bg.height-chk_box.height)*.5)
		anchor(chk_box)

		lbl = create_label(chk_box.x+(chk_box.width*1.2), 0, dsp_w, lbl_gfs_1, tmp_time_list[i], "left", {0.1,0.1,0.1,.9})
		lbl.y = item_bg.y+((item_bg.height-lbl.height)*.5)

		pos_y = pos_y+list_h
		modal_g:insert(item_bg)
		modal_g:insert(chk_box)
		modal_g:insert(lbl)

	end
	local lbl_close = create_label(modal_bg.x, pos_y, modal_bg.width*.5, lbl_gfs_1, "Close", "center", {0,0,0,.8})
	lbl_close:addEventListener( "tap", init_hide_popup )
	lbl_close.x = modal_bg.x+(modal_bg.width-lbl_close.width)
	modal_g:insert(lbl_close)
	pos_y = pos_y+list_h
	sc_view:insert(modal_g)
	modal_bg.height = pos_y

	local add_sc_view_h = 0
	if(modal_g.height+20>dsp_h) then
		add_sc_view_h = 40
		modal_g.y = add_sc_view_h*.5
	else
		modal_g.y = (sc_view.height-modal_g.height)*.5
	end
	
	sc_view:setScrollHeight(modal_g.height+add_sc_view_h)
end

function get_day_offs( event )
    if ( event.isError ) then
		scrn_msg:show("Network error!")
    else
		res_data = json.decode(event.response)
		for i=1, #res_data do
			day_off_data[res_data[i]['sched_date']] = res_data[i]['description']
		end
		
		local parse_arr = split_string(server_date, "-")
		tmp_cur_dd = tonumber(parse_arr[3])
		tmp_cur_mm = tonumber(parse_arr[2])
		tmp_cur_yr = tonumber(parse_arr[1])
		tmp_dd = tmp_cur_dd
		tmp_mm = tmp_cur_mm
		tmp_yr = tmp_cur_yr

		calendar_list()
	end
end

local function prev_month( event )
	tmp_mm = tmp_mm - 1
	if(tmp_mm <= 0) then
		tmp_mm = 12
		tmp_yr = tmp_yr - 1
	end
	calendar_list()
end

local function next_month( event )
	tmp_mm = tmp_mm + 1
	if(tmp_mm >= 13) then
		tmp_mm = 1
		tmp_yr = tmp_yr + 1
	end
	calendar_list()
end

function scene:create( event )

	local params = event.params
	pop_type = params.pop_type
	
	local g1 = dsp_w*.07
	local g2 = dsp_w*.05
	local m1 = dsp_w*.05
	local fw1 = dsp_w*.9

	scene_g = self.view
	anchor(scene_g)
	
	local cover_bg = std_page_background()
	scene_g:insert(cover_bg)
	local top_g = display.newGroup()
	local top_bg = create_background(0, 0, dsp_w, btn_h, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)
    --local lbl_page_title = create_label(5, 0, dsp_w, lbl_gfs_0, params.title, "left", {0,0,0,.8})
	--lbl_page_title.y = (top_bg.height-lbl_page_title.height)*.5
    --top_g:insert(lbl_page_title)

	local btn_icon = display.newImageRect("assets/images/slideup.png", 100, 100)
	anchor(btn_icon)
	btn_close = create_button("add","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_close.x = (dsp_w*.5)-(btn_close.width*.5)
	btn_close.y = (top_bg.height-btn_close.height)*.5
	btn_close:addEventListener( "tap", init_hide_popup )
	resize(btn_icon, btn_close, 0.2)
	btn_close:insert(btn_icon)
	top_g:insert(btn_close)

	local form_g = display.newGroup()
	local btn_g = display.newGroup()
	local btn_pos_y = 0
	if(pop_type ~= "pts_history" and pop_type ~= "pts_reward" and pop_type ~= "days_sched" and pop_type ~= "mode_sched" and pop_type ~= "dt_sched" and pop_type ~= "days_sched") then
		btn_cancel = create_button("cancel","Cancel", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
		btn_cancel.x = (dsp_w*.25)-(btn_cancel.width*.5)
		btn_cancel.y = 0
		btn_cancel:addEventListener( "tap", init_hide_popup )
		btn_g:insert(btn_cancel)

		btn_submit = create_button("submit","Submit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
		btn_submit.x = (dsp_w*.75)-(btn_cancel.width*.5)
		btn_submit.y = btn_cancel.y
		btn_submit:addEventListener( "tap", submit_profile_update )
		btn_g:insert(btn_submit)
	else
		sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
		sc_view.x = 0
    	sc_view.y = 0--top_g.height
		scene_g:insert(sc_view)
	end

	if(pop_type == "pts_history") then
		points_history()
	elseif(pop_type == "pts_reward") then
		points_reward_list()
	elseif(pop_type == "days_sched") then
		header_title = create_label(0, 0, dsp_w, lbl_gfs_0, "", "center", {0,0,0,.9})
		header_g:insert(header_title)
		local lbl_back = create_label(0, 0, dsp_w*.2, lbl_gfs_0, " <<", "left", {0,0,0,.9})
		header_g:insert(lbl_back)
		lbl_back:addEventListener( "tap", prev_month )
		local lbl_next = create_label(0, 0, dsp_w*.2, lbl_gfs_0, ">> ", "right", {0,0,0,.9})
		header_g:insert(lbl_next)
		lbl_next:addEventListener( "tap", next_month )
		lbl_next.x = dsp_w-lbl_next.width
		scene_g:insert(header_g)

		sc_view.height = sc_view.height-(header_g.height+btn_close.height)
		sc_view.y = header_g.height

		server_date = params.server_date
		sel_val = params.val
		--days_list(sel_val, params.title)
		network.request( host_url .. "get_day_off", "GET",  get_day_offs)
	elseif(pop_type == "mode_sched") then
		sel_val = params.val
		mode_list(sel_val, params.title)
	elseif(pop_type == "dt_sched") then
		sel_val = params.val
		time_list(sel_val, params.title)
	elseif(pop_type == "password") then
		password_secured = true

		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Old Password", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "Old Password")
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		lbl_show = create_btn_toggle(0, 0, 2, true)
		lbl_show.x = inp1.x+(inp1.width-lbl_show.width)
		lbl_show.y = lbl.y+((lbl.height-lbl_show.height)*.5)
		lbl_show:addEventListener( "tap", show_password )
		form_g:insert(lbl_show)

		lbl = create_label(m1, inp1.y+inp1.height+g1, fw1, lbl_gfs_2, "New Password", "left", {0,0,0,1})
		inp2 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "New Password")
		inp2.x = lbl.x
		inp2.y = lbl.y+lbl.height
		password_note = create_label(m1, inp2.y+(inp2.height*1.05), fw1, lbl_gfs_3, "", "left", {1,0.1,0,1})
		form_g:insert(lbl)
		form_g:insert(password_note)
		form_g:insert(inp2)

		lbl = create_label(m1, inp2.y+inp2.height+g1, fw1, lbl_gfs_2, "Re-entry Password", "left", {0,0,0,1})
		inp3 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", true, "default", "Re-entry Password")
		inp3.x = lbl.x
		inp3.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp3)
		btn_pos_y = inp3.y+inp3.height+g2

	elseif(pop_type == "cancel_reason") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Reason for cancellation", "left", {0,0,0,1})
		inp1 = create_input_multiline(lbl, .9, w1, dsp_h*.3, inp_gfs_5, "State here...")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "first_name") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "First Name", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "First Name")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "last_name") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Last Name", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "Last Name")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "email") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Email Address", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "Email Address")
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "mobile_no") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Mobile #", "left", {0,0,0,1})
		inp1 = create_input(lbl, 1.2, fw1, inp_gfs_2, "center", false, "default", "Mobile #")
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2

	elseif(pop_type == "address") then
		local lbl = create_label(m1, top_g.height, fw1, lbl_gfs_2, "Address", "left", {0,0,0,1})
		inp1 = create_input_multiline(lbl, 1, fw1, dsp_h*.2, inp_gfs_5, "Address")
		inp1:addEventListener( "userInput", mod_input_format )
		inp1.text = params.val
		inp1.x = lbl.x
		inp1.y = lbl.y+lbl.height
		form_g:insert(lbl)
		form_g:insert(inp1)
		btn_pos_y = inp1.y+inp1.height+g2
	end

	form_g.y = 0
	btn_g.y = btn_pos_y
	top_g.y = dsp_h-top_g.height

	scene_g:insert(top_g)
	scene_g:insert(form_g)
	scene_g:insert(btn_g)

	if(pop_type ~= "mode_sched" and pop_type ~= "dt_sched") then
		--lbl_page_title.text = ""
		scene_g.y = 0-scene_g.height
		transition.moveTo( scene_g, { y=0, time=300, transition = easing.inExpo } )
	else
		top_g.alpha=0
	end
end

function scene:show( event )
	--local scene_g = self.view
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
    --local sceneGroup = self.view
    local phase = event.phase
    local parent = event.parent  -- Reference to the parent scene object
    if ( phase == "will" ) then
		if(reset_session) then
			parent:force_logout()
		elseif(update_session) then
			parent:force_update()
		else
        	parent:hide_popup(sel_val, pop_type)
		end
    end
end

function scene:destroy( event )
	if(inp1 ~= nil) then
		inp1:removeSelf()
	end
	if(inp2 ~= nil) then
		inp2:removeSelf()
	end
	if(inp3 ~= nil) then
		inp3:removeSelf()
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
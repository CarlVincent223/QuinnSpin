dsp_w = display.contentWidth
dsp_h = display.contentHeight

api_key = "qlh-20080104"

on_android = false
if(system.getInfo( "platform" ) == "android") then
    on_android = true
end

on_simulator = (system.getInfo("environment")=="simulator")
if (on_simulator==false) then
    host_url = "https://quinns-laundry-house-jjum.onrender.com/"
else
    host_url = "https://quinns-laundry-house-jjum.onrender.com/"
end

enable_act = true
reloading_content = false
ntfy_status = false
fb_data = ""
data = ''
complete_msg = ''
page_change = 200
page_anim = ''
tmp_pin = ''
btn_h = dsp_w*.12 --Standard button height

booking_req_data = ""

current_page = ""
prev_page = ""
request_type = ""
request_data = ""
services_acquired = {}
new_msg = {}

bk_code = "QLH"
shop_mobile_num = "+639761082555"
shop_fb_id = "355944427611529"
shop_map = {}
shop_map['lat'] = 13.646271310102902
shop_map['lng'] = 123.20270205986043
shop_map['lbl'] = "Quinn's Laundry House"
cur_booking = ""
days_of_week_ind = {}
days_of_week_ind['Sunday'] = 1
days_of_week_ind['Monday'] = 2
days_of_week_ind['Tuesday'] = 3
days_of_week_ind['Wednesday'] = 4
days_of_week_ind['Thursday'] = 5
days_of_week_ind['Friday'] = 6
days_of_week_ind['Saturday'] = 7
days_of_week = { "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" }
months_list = { "January","February","March","April","May","June","July","August","September","October","November","December" }
months_days_list = { 31,29,31,30,31,30,31,31,30,31,30,31 }
booking_modes = { "Pickup","Drop off" }
booking_dt = {}
sched_date = ""
sched_day = "" --get_day_index(date.wday)
sched_time = ""
sched_mode = ""
sched_dt = ""

-- bg
bubble_bg = display.newImage("assets/images/quins_bubble_bg.png", 0, 0)
local scaleX = dsp_w / bubble_bg.width
local scaleY = dsp_h / bubble_bg.height
local scaleFactor = math.min(scaleX, scaleY)
bubble_bg:scale(scaleFactor, scaleFactor)
bubble_bg.x = display.contentCenterX
bubble_bg.y = display.contentCenterY
bubble_bg.alpha = 0.25
hl_bg0 = {0.2, 0.5, 0.8, 0}
hl_bg1 = {0.2, 0.5, 0.8, 1}
hl_bg2 = {0.2, 0.5, 0.8, .8}
hl_bg3 = {0.2, 0.5, 0.8, .7}
hl_bg4 = {0.2, 0.5, 0.8, .5}

txt_hl_blue1 = {0.2, 0.5, 0.8, 1}
txt_hl_white1 = {1, 1, 1, 1}
-- bg

-- icons hl
indc_hl_clr = {255/255,153/255,0/255,1}
indc_clr = {1,1,1,1}
-- icons hl

-- Fonts
gfont_bold = "assets/fonts/poppins/Poppins-Bold.ttf"
gfont_light = "assets/fonts/poppins/Poppins-Light.ttf"
gfont_med = "assets/fonts/poppins/Poppins-Medium.ttf"
gfont_reg = "assets/fonts/poppins/Poppins-Regular.ttf"
gfont_ita = "assets/fonts/poppins/Poppins-Italic.ttf"
gfont_semibold = "assets/fonts/poppins/Poppins-SemiBold.ttf"
-- Fonts

-- Fonts Size
lbl_gfs_0 = dsp_w*.08
lbl_gfs_1 = dsp_w*.06
lbl_gfs_2 = dsp_w*.05
lbl_gfs_3 = dsp_w*.04
lbl_gfs_4 = dsp_w*.03

inp_gfs_1 = dsp_w*.09
inp_gfs_2 = dsp_w*.075
inp_gfs_3 = dsp_w*.07
inp_gfs_4 = dsp_w*.055
inp_gfs_5 = dsp_w*.05
inp_gfs_6 = dsp_w*.04
-- Fonts Size

-- Buttons fill color
btn_lbl_style_l = {1, 1, 1, 1}
btn_lbl_style_d = {0, 0, 0, 1}
btn_style_1 = { default={74/255, 145/255, 167/255, 1}, over={179/255, 204/255, 208/255, 1} }
btn_style_2 = { default={1, 0, 0, 1}, over={1, 0, 0, .7} }
btn_style_trans = { default={1,1,0,0}, over={0,0,0,0.2} }
-- Buttons fill color

-- Temporay arrays that are used globaly
user_token = ""
user = {}
products_list = {}
services_list = {}
addons_list = {}
-- Temporay arrays that are used globaly

reg_id = '' -- Temporary id storage during registration of new user
otp_resend_lmt = 60 -- OTP resend countdown limit
home_slides_ctr = 1 -- Home slide transition counter
home_slides_lmt = 20 -- Home slide transition delay
retry_ctr = 0
local scene_g
local scene = composer.newScene()
local completion_g

function add_new_booking(event)
    composer.removeScene(composer.getSceneName( "current" ))
    composer.gotoScene("pages.booking")
end

function scene:create( event )
	scene_g = self.view
    completion_g = display.newGroup()

	lbl_msg = create_label(0, dsp_w, 22, "", "center")
    lbl_msg.text = complete_msg
    completion_g:insert(lbl_msg)
    completion_g.y = (dsp_h-completion_g.height)/2

    btn_addnew = create_button("done","DONE", dsp_w, dsp_w*.1, "Rect")
    btn_addnew.x = 0
    btn_addnew.y = dsp_h-btn_addnew.height
    btn_addnew:addEventListener( "tap", add_new_booking )

	scene_g:insert(completion_g)
    scene_g:insert(btn_addnew)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
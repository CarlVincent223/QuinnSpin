local scene_g
local scene = composer.newScene()
local completion_g

function close_msg_page(event)
	if(request_type == "login") then
		set_cache_account()
		change_page("pages.booked", "slideLeft")
	elseif(request_type == "signup" or request_type == "reset_password") then
		change_page("pages.login", "slideRight")
	elseif(request_type == "booking") then
		change_page("pages.booked", "slideLeft")
	end
	request_type = ""
end

function scene:create( event )
	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
    completion_g = display.newGroup()

	lbl_msg = create_label(0, 0, dsp_w*.9, 25, complete_msg, "center")
    lbl_msg.text = complete_msg
    completion_g:insert(lbl_msg)
    

    btn_done = create_button("done","OK", dsp_w*.3, btn_h, "roundedRect", 20, btn_style_1, gfont_med, 5)
    btn_done.x = lbl_msg.x+((lbl_msg.width-btn_done.width)/2)
    btn_done.y = lbl_msg.height+btn_done.height
    btn_done:addEventListener( "tap", close_msg_page )
	completion_g:insert(btn_done)

	completion_g.x = (dsp_w-completion_g.width)/2
	completion_g.y = (dsp_h-completion_g.height)/2
	scene_g:insert(bubble_bg)
	scene_g:insert(completion_g)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
local scene_g
local scene = composer.newScene()
local form_g
local inp_host
local btn_submit

function connect_local_server(event)
    if(check_input_form({trim_obj(inp_host)})) then
        retry_ctr = 0
        sc_view:removeSelf()
        host_url = trim_string(inp_host.text)
        change_page("pages.intro", "slideRight")
    end
end

function scene:create( event )
	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    btn_g = display.newGroup()
    
    local lbl_page_title = create_label(0, dsp_h*.1, dsp_w, 32, "Change Server", "center", {1,1,1,1}, gfont_bold)
    form_g:insert(lbl_page_title)
    
    local lbl = create_label(dsp_w*.15, lbl_page_title.y+(lbl_page_title.height*2), dsp_w*.7, 22, "", "center", {1,1,1,1})
    inp_host = create_input(lbl, 1.2, dsp_w*.7, 32, "center", false, "default", "Server URL")
    inp_host.text = host_url
    form_g:insert(lbl)
    form_g:insert(inp_host)

    btn_submit = create_button("submit","Connect", dsp_w*.3, btn_h, "roundedRect", 20, btn_style_1, gfont_med, 5)
    btn_submit.x = (dsp_w*.5)-(btn_submit.width*.5)
    btn_submit.y = inp_host.y+(inp_host.height*2.8)
    btn_submit:addEventListener( "tap", connect_local_server )
    form_g:insert(btn_submit)

    sc_view.x = 0
    sc_view.y = 0
    sc_view:setScrollHeight(form_g.height*1.1)
    local form_bg = create_background(dsp_w*.1, dsp_h*.05, dsp_w*.8, form_g.height*1.3, 25, {17/255,120/255,196/255,1})
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
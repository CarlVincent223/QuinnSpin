local scene_g
local scene = composer.newScene()
local completion_g

function scene:create( event )
	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
    completion_g = display.newGroup()

	scene_g:insert(bubble_bg)
	scene_g:insert(completion_g)

    composer.removeScene(composer.getSceneName( "current" ))     
    composer.gotoScene("pages.profile")
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
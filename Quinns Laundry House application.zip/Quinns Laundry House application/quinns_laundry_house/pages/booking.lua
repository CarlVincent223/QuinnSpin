local scene_g
local scene = composer.newScene()
local sc_view
local form_g
local inp_client_name
local inp_mobile_no
local inp_pickup_loc
local inp_notes
local btn_back
local btn_cancel
local btn_submit
local server_date
local lbl_days
local lbl_mode
local lbl_cnt
local btn_opt_dt
local lbl_dt

local function send_booking( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        complete_msg = "Booking complete\n\nYour reference number\n\n" .. event.response
        request_type = "booking"
        change_page("pages.request_completed", "slideLeft")
    end

end

local function submit_booking(event)
    local items = ""
    local i = 1
    local tmp_services = ""
    local tmp_addons = ""
    services_acquired['services_availed'] = ""
    for key, value in pairs(services_acquired) do
        if(value == true) then
            items = items .. '"' .. i .. '":"' .. key .. '",'
            if(services_list[key] ~= nil) then
                services_acquired['services_title'] = services_list[key]['title']
                tmp_services = "• " .. services_list[key]['sub_title'] .. "\n" .. tmp_services
            else
                tmp_addons = "   " .. addons_list[key]['desc'] .. "\n" .. tmp_addons
            end
            i = i + 1
        end
    end  
    services_acquired['services_availed'] = tmp_services .. tmp_addons
    
    if(items ~= "") then
        native.showAlert("Notice","Select a services",{"OK"})
    elseif(check_input_form({trim_obj(inp_client_name), trim_obj(inp_mobile_no), trim_obj(inp_pickup_loc)})) then
        items = items:sub( 1, items:len()-1) 

        services_acquired['sched'] = sched_day
        services_acquired['mode'] = sched_mode
        services_acquired['dt'] = sched_dt
        services_acquired['client'] = trim_string(inp_client_name.text)
        services_acquired['contact'] = trim_string(inp_mobile_no.text)
        services_acquired['addr'] = trim_string(inp_pickup_loc.text)
        services_acquired['notes'] = trim_string(inp_notes.text)
        
		services_acquired['sched_date'] = sched_date --get_sched_date(server_date, get_day_index())
        
        booking_req_data = '{"uid":"' .. user.id .. '","quantity":"' .. services_acquired['qty'] .. '","sched":"' .. services_acquired['sched'] .. '","sched_date":"' .. services_acquired['sched_date'] .. '","mode":"' .. services_acquired['mode'] .. '","client":"' .. services_acquired['client'] .. '","contact":"' .. services_acquired['contact'] .. '","ploc":"' .. services_acquired['addr'] .. '","notes":"' .. services_acquired['notes'] .. '","dt":"' .. services_acquired['dt'] .. '"}'
        if(server_date ~= nil) then
            change_page("pages.booking_confirmation", "slideLeft")
        else
            scrn_msg:show("Network error!")
        end

    else
        native.showAlert("Notice","Invalid inputs",{"OK"})
    end
end

local function cancel_booking(event)
    -- revert_page()
    change_page("pages.booked", "slideRight")
end

local function listEventsListener(event)
    if event.isError then
        scrn_msg:show("Network error!")
    else
        for i, eventData in ipairs(event.events) do
            print("Event Title: " .. eventData.title)
            print("Start Date: " .. os.date("%c", eventData.startDate)) -- Format timestamp
        end
    end
end

local def_sch
local ext_margin = false
local function move_page_gui( event )
    if ( "began" == event.phase ) then
        sc_view:setScrollHeight(def_sch+(dsp_h*.3))
        --sc_view:scrollToPosition( { y = (0-(event.target.y+event.target.height))+dsp_h*.6, time = 0 } )
        --sc_view:setScrollHeight(form_g.height+(dsp_h*.6))
    elseif ( "ended" == event.phase or "submitted" == event.phase ) then
        sc_view:setScrollHeight(def_sch)
        --sc_view:scrollToPosition( { y = 0, time = 0 } )
        --sc_view:setScrollHeight(form_g.height*1.1)
        native.setKeyboardFocus( nil )
    end
    
    -- if ( "began" == event.phase ) then
    --     transition.moveTo( sc_view, { y=0-(dsp_h*.25), time=200, transition = easing.inExpo } )
    -- elseif ( "ended" == event.phase or "submitted" == event.phase ) then
    --     transition.moveTo( sc_view, { y=0, time=200, transition = easing.inExpo } )
    --     native.setKeyboardFocus( nil )
    -- end
end

local function hide_keyboard( event )
	native.setKeyboardFocus( nil )
end

local function get_server_datetime(event)
    processing_state({btn_back, btn_cancel, btn_submit}, true)
    if event.isError then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "") then
			local arr = json.decode(res)
            server_date = arr[1]
            --lbl_dt.text = set_datetime_format(get_sched_date(server_date, days_of_week_ind[sched_day]), "date")
            if(sched_date == "") then
                sched_date =  server_date
            end

            sched_day = get_day_str(sched_date) 
            
            if(sched_mode == "") then
                sched_mode = "Pickup"
            else
                if(sched_mode == "Drop off") then
                    lbl_dt.text = sched_dt
                else
                    lbl_dt.text = "--:--"
                end
            end
            
            lbl_days.text = set_datetime_format(sched_date, "date")
        end
    end
end

local function hide_native_input(pos_x)
    inp_client_name.x = pos_x
    inp_mobile_no.x = pos_x
    inp_pickup_loc.x = pos_x
    inp_notes.x = pos_x
end

local function open_popup(popup_name, params)
    hide_native_input(dsp_w)
	local popup_effects =
	{
		isModal = true,
		effect = "fade",
		time = 100,
		params = params
	}
	composer.showOverlay( popup_name , popup_effects )
end

local function view_days_sched(event)
	local popup_params = {
		pop_type = "days_sched",
		title = "Choose Day",
        val = sched_date,
        server_date = sched_date
	}
	open_popup("assist.popup_list", popup_params)
end

local function view_mode_sched(event)
	local popup_params = {
		pop_type = "mode_sched",
		title = "Choose Mode",
        val = sched_mode
	}
	open_popup("assist.popup_list", popup_params)
end

local function view_time_sched(event)
	local popup_params = {
		pop_type = "dt_sched",
		title = "Choose Time",
        val = sched_dt
	}
	open_popup("assist.popup_list", popup_params)
end

function scene:hide_popup(sel_val, val_type)
    if(val_type == "mode_sched") then
        sched_mode = sel_val
        lbl_mode.text = sched_mode
        sched_dt = booking_dt[sched_day][1]
    elseif(val_type == "days_sched") then
        --sched_day = sel_val
        sched_date = sel_val
        sched_day = get_day_str(sel_val)
        lbl_days.text = set_datetime_format(sel_val, "date")
        sched_dt = booking_dt[sched_day][1]
        --lbl_days.text = set_datetime_format(get_sched_date(server_date, days_of_week_ind[sched_day]), "date")
    elseif(val_type == "dt_sched") then
        sched_dt = sel_val
        lbl_dt.text = sched_dt
    end

    if(sched_mode == "Pickup") then
        btn_opt_dt.alpha = 0
        sched_dt = ""
        lbl_dt.text = "--:--"
    else
        btn_opt_dt.alpha = 1
        lbl_dt.text = sched_dt
    end

    --lbl_dt.text = set_datetime_format(get_sched_date(server_date, days_of_week_ind[sched_day]), "date") .. "   " .. sched_dt
	hide_native_input(dsp_w*.1)
end

local function qty_increment(event)
	services_acquired['qty'] = services_acquired['qty'] + 1
    lbl_cnt.text = services_acquired['qty']
end

local function qty_decrement(event)
    if(services_acquired['qty'] > 1) then
	    services_acquired['qty'] = services_acquired['qty'] - 1
        lbl_cnt.text = services_acquired['qty']
    end
end

function scene:create( event )
    if(sched_mode == "") then
        sched_mode = "Pickup"
    end
    --sched_dt = ""

	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    bg:addEventListener( "tap", hide_keyboard )
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    local top_g = display.newGroup()

    local header_bg = create_background(0, 0-(dsp_h*.88), dsp_w, dsp_h, 0, {0.2, 0.5, 0.8, 1})
    --local header_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	form_g:insert(header_bg)

    local lbl_page_title = create_label(0, 0, dsp_w, lbl_gfs_0*.9, "Create Booking", "center", {1, 1, 1, 1})
    lbl_page_title.y = ((dsp_h*.12)-(lbl_page_title.height+10))
    form_g:insert(lbl_page_title)

    local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 10
	btn_back.y = ((dsp_h*.12)-(btn_back.height+10))
	btn_back:addEventListener( "tap", cancel_booking )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	form_g:insert(btn_back)

    local tmp_y = lbl_page_title.y+(lbl_page_title.height*1.7)
    local m1 = dsp_w*.08
    local w1 = dsp_w*.84

    local lbl = create_label(m1, tmp_y, w1, lbl_gfs_1, "Basket", "left", txt_hl_blue1)
    lbl_cnt = create_label(0, tmp_y, dsp_w*.3, lbl_gfs_2, services_acquired['qty'], "center")
    lbl_cnt.x = (lbl.x+lbl.width)-lbl_cnt.width
    local cnt_bg = create_background(lbl_cnt.x-(lbl_cnt.width*.08), lbl_cnt.y, lbl_cnt.width*1.1, lbl_cnt.height, 0, hl_bg0)
    cnt_bg.strokeWidth = 1.5
    cnt_bg:setStrokeColor( 0.5, 0.5, 0.5, 1 )

    local btn_plus = create_label(0, tmp_y, lbl_cnt.width*.25, lbl_gfs_1, "+", "center")
    btn_plus.x = (lbl_cnt.x+lbl_cnt.width)-btn_plus.width
    btn_plus:addEventListener( "tap", qty_increment )
    
    local btn_minus = create_label(lbl_cnt.x, tmp_y, lbl_cnt.width*.25, lbl_gfs_1, "-", "center")
    btn_minus:addEventListener( "tap", qty_decrement )

    form_g:insert(cnt_bg)
    form_g:insert(lbl)
    form_g:insert(lbl_cnt)
    form_g:insert(btn_minus)
    form_g:insert(btn_plus)
    

    lbl = create_label(m1, lbl.y+(lbl.height*1.5), w1, lbl_gfs_1, "Schedule", "left", txt_hl_blue1)

    lbl_days = create_label(dsp_w*.1, lbl.y+lbl.height, dsp_w*.8, lbl_gfs_2, sched_day, "left")
    local sched_bg = create_background(m1, lbl_days.y, w1, lbl_days.height, 0, hl_bg0)
    sched_bg.strokeWidth = 1.5
    sched_bg:setStrokeColor( 0.5, 0.5, 0.5, 1 )
    form_g:insert(sched_bg)

    local btn_opt_days = create_label(lbl_days.x, lbl_days.y, lbl_days.width*.95, lbl_gfs_2, ". . .", "right")
    btn_opt_days:addEventListener( "tap", view_days_sched )

    lbl_mode = create_label(dsp_w*.1, lbl_days.y+(lbl_days.height*1.4), dsp_w*.8, lbl_gfs_2, sched_mode, "left")
    sched_bg = create_background(m1, lbl_mode.y, w1, lbl_mode.height, 0, hl_bg0)
    sched_bg.strokeWidth = 1.5
    sched_bg:setStrokeColor( 0.5, 0.5, 0.5, 1 )
    form_g:insert(sched_bg)

    local btn_opt_mode = create_label(lbl_mode.x, lbl_mode.y, lbl_mode.width*.95, lbl_gfs_2, ". . .", "right")
    btn_opt_mode:addEventListener( "tap", view_mode_sched )

    lbl_dt = create_label(dsp_w*.1, lbl_mode.y+(lbl_mode.height*1.4), dsp_w*.8, lbl_gfs_2, sched_dt, "left")
    sched_bg = create_background(m1, lbl_dt.y, w1, lbl_dt.height, 0, hl_bg0)
    sched_bg.strokeWidth = 1.5
    sched_bg:setStrokeColor( 0.5, 0.5, 0.5, 1 )
    form_g:insert(sched_bg)

    btn_opt_dt = create_label(lbl_dt.x, lbl_dt.y, lbl_dt.width*.95, lbl_gfs_2, ". . .", "right")
    btn_opt_dt:addEventListener( "tap", view_time_sched )

    if(sched_mode == "Pickup") then
        btn_opt_dt.alpha = 0
    end

    form_g:insert(lbl)
    form_g:insert(lbl_days)
    form_g:insert(lbl_mode)
    form_g:insert(lbl_dt)
    form_g:insert(btn_opt_days)
    form_g:insert(btn_opt_mode)
    form_g:insert(btn_opt_dt)
    
    lbl = create_label(m1, sched_bg.y+(sched_bg.height*1.2), w1, lbl_gfs_1, "Client", "left", txt_hl_blue1)
    inp_client_name = create_input(lbl, .9, w1, inp_gfs_2, "left", false, "default", "Name")
    inp_client_name.text = user.first_name .. " " ..user.last_name
    inp_client_name:addEventListener( "userInput", mod_input_format )
    --if (on_simulator==false and on_android) then
        --inp_client_name:addEventListener( "userInput", move_page_gui )
    --end
    form_g:insert(lbl)
    form_g:insert(inp_client_name)

    lbl = create_label(m1, inp_client_name.y+(inp_client_name.height*1.2), w1, lbl_gfs_1, "Contact", "left", txt_hl_blue1)
    inp_mobile_no = create_input(lbl, .9, w1, inp_gfs_2, "left", false, "default", "Mobile #")
    inp_mobile_no.text = user.mobile_no
    if (on_simulator==false and on_android) then
        inp_mobile_no:addEventListener( "userInput", move_page_gui )
    end
    form_g:insert(lbl)
    form_g:insert(inp_mobile_no)
    
    lbl = create_label(m1, inp_mobile_no.y+(inp_mobile_no.height*1.2), w1, lbl_gfs_1, "Address", "left", txt_hl_blue1)
    inp_pickup_loc = create_input_multiline(lbl, .9, w1, dsp_h*.2, inp_gfs_5, "Enter your address...")
    inp_pickup_loc.text = user.address
    inp_pickup_loc:addEventListener( "userInput", mod_input_format )
    if (on_simulator==false and on_android) then
        inp_pickup_loc:addEventListener( "userInput", move_page_gui )
    end
    form_g:insert(lbl)
    form_g:insert(inp_pickup_loc)

    lbl = create_label(m1, inp_pickup_loc.y+(inp_pickup_loc.height*1.1), w1, lbl_gfs_1, "Notes", "left", txt_hl_blue1)
    inp_notes = create_input_multiline(lbl, .9, w1, dsp_h*.2, inp_gfs_5, "Enter your notes...")
    inp_notes.text = services_acquired['notes']
    inp_notes:addEventListener( "userInput", mod_input_format )
    if (on_simulator==false and on_android) then
        inp_notes:addEventListener( "userInput", move_page_gui )
    end
    form_g:insert(lbl)
    form_g:insert(inp_notes)

    btn_cancel = create_button("cancel","Cancel", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_cancel.x = (dsp_w*.25)-(btn_cancel.width*.5)
    btn_cancel.y = (inp_notes.y+inp_notes.height)+btn_cancel.height
    btn_cancel:addEventListener( "tap", cancel_booking )
    form_g:insert(btn_cancel)

    btn_submit = create_button("submit","Submit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_submit.x = (dsp_w*.75)-(btn_cancel.width*.5)
    btn_submit.y = btn_cancel.y
    btn_submit:addEventListener( "tap", submit_booking )
    form_g:insert(btn_submit)

    sc_view.x = 0
    sc_view.y = 0
    def_sch = (form_g.height*1.02)-(dsp_h*.88)
    sc_view:setScrollHeight(def_sch)
    --sc_view:setScrollHeight(form_g.height+(top_g.height*1.5))
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
    scene_g:insert( top_g )

    processing_state({btn_back, btn_cancel, btn_submit}, false)
    network.request( host_url .. "server-datetime", "GET",  get_server_datetime)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
        native.setKeyboardFocus(nil)
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	inp_client_name:removeSelf()
    inp_mobile_no:removeSelf()
    inp_pickup_loc:removeSelf()
    inp_notes:removeSelf()
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
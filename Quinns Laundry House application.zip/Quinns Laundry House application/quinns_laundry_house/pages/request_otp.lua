local scene_g
local scene = composer.newScene()
local completion_g
local btn_resend
local otp_timer
local timer_ctr = 1
local lbl_resend_otp
local inp1
local inp2
local inp3
local inp4

local function validated_otp(event)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "invalid") then
            if(request_type == "reset_password") then
                complete_msg = "Congratulations!, your password has been reset."
            else
                complete_msg = "Account registration complete."
            end
            change_page("pages.request_completed", "slideLeft")
        else
            native.showAlert("Notice","Invalid pin",{"OK"})
        end
    end
end

local function submit_otp(event)
    local otp = inp1.text .. inp2.text .. inp3.text .. inp4.text
    if(otp ~= "") then
        local json_data
        if(request_type == "reset_password") then
            json_data = '{"user_id":"' .. reg_id .. '", "upass":"' .. request_data .. '", "otp":"' .. otp .. '"}'
            network.request( host_url .. "reset_password/" .. json_data, "POST",  validated_otp)
        else
            json_data = '{"user_id":"' .. reg_id .. '", "otp":"' .. otp .. '"}'
	        network.request( host_url .. "validate_otp/" .. json_data, "POST",  validated_otp)
        end
    else
        native.showAlert("Notice","Invalid input",{"OK"})
    end
end

local function otp_countdown(event)
    if(timer_ctr < 1) then
        timer.cancel(otp_timer)
        lbl_resend_otp.text = ""
        processing_state({btn_resend}, true)
    else
        timer_ctr = timer_ctr-1
        lbl_resend_otp.text = "Resend OTP in....("..timer_ctr..")"
    end
end

local function set_otp(event)
    if ( event.isError ) then
        print("failed")
    else
        local str_otp = event.response
        inp1.text = string.sub(str_otp, 1, 1)
        inp2.text = string.sub(str_otp, 2, 2)
        inp3.text = string.sub(str_otp, 3, 3)
        inp4.text = string.sub(str_otp, 4, 4)

        timer_ctr = otp_resend_lmt
        otp_timer = timer.performWithDelay(1000, otp_countdown, -1)
    end
end

local function key_input( event )
    if event.phase == "began" then
        -- Optional: Code to execute when editing begins
        event.target.text = ""
    elseif event.phase == "ended" then
        -- Optional: Code to execute when editing ends
    elseif event.phase == "submitted" then
        -- Optional: Code to execute when the return key is pressed  
    elseif event.phase == "editing" then
        -- Optional: Code to execute while editing
        if(event.target.id == 1) then
            native.setKeyboardFocus( inp2 )
        elseif(event.target.id == 2) then
            native.setKeyboardFocus( inp3 )
        elseif(event.target.id == 3) then
            native.setKeyboardFocus( inp4 )
        elseif(event.target.id == 4) then
            native.setKeyboardFocus( nil )
        end
    end
end

local function generate_otp()
    processing_state({btn_resend}, false)
    local json_data  = '{"user_id":"' .. reg_id .. '"}'
	network.request( host_url .. "get_otp/" .. json_data, "POST",  set_otp)
end

local function resend_otp(event)
    if(timer_ctr == 0) then
        generate_otp()
    end
end

function scene:create( event )
    local g1 = dsp_h*.05

	scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    completion_g = display.newGroup()

	local lbl = create_label(0, 0, dsp_w, lbl_gfs_0, "Enter your (OTP)\nOne Time Pin", "center")
    completion_g:insert(lbl)

    local secure_inp = true
    local inp_w = dsp_w*.1
    local inp_gap = 1
    local inp_size = 40
    inp1 = create_input(lbl, inp_gap, inp_w, inp_size, "center", secure_inp, "default", "")
    inp1.x = inp_w*2.5
    inp1.y = inp1.y+g1
    inp1.id = 1
    inp1.inputType = "number"
    inp1:addEventListener("userInput", key_input)
    inp2 = create_input(lbl, inp_gap, inp_w, inp_size, "center", secure_inp, "default", "")
    inp2.x = inp1.x+(inp1.width*1.3)
    inp2.y = inp1.y
    inp2.id = 2
    inp2:addEventListener("userInput", key_input)
    inp3 = create_input(lbl, inp_gap, inp_w, inp_size, "center", secure_inp, "default", "")
    inp3.x = inp2.x+(inp2.width*1.3)
    inp3.y = inp1.y
    inp3.id = 3
    inp3:addEventListener("userInput", key_input)
    inp4 = create_input(lbl, inp_gap, inp_w, inp_size, "center", secure_inp, "default", "")
    inp4.x = inp3.x+(inp3.width*1.3)
    inp4.y = inp1.y
    inp4.id = 4
    inp4:addEventListener("userInput", key_input)
    completion_g:insert(inp1)
    completion_g:insert(inp2)
    completion_g:insert(inp3)
    completion_g:insert(inp4)

    if(tmp_pin ~= "") then
        inp1.text = tmp_pin:sub(1,1)
        inp2.text = tmp_pin:sub(2,2)
        inp3.text = tmp_pin:sub(3,3)
        inp4.text = tmp_pin:sub(4,4)
        native.setKeyboardFocus( nil )
    end

    lbl_resend_otp = create_label(0, inp4.y+inp4.height+g1, dsp_w, lbl_gfs_2, " ", "center")
    completion_g:insert(lbl_resend_otp)

    btn_resend = create_button("resend","Resend", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_resend.x = (dsp_w*.25)-(btn_resend.width*.5)
    btn_resend.y = lbl_resend_otp.y+g1+g1
    btn_resend:addEventListener( "tap", resend_otp )
    completion_g:insert(btn_resend)
    btn_submit = create_button("submit","Submit", dsp_w*.3, btn_h, "roundedRect", lbl_gfs_2, btn_style_1, gfont_med, 5)
    btn_submit.x = (dsp_w*.75)-(btn_submit.width*.5)
    btn_submit.y =  btn_resend.y
    btn_submit:addEventListener( "tap", submit_otp )
    completion_g:insert(btn_submit)

    --completion_g.x = (dsp_w-completion_g.width)-(completion_g.width/2)
    completion_g.y = (dsp_h*.5)-(completion_g.height/2)

    scene_g:insert(bubble_bg)
	scene_g:insert(completion_g)
    
    generate_otp()
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
    inp1:removeSelf()
    inp2:removeSelf()
    inp3:removeSelf()
    inp4:removeSelf()
	timer.cancel(otp_timer)
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
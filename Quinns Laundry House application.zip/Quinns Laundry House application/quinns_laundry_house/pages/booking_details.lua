local scene_g
local scene = composer.newScene()
local form_g
local btn_back
local btn_cancel
local booking_tracks = {}
local booking_payments = {}

local function close_booking(event)
    if(enable_act) then
        change_page("pages.booked", "slideRight")
    end
end

local function cancel_booking_result( event )
    processing_state({btn_cancel, btn_back}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "valid") then
            native.showAlert( "Notice", "Unable to cancel?", { "OK" })
        else
            change_page("pages.booked", "slideRight")
        end
    end
end

function scene:hide_popup(sel_val, val_type)

end

local function open_popup(popup_name, params)
	local popup_effects =
	{
		isModal = true,
		effect = "fade",
		time = 100,
		params = params
	}
	composer.showOverlay( popup_name , popup_effects )
end

local function on_cancel_booking(event)
    if ( event.action == "clicked" ) then
        local i = event.index
        if ( i == 1 ) then
            local json_data = '{"key":"' .. api_key .. '","id":"' .. cur_booking .. '"}'
            --processing_state({btn_cancel, btn_back}, false)
            --network.request( host_url .. "cancel_booking/" .. json_data, "POST",  cancel_booking_result)
            local popup_params = {
                pop_type = "cancel_reason",
                title = "Enter Your Reason",
                val = sched_dt
            }
            open_popup("assist.popup_list", popup_params)

        elseif ( i == 2 ) then
			return false
        end
    end
end

local function cancel_booking(event)
    if(enable_act) then
        native.showAlert( "Confirmation!", "Are you sure you want to cancel this booking?", { "Yes", "No" }, on_cancel_booking)
    end
end

local function display_booking_details(booking_details, booking_products)
    
    local gap_y = 10
    local services_g = display.newGroup()
    services_g.y = dsp_h*.15
    form_g:insert(services_g)

    local mgl = dsp_w*.08
    local start_y = 0
    local lbl

    if(#booking_products ~= 0) then
        lbl = create_label(mgl, start_y, dsp_w*.9, lbl_gfs_1, "Product Availed", "left", txt_hl_blue1, gfont_med)
        services_g:insert(lbl)

        local service_amt = 0
        for i=1, #booking_products do
            lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_products[i]['title'], "left")
            services_g:insert(lbl)
            lbl = create_label(dsp_w*.1, lbl.y+(lbl.height*.9), dsp_w*.8, lbl_gfs_3, booking_products[i]['description'], "left", {0.3,0.3,0.3,1}, gfont_ita)
            services_g:insert(lbl)
            if(booking_products[i]['unit'] == "none") then
                lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "P "..booking_products[i]['price'], "left")
            else
                lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "P "..booking_products[i]['price'].." / "..booking_products[i]['quantity']..booking_products[i]['unit'], "left")
            end
            services_g:insert(lbl)
            lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "x"..booking_products[i]['item_qty'], "right")
            services_g:insert(lbl)

            service_amt = service_amt + (booking_products[i]['price']*booking_products[i]['item_qty'])
        end        

        lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Billing", "left", txt_hl_blue1, gfont_med)
        services_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "Service Fee", "left")
        services_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "P "..string.format("%.2f", service_amt), "right")
        services_g:insert(lbl)

        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "Logistics Fee", "left")
        services_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "P "..booking_details[1]['logistics_fee'], "right")
        services_g:insert(lbl)

        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "Total", "left")
        services_g:insert(lbl)
        lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, "P "..string.format("%.2f", (service_amt+tonumber(booking_details[1]['logistics_fee']))), "right")
        services_g:insert(lbl)

        start_y = lbl.y+lbl.height+gap_y
    end

    lbl = create_label(mgl, start_y, dsp_w*.9, lbl_gfs_1, "Scheduled", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details[1]['schedule'], "left")
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, set_datetime_format(booking_details[1]['sched'], "date"), "right")
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details[1]['mode'], "left")
    services_g:insert(lbl)

    if(booking_details[1]['mode']=="Drop off" and booking_details[1]['dropoff_time'] ~= nil) then
        lbl = create_label(dsp_w*.1, lbl.y, dsp_w*.8, lbl_gfs_2, booking_details[1]['dropoff_time'], "right")
        services_g:insert(lbl)
    end

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Client", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details[1]['client'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Contact", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details[1]['contact'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Address", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, booking_details[1]['pickup_loc'], "left")
    services_g:insert(lbl)

    lbl = create_label(mgl, lbl.y+lbl.height+gap_y, dsp_w*.9, lbl_gfs_1, "Tracking", "left", txt_hl_blue1, gfont_med)
    services_g:insert(lbl)
    
    if(booking_details[1]['status'] ~= "Cancelled") then
        local stat_icon
        local div_line
        local str_stat = ""
        if(booking_details[1]['accepted'] == nil) then
            stat_icon = create_image_rec(dsp_w*.1, lbl.y+lbl.height+gap_y, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/confirmed_normal.png") 
            str_stat = "Confirmed"
        else
            stat_icon = create_image_rec(dsp_w*.1, lbl.y+lbl.height+gap_y, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/confirmed_hl.png")
            str_stat = "Confirmed\n"..set_datetime_format(booking_details[1]['accepted'], "datetime")
        end
        lbl = create_label(mgl, stat_icon.y, dsp_w*.8, lbl_gfs_3, str_stat, "right", {0.3,0.3,0.3,1}, gfont_ita)
        div_line = create_div_hline(stat_icon.x, stat_icon.y+(stat_icon.height*.5), dsp_w*.9, stat_icon.y+(stat_icon.height*.5), 2, {0, 0.4, 1, 1})
        services_g:insert(div_line)
        services_g:insert(lbl)
        services_g:insert(stat_icon)

        if(booking_details[1]['mode'] == "Pickup") then
            if(booking_details[1]['pickup'] == nil) then
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped_normal.png")
                str_stat = "Pickup"
            else
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped_hl.png")
                str_stat = "Pickup\n"..set_datetime_format(booking_details[1]['pickup'], "datetime")
            end
        else
            if(booking_details[1]['arrived'] == nil) then
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff_normal.png")
                str_stat = "Arrived"
            else
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff_hl.png")
                str_stat = "Arrived\n"..set_datetime_format(booking_details[1]['arrived'], "datetime")
            end
        end
        lbl = create_label(mgl, stat_icon.y, dsp_w*.8, lbl_gfs_3, str_stat, "right", {0.3,0.3,0.3,1}, gfont_ita)
        div_line = create_div_hline(stat_icon.x, stat_icon.y+(stat_icon.height*.5), dsp_w*.9, stat_icon.y+(stat_icon.height*.5), 2, {0, 0.4, 1, 1})
        services_g:insert(div_line)
        services_g:insert(lbl)
        services_g:insert(stat_icon)
        
        if(booking_details[1]['processing'] == nil) then
            stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/processing_normal.png")
            str_stat = "Processing"
        else
            stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/processing_hl.png")
            str_stat = "Processing\n"..set_datetime_format(booking_details[1]['processing'], "datetime")
        end
        lbl = create_label(mgl, stat_icon.y, dsp_w*.8, lbl_gfs_3, str_stat, "right", {0.3,0.3,0.3,1}, gfont_ita)
        div_line = create_div_hline(stat_icon.x, stat_icon.y+(stat_icon.height*.5), dsp_w*.9, stat_icon.y+(stat_icon.height*.5), 2, {0, 0.4, 1, 1})
        services_g:insert(div_line)
        services_g:insert(lbl)
        services_g:insert(stat_icon)

        if(booking_details[1]['outgoing'] == nil) then
            if(booking_details[1]['mode'] == "Pickup") then
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped_normal.png")
                str_stat = "Delivery"
            else
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff_normal.png")
                str_stat = "To Received"
            end
        else
            if(booking_details[1]['mode'] == "Pickup") then
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped_hl.png")
                str_stat = "Delivery\n"..set_datetime_format(booking_details[1]['outgoing'], "datetime")
            else
                stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff_hl.png")
                str_stat = "To Received\n"..set_datetime_format(booking_details[1]['outgoing'], "datetime")
            end
        end
        lbl = create_label(mgl, stat_icon.y, dsp_w*.8, lbl_gfs_3, str_stat, "right", {0.3,0.3,0.3,1}, gfont_ita)
        div_line = create_div_hline(stat_icon.x, stat_icon.y+(stat_icon.height*.5), dsp_w*.9, stat_icon.y+(stat_icon.height*.5), 2, {0, 0.4, 1, 1})
        services_g:insert(div_line)
        services_g:insert(lbl)
        services_g:insert(stat_icon)

        if(booking_details[1]['completed'] == nil) then
            stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/completed_normal.png")
            str_stat = "Completed"
        else
            stat_icon = create_image_rec(dsp_w*.1, stat_icon.y+(stat_icon.height*2), lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/completed_hl.png")
            str_stat = "Completed\n"..set_datetime_format(booking_details[1]['completed'], "datetime")
        end
        lbl = create_label(mgl, stat_icon.y, dsp_w*.8, lbl_gfs_3, str_stat, "right", {0.3,0.3,0.3,1}, gfont_ita)
        div_line = create_div_hline(stat_icon.x, stat_icon.y+(stat_icon.height*.5), dsp_w*.9, stat_icon.y+(stat_icon.height*.5), 2, {0, 0.4, 1, 1})
        services_g:insert(div_line)
        services_g:insert(lbl)
        services_g:insert(stat_icon)

        sc_height = (stat_icon.y+stat_icon.height)+(dsp_h*0.2)
        if(booking_details[1]['status'] == "Pending" or booking_details[1]['status'] == "Confirmed") then
            btn_cancel = create_button("cancel","Cancel", dsp_w*.7, btn_h, "roundedRect", lbl_gfs_2, btn_style_2, gfont_med, 5)
            btn_cancel.x = dsp_w*.15
            btn_cancel.y = stat_icon.y+(stat_icon.height*2)
            btn_cancel:addEventListener( "tap", cancel_booking )
            services_g:insert(btn_cancel)
            sc_height = (btn_cancel.y+btn_cancel.height)+(dsp_h*0.2)
        end
    else
        lbl = create_label(dsp_w*.1, lbl.y+lbl.height+gap_y, dsp_w*.8, lbl_gfs_2, "Status: Cancelled\nCancelled by: " .. force_capital_letter(booking_details[1]['cancelled_by']) .. "\nDate: " .. set_datetime_format(booking_details[1]['cancelled'], "datetime") .. "\nReason: " .. force_capital_letter(booking_details[1]['cancel_reason']), "left")
        services_g:insert(lbl)
        sc_height = (lbl.y+lbl.height)+(dsp_h*0.2)
    end

    sc_view:setScrollHeight(sc_height)
end

local function load_booking_details( event )
    processing_state({btn_back}, true)
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "") then
            arr = json.decode(res)
            display_booking_details(arr[1], arr[2])
        end
    end
end

function scene:create( event )

    scene_g = self.view
    local bg = std_page_background()
	scene_g:insert(bg)
    sc_view = create_scroll_view(0, 0, dsp_w, dsp_h, 0)
    form_g = display.newGroup()
    local top_g = display.newGroup()

    local header_bg = create_background(0, 0, dsp_w, dsp_h*.12, 0, {0.2, 0.5, 0.8, 1})
	top_g:insert(header_bg)

    local lbl_page_title = create_label(0, 30, dsp_w, lbl_gfs_0*.9, set_code_format("QLH", cur_booking, 5), "center", {1,1,1,1})
    lbl_page_title.y = ((dsp_h*.12)-(lbl_page_title.height+10))
    top_g:insert(lbl_page_title)

    local btn_icon = display.newImageRect("assets/images/back.png", 100, 100)
	anchor(btn_icon)
	btn_back = create_button("back","", dsp_w*.12, dsp_w*.12, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.12)
	btn_back.x = 10
	btn_back.y = ((dsp_h*.12)-(btn_back.height+10))
	btn_back:addEventListener( "tap", close_booking )
	resize(btn_icon, btn_back, 0.2)
	btn_back:insert(btn_icon)
	top_g:insert(btn_back)

    sc_view.x = 0
    sc_view.y = 0
    local form_bg = create_background(dsp_w*.05, lbl_page_title.y-10, dsp_w*.9, form_g.height*1.05, 25, {217/255,217/255,217/255,0})
    sc_view:insert(form_bg)
    sc_view:insert( form_g )
    scene_g:insert(bubble_bg)
    scene_g:insert(sc_view)
    scene_g:insert( top_g )

    processing_state({btn_back}, false)
    local json_data = '{"key":"' .. api_key .. '","id":"' .. cur_booking .. '"}'
	network.request( host_url .. "get_booking_details/" .. json_data, "GET",  load_booking_details)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
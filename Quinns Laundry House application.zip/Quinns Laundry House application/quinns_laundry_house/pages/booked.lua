local scene_g
local scene = composer.newScene()

--local btn_back
local btn_add

local slides = {}
local indc = {}
local indc_lbl = {}
local users_bookings = {}
local list_index = {}
local pos_y=20
local mutiplier = {}
local addon_dry = {}
local total_service_fee = {}
local total_addon_fee = {}
local msg_ntfy = {}
local msg_container_g = display.newGroup()
local cur_index = 1
local list_inc = 7
local list_range = list_inc

local function open_threads(event)
	if(enable_act) then
		cur_booking = event.target.id
		new_msg[cur_booking] = 0
		change_page("pages.threads", "slideLeft")
	end
end

local function open_booking(event)
	if(enable_act) then
		cur_booking = event.target.id
		change_page("pages.booking_details", "slideLeft")
	end
end

local function create_new(event)
	if(enable_act) then
		sched_date = ""
		sched_day = ""
		sched_time = ""
		sched_mode = ""
		sched_dt = ""

		reset_services_acquired()
		services_acquired['qty'] = 1
		change_page("pages.booking", "slideLeft")
	end
end

local function check_status_icon(val)
	if(val ~= nil) then
		return "_hl"
	else
		return "_normal"
	end
end

local function create_booking_list(x, y, w, h, data, stat)
	
	-- local booked_g = display.newGroup()
	-- local clr = {0.9,0.9,0.9,1} --{1,0.6,0,1} -- yellow
	-- -- if(stat == "Pending") then
	-- -- 	clr = {0.5, 0.5, 0.5, 1} -- gray
	-- -- elseif(stat == "Cancelled" or stat == "Declined") then
	-- -- 	clr = {1,0,0,1} -- red
	-- -- elseif(stat == "Completed") then
	-- -- 	clr = {0.2,0.6,0,1} -- green
	-- -- end

	h = lbl_gfs_0*5
	local booked_g = display.newGroup()
	local clr = nil
	if(stat == "Cancelled") then
		clr = {1,0.3,0.3,1}
	else
		clr = {0.9,0.9,0.9,1}
	end
	local clr_bg = {0.2, 0.5, 0.8, .4}
	local bg_cat = create_background(w*.05, 0, w, h, 10, clr)
	local bg_shadow = create_background(w*.06, w*.01, w, h, 10, clr_bg)
	
	m1 = bg_cat.width*.08
	--local item_title = create_label(m1, bg_cat.y, w*.95, dsp_w*.04,data['tstamp'], "right", {.1,.1,.1,1}, gfont_ita)
	local item_title = create_label(m1, bg_cat.y, w*.95, dsp_w*.04, set_datetime_format(data['tstamp'], "datetime"), "right", {.1,.1,.1,1}, gfont_ita)


	local item_id = create_label(m1, bg_cat.y, w*.95, dsp_w*.06, set_code_format("QLH", data['id'], 5), "left", txt_hl_blue1, gfont_med)
	local service_stat = create_label(m1, 0, w*.9, dsp_w*.05, stat, "left", {.3,.3,.3,1}, gfont_med)
	service_stat.y = bg_cat.height-(service_stat.height*1.2)

	local btn_icon = display.newImageRect("assets/images/message_env_dark.png", 35, 35)
	anchor(btn_icon)
	local btn_messages = create_button("message","", dsp_w*.1, dsp_w*.1, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.1)
	btn_messages.id = data['id']
	btn_messages:addEventListener( "tap", open_threads )
	resize(btn_icon, btn_messages, 0.2)
	btn_messages:insert(btn_icon)
	btn_messages.x = (bg_cat.x+bg_cat.width)-(btn_messages.width*1.2)
	btn_messages.y = service_stat.y-(service_stat.height*.1)
	
	btn_icon = display.newImageRect("assets/images/eye_dark.png", 35, 35)
	anchor(btn_icon)
	local btn_view = create_button("view","", dsp_w*.1, dsp_w*.1, "RoundedRect", 32, btn_style_trans, gfont_med, dsp_w*.1)
	btn_view.id = data['id']
	btn_view:addEventListener( "tap", open_booking )
	resize(btn_icon, btn_messages, 0.2)
	btn_view:insert(btn_icon)
	btn_view.x = btn_messages.x-(btn_messages.width*2)
	btn_view.y = service_stat.y-(service_stat.height*.1)

	booked_g:insert(bg_shadow)
	booked_g:insert(bg_cat)

	local stat_g = display.newGroup()
	local div_line = create_div_hline(bg_cat.x, bg_cat.y, bg_cat.width-m1, bg_cat.y, 2, {0, 0.4, 1, 1})
    stat_g:insert(div_line)

	stat_icon = create_image_rec(bg_cat.x, 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/confirmed"..check_status_icon(data['confirmed'])..".png")
	stat_g:insert(stat_icon)
	div_line.x = stat_icon.x
	div_line.y = stat_icon.y+(stat_icon.height*.5)
	
	if(data['mode'] == "Pickup") then
		stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.2), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped"..check_status_icon(data['pickup'])..".png")
	else
		stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.2), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff"..check_status_icon(data['dropoff'])..".png")
	end
	stat_g:insert(stat_icon)
	stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.4), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/processing"..check_status_icon(data['processing'])..".png")
	stat_g:insert(stat_icon)
	if(data['mode'] == "Pickup") then
		stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.6), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/shipped"..check_status_icon(data['delivery'])..".png")
	else
		stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.6), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/dropoff"..check_status_icon(data['delivery'])..".png")
	end
	stat_g:insert(stat_icon)
	stat_icon = create_image_rec(bg_cat.x+(bg_cat.width*.8), 0, lbl_gfs_0*1.5, lbl_gfs_0*1.5, "assets/images/status/completed"..check_status_icon(data['completed'])..".png")
	stat_g:insert(stat_icon)

	stat_g.x = (bg_cat.width-stat_g.width)*.5
	stat_g.y = (bg_cat.height*.5)-(stat_g.height*.5)

	booked_g:insert(stat_g)
	booked_g:insert(item_title)
	booked_g:insert(item_id)
	booked_g:insert(service_stat)
	booked_g:insert(btn_view)
	booked_g:insert(btn_messages)
	booked_g.y = pos_y
	pos_y = pos_y+booked_g.height+20

	msg_container_g:insert(booked_g)
end

local function load_booking_payments( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        --print(event.response, "<<")
    end
end

local function load_booking_tracks( event )
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        --print(event.response)
        local filter_data = '{"id":' .. services_acquired['id'] .. ',"sort":"booking_id ASC"}'
	    network.request( host_url .. "get_booking_payments/" .. filter_data, "GET",  load_booking_payments)
    end
end

local function show_items( event )
	list_range = list_range + list_inc
	processing_state({btn_add}, true)
	reload_user_bookings()
end

local function display_booked_list()
	for i=1, #list_index do
		create_booking_list(0, 0, dsp_w*.9, 0, users_bookings[list_index[i]], users_bookings[list_index[i]]['stat'])
		if(i>=list_range) then
			break
		end
	end

	if(#list_index > list_range) then
		local btn_g = display.newGroup()
		local btn_bg = create_background(0, 0, dsp_w*.6, btn_h*.9, 20, {0.2, 0.5, 0.8, .4})
		local btn_lbl = create_label(0, 0, dsp_w, dsp_w*.05, "Show more", "center", {0.1,0.1,0.1,.8})
		btn_lbl.x = btn_bg.x+((btn_bg.width-btn_lbl.width)*.5)
		btn_lbl.y = (btn_bg.height-btn_lbl.height)*.5
		btn_g:insert(btn_bg)
		btn_g:insert(btn_lbl)
		btn_g.x = (dsp_w-btn_bg.width)*.5
		btn_g.y = pos_y
		btn_g:addEventListener( "tap", show_items )
		msg_container_g:insert(btn_g)
	end

	if(#list_index == 0) then
		local btn_lbl = create_label(0, 0, dsp_w, dsp_w*.05, "- No booking yet -", "center", {0,0,0,.8}, gfont_ita)
		btn_lbl.x = 0
		btn_lbl.y = pos_y
		msg_container_g:insert(btn_lbl)
	end
		
	slides[1]:setScrollHeight(msg_container_g.height+30)
	slides[1]:insert(msg_container_g)

	processing_state({btn_add}, true)
end

local function load_booking_details( event )
	reloading_content = false
    if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
        res = event.response
        if(res ~= "") then
            local arr = json.decode(res)
			for i=1, #arr do
				users_bookings[arr[i].id] = {}
				users_bookings[arr[i].id]['id'] = arr[i].id
				users_bookings[arr[i].id]['mode'] = arr[i].mode
				users_bookings[arr[i].id]['tstamp'] = arr[i].sched_date
				users_bookings[arr[i].id]['stat'] = arr[i].status
				users_bookings[arr[i].id]['confirmed'] = arr[i].accepted
				users_bookings[arr[i].id]['pickup'] = arr[i].pickup
				users_bookings[arr[i].id]['dropoff'] = arr[i].arrived
				users_bookings[arr[i].id]['processing'] = arr[i].processing
				users_bookings[arr[i].id]['delivery'] = arr[i].outgoing
				users_bookings[arr[i].id]['completed'] = arr[i].completed
				
				list_index[i] = arr[i].id
			end
        end
		
        display_booked_list()
    end
end

function reload_user_bookings()
	if(enable_act) then
		msg_container_g:removeSelf()
		msg_container_g = display.newGroup()
		pos_y = 20
		processing_state({btn_add}, false)
		local json_data = '{"key":"' .. api_key .. '","id":"'.. user.id ..'"}'
		network.request( host_url .. "get_user_booking/" .. json_data, "GET",  load_booking_details)
	end
end

function navi_slides(event)
	if(event.target.id ~= cur_index) then
		indc[cur_index]:setState( { isOn=false } )
		indc_lbl[cur_index]:setFillColor(unpack(indc_clr))
		indc_lbl[event.target.id]:setFillColor(unpack(indc_hl_clr))
		
		slides[cur_index].x = dsp_w
		cur_index = event.target.id
		indc[cur_index]:setState( { isOn=true } )

		if(event.target.id == 4) then
			if(enable_act) then
				change_page("pages.profile", "slideLeft")
			end
		else
			slides[cur_index].x = 0
		end
	else
		indc[cur_index]:setState( { isOn=true } )
	end
end

local function display_points_home(event)
	if ( event.isError ) then
        scrn_msg:show("Network error!")
    else
		lbl_points.text = trim_string(event.response)
	end
end

function scene:create( event )
	network.request( host_url .. "clear_notification/" .. user.id, "GET",  clear_notification_update)

	scene_g = self.view
	local bg = std_page_background()
	scene_g:insert(bg)
	local top_g = display.newGroup()
    local form_g = display.newGroup()
	
	local top_bg = create_background(dsp_w*.015, dsp_w*.18, dsp_w*.97, dsp_h*.1, 10, {0.2, 0.5, 0.8, 1})
	top_g:insert(top_bg)

	local shop_icon = display.newImageRect("assets/images/quinns_logo.png", btn_h*1.4, btn_h*1.4)
	shop_icon.x = dsp_w-(shop_icon.width*1.2)
	shop_icon.y = 5
	anchor(shop_icon)
	top_g:insert(shop_icon)

	lbl_user = create_label(top_bg.x+5, 0, dsp_w*.5, lbl_gfs_2, "Hello, "..user.first_name, "left", {0,0,0,.8})
	lbl_user.y = top_bg.y-(lbl_user.height*1.4)
	top_g:insert(lbl_user)
	--local lbl = create_label(lbl_user.x, 0, dsp_w*.5, lbl_gfs_3, "Hello", "left", {0,0,0,.8})
	--lbl.y = lbl_user.y-(lbl.height*.6)
	--top_g:insert(lbl)

	lbl = create_label(top_bg.x+20, lbl_user.y+lbl_user.height, dsp_w*.22, lbl_gfs_1, "Points:", "left", {1,1,1,1})
	lbl.y = top_bg.y+((top_bg.height-lbl.height))*.5
	lbl_points = create_label(lbl.x+lbl.width, lbl_user.y+lbl_user.height, dsp_w*.5, lbl_gfs_0, "0", "left", {1,1,1,1})
	lbl_points.y = top_bg.y+((top_bg.height-lbl_points.height)*.55)
	top_g:insert(lbl_points)
	top_g:insert(lbl)

	lbl = display.newText("Add Booking", 0, 0, gfont_med, dsp_w*.04)
	anchor(lbl)
	btn_add = create_button("add","", lbl.width*1.5, lbl.height*1.3, "RoundedRect", 28, btn_style_1, gfont_med, 30)
	local btn_icon = display.newImageRect("assets/images/add.png", lbl.height*.8, lbl.height*.8)
	anchor(btn_icon)

	btn_icon.x = (btn_add.width-(lbl.width+btn_icon.width))*.45
	btn_icon.y = (((lbl.height*1.3)-btn_icon.height)*.5)
	lbl.x = btn_icon.x+(btn_icon.width*1.2)
	lbl.y = (((lbl.height*1.3)-lbl.height)*.6)

	btn_add:insert(btn_icon)
	btn_add:insert(lbl)
	btn_add:addEventListener( "tap", create_new )
	btn_add.x = (top_bg.x+top_bg.width)-(btn_add.width*1.1)
	btn_add.y = (top_bg.y+((top_bg.height-btn_add.height)*.5))
	top_g:insert(btn_add)

	network.request( host_url .. "user_points/" .. user.id, "GET",  display_points_home)

	local page_indc_g = display.newGroup()
	local page_indc_size = (dsp_w*.50)/4
	
	local lbl_arr = {'Home','Offers','About Us','Profile'}
	local btn_w = dsp_w*.25

	for i=1, 4 do
		local indc_btn_g = display.newGroup()
		local init_indc_clr = indc_clr
		if(i==1) then
			indc[i] = create_radio_button(page_indc_size, page_indc_size, true, i)
			init_indc_clr = indc_hl_clr
		else
			indc[i] = create_radio_button(page_indc_size, page_indc_size, false, i)
		end

		indc[i].x = (btn_w*(i-1))+((btn_w-page_indc_size)/2) --(page_indc_size*(i-1))+((page_indc_size*.4)*(i-1))
		indc_btn_g.id = i
		indc_btn_g:addEventListener("tap", navi_slides)
		indc_lbl[i] = create_label(btn_w*(i-1), indc[i].height*1.4, btn_w, dsp_w*.035, lbl_arr[i], "center", init_indc_clr, gfont_med)
		
		indc_btn_g:insert(indc[i])
		indc_btn_g:insert(indc_lbl[i])

		page_indc_g:insert(indc_btn_g)
	end

	scene_g:insert(bubble_bg)

	page_indc_g.x = 0 --dsp_w*.05
	page_indc_g.y = dsp_h-(page_indc_g.height*1.5)
	local bottom_bg = create_background(0, page_indc_g.y+20, dsp_w, page_indc_g.height*1.5, 0, {0.2, 0.5, 0.8, 1})

	local sc_view_h = (bottom_bg.y-top_g.height) --dsp_h-(top_g.height+bottom_bg.height)
	slides[1] = create_scroll_view(0, 0, dsp_w, sc_view_h-5, 0)
	slides[1].x = top_g.x
    slides[1].y = (top_bg.y+top_bg.height)

	slides[2] = create_page_slide2(dsp_w, sc_view_h)
	slides[2].x = dsp_w
	slides[2].y = (top_bg.y+top_bg.height)
	scene_g:insert(slides[2])

	slides[3] = create_page_slide3(dsp_w, sc_view_h)
	slides[3].x = dsp_w
	slides[3].y = (top_bg.y+top_bg.height)
	scene_g:insert(slides[3])

	local header_bg = create_background(0, 0, dsp_w, slides[1].y+5, 0, {0.2, 0.5, 0.8, .4})
	scene_g:insert(header_bg)

	scene_g:insert(bottom_bg)
	scene_g:insert(page_indc_g)
	scene_g:insert(slides[1])
	scene_g:insert(top_g)

	processing_state({btn_add}, false)
	local json_data = '{"key":"' .. api_key .. '","id":"'.. user.id ..'"}'
	network.request( host_url .. "get_user_booking/" .. json_data, "GET",  load_booking_details)
end

function scene:show( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:hide( event )
	local phased = event.phase
	if(phased == "will") then
		--print("will")
	elseif(phased == "did") then
		--print("did")
	end
end

function scene:destroy( event )
	
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene